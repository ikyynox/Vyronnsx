#!/usr/bin/env python3
"""
generate_pdf.py <findings.json>

Fase 4: susun findings.json jadi laporan PDF final. Ditaruh di
reports/<host>_<timestamp>.pdf.

Butuh: pip install reportlab (pure-Python, gak ada dependency sistem yang
ribet kayak wkhtmltopdf/weasyprint -- lebih reliable buat dijalanin di
banyak environment beda). Pakai "pip" biasa di Windows, bukan "pip3".

SCHEMA findings.json (WAJIB diikutin, ini yang dibaca script ini):
{
  "target": "https://example.com",
  "scan_date": "2026-09-22T14:30:00",
  "recon_summary": {
    "open_ports": ["80", "443", "22"],
    "server_header": "nginx/1.24",
    "is_wordpress": false
  },
  "confirmed_findings": [
    {
      "title": "judul singkat temuan",
      "severity": "Critical|High|Medium|Low|Informational",
      "category": "kategori dari checklist.md, misal 'Broken Access Control'",
      "location": "endpoint/URL spesifik",
      "request": "request mentah yang beneran dikirim (kutip persis)",
      "response": "response mentah yang beneran diterima (kutip persis)",
      "explanation": "penjelasan yang eksplisit ngerujuk ke request/response di atas",
      "impact": "dampak konkret kalau dieksploitasi",
      "reproduction_steps": "langkah reproduce, step by step",
      "recommendation": "saran perbaikan KONKRET sesuai tech stack, bukan generik"
    }
  ],
  "suspected_findings": [
    {
      "title": "...",
      "category": "...",
      "location": "...",
      "indication": "apa yang mencurigakan (bukan bukti definitif)",
      "why_needs_manual_check": "kenapa ini butuh verifikasi manusia"
    }
  ],
  "not_tested": [
    {"area": "...", "reason": "kenapa belum sempat diuji"}
  ]
}

Kategori confirmed_findings dan suspected_findings WAJIB dipisah -- lihat
references/evidence-rules.md buat aturan lengkapnya. Script ini SENGAJA
nge-render dua kategori itu dengan visual yang beda jelas (warna beda,
header beda) supaya pembaca laporan gak ketuker mana yang udah kebukti dan
mana yang masih dugaan.
"""

import sys
import json
import os
from datetime import datetime
from xml.sax.saxutils import escape as _xml_escape

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        PageBreak, HRFlowable, Preformatted
    )
    from reportlab.lib.enums import TA_CENTER
except ImportError:
    print("ERROR: reportlab belum keinstall. Jalanin: pip install reportlab")
    sys.exit(1)

def esc(value):
    """Escape nilai dinamis (dari findings.json) sebelum ditaro di dalem
    reportlab Paragraph. Paragraph pake mini XML-parser internal (reportlab)
    buat ngebaca tag kayak <b>/<br/> -- kalau isinya ada karakter mentah
    '<', '>', atau '&' (yang HAMPIR PASTI muncul di konteks scanner ini:
    payload XSS kayak <script>, URL dengan query string pake '&', dst),
    Paragraph bakal exception/crash dan PDF gagal ke-generate sama sekali.
    Preformatted (dipake buat request/response mentah) gak kena masalah ini
    karena dia render literal, bukan lewat parser markup -- jadi gak perlu
    di-escape."""
    if value is None:
        return "-"
    return _xml_escape(str(value))


SEVERITY_COLORS = {
    "Critical": colors.HexColor("#7a1010"),
    "High": colors.HexColor("#c0392b"),
    "Medium": colors.HexColor("#e67e22"),
    "Low": colors.HexColor("#f1c40f"),
    "Informational": colors.HexColor("#7f8c8d"),
}


def build_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TitleBig", fontSize=22, leading=26,
                               alignment=TA_CENTER, spaceAfter=8))
    styles.add(ParagraphStyle(name="SubTitle", fontSize=12, leading=16,
                               alignment=TA_CENTER, textColor=colors.grey,
                               spaceAfter=20))
    styles.add(ParagraphStyle(name="SectionHeader", fontSize=16, leading=20,
                               spaceBefore=16, spaceAfter=8,
                               textColor=colors.HexColor("#1a1a2e")))
    styles.add(ParagraphStyle(name="FindingTitle", fontSize=13, leading=16,
                               spaceBefore=10, spaceAfter=4,
                               fontName="Helvetica-Bold"))
    styles.add(ParagraphStyle(name="Label", fontSize=9, leading=12,
                               fontName="Helvetica-Bold",
                               textColor=colors.HexColor("#444444"),
                               spaceBefore=6))
    styles.add(ParagraphStyle(name="Body", fontSize=10, leading=14))
    styles.add(ParagraphStyle(name="EvidenceCode", fontName="Courier", fontSize=8,
                               leading=10, backColor=colors.HexColor("#f4f4f4"),
                               borderPadding=6))
    return styles


def severity_badge(severity, styles):
    color = SEVERITY_COLORS.get(severity, colors.grey)
    style = ParagraphStyle(name="SeverityBadge", fontSize=10, leading=12,
                            fontName="Helvetica-Bold", textColor=colors.white,
                            backColor=color, borderPadding=4,
                            alignment=TA_CENTER)
    return Paragraph(esc(severity).upper(), style)


SEVERITY_ORDER = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Informational": 4}


def overall_risk_banner(confirmed, styles):
    """Badge gede di cover: severity PALING TINGGI di antara semua confirmed
    findings. Ini cuma ringkasan sekilas, bukan pengganti baca detail tiap
    temuan -- 1 Critical + 0 lainnya tetep nampilin 'CRITICAL', bukan
    rata-rata."""
    if not confirmed:
        label = "TIDAK ADA TEMUAN TERKONFIRMASI"
        color = colors.HexColor("#2e7d32")
    else:
        highest = min(confirmed, key=lambda f: SEVERITY_ORDER.get(f.get("severity", "Informational"), 5))
        sev = highest.get("severity", "Informational")
        label = f"RISIKO KESELURUHAN: {esc(sev).upper()}"
        color = SEVERITY_COLORS.get(sev, colors.grey)
    style = ParagraphStyle(name="OverallRisk", fontSize=14, leading=20,
                            fontName="Helvetica-Bold", textColor=colors.white,
                            backColor=color, borderPadding=10,
                            alignment=TA_CENTER)
    return Paragraph(label, style)


def render_confirmed_finding(f, idx, styles, elements):
    elements.append(Paragraph(f"#{idx} — {esc(f.get('title', '(tanpa judul)'))}",
                               styles["FindingTitle"]))

    meta_table = Table([
        [severity_badge(f.get("severity", "Informational"), styles),
         Paragraph(f"<b>Kategori:</b> {esc(f.get('category', '-'))}", styles["Body"]),
         Paragraph(f"<b>Lokasi:</b> {esc(f.get('location', '-'))}", styles["Body"])]
    ], colWidths=[3 * cm, 6 * cm, 8 * cm])
    meta_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(meta_table)
    elements.append(Spacer(1, 6))

    elements.append(Paragraph("Bukti — Request", styles["Label"]))
    elements.append(Preformatted(f.get("request") or "(tidak ada)", styles["EvidenceCode"]))

    elements.append(Paragraph("Bukti — Response", styles["Label"]))
    elements.append(Preformatted(f.get("response") or "(tidak ada)", styles["EvidenceCode"]))

    elements.append(Paragraph("Penjelasan", styles["Label"]))
    elements.append(Paragraph(esc(f.get("explanation", "-")), styles["Body"]))

    elements.append(Paragraph("Dampak", styles["Label"]))
    elements.append(Paragraph(esc(f.get("impact", "-")), styles["Body"]))

    elements.append(Paragraph("Cara reproduce", styles["Label"]))
    elements.append(Paragraph(esc(f.get("reproduction_steps", "-")).replace("\n", "<br/>"), styles["Body"]))

    elements.append(Paragraph("Rekomendasi perbaikan", styles["Label"]))
    elements.append(Paragraph(esc(f.get("recommendation", "-")), styles["Body"]))

    elements.append(Spacer(1, 4))
    elements.append(HRFlowable(width="100%", color=colors.HexColor("#dddddd")))
    elements.append(Spacer(1, 10))


def render_suspected_finding(f, idx, styles, elements):
    box_style = ParagraphStyle(name="SuspectedBox", fontSize=10, leading=14,
                                backColor=colors.HexColor("#fff8e1"),
                                borderPadding=8,
                                borderColor=colors.HexColor("#f1c40f"),
                                borderWidth=1)
    text = (
        f"<b>⚠ DUGAAN #{idx} — {esc(f.get('title', '(tanpa judul)'))}</b><br/>"
        f"<b>Kategori:</b> {esc(f.get('category', '-'))} &nbsp;|&nbsp; "
        f"<b>Lokasi:</b> {esc(f.get('location', '-'))}<br/><br/>"
        f"<b>Indikasi:</b> {esc(f.get('indication', '-'))}<br/><br/>"
        f"<b>Kenapa butuh verifikasi manual:</b> {esc(f.get('why_needs_manual_check', '-'))}"
    )
    elements.append(Paragraph(text, box_style))
    elements.append(Spacer(1, 10))


def generate(findings_path):
    with open(findings_path, encoding="utf-8") as f:
        data = json.load(f)

    styles = build_styles()
    target = data.get("target", "unknown")
    host_safe = "".join(c if c.isalnum() or c in ".-_" else "_" for c in target.replace("https://", "").replace("http://", "").split("/")[0])
    timestamp = datetime.now().strftime("%Y-%m-%d_%H%M")
    out_dir = os.path.dirname(findings_path) or "reports"
    out_path = os.path.join(out_dir, f"{host_safe}_{timestamp}.pdf")

    doc = SimpleDocTemplate(out_path, pagesize=A4,
                             topMargin=2 * cm, bottomMargin=2 * cm,
                             leftMargin=2 * cm, rightMargin=2 * cm)
    elements = []

    # --- Cover ---
    elements.append(Spacer(1, 4 * cm))
    elements.append(Paragraph("Laporan Security Assessment", styles["TitleBig"]))
    elements.append(Paragraph(esc(target), styles["SubTitle"]))
    elements.append(Paragraph(f"Tanggal scan: {esc(data.get('scan_date', datetime.now().isoformat()))}",
                               styles["SubTitle"]))
    elements.append(Spacer(1, 1 * cm))

    confirmed = data.get("confirmed_findings", [])
    suspected = data.get("suspected_findings", [])
    not_tested = data.get("not_tested", [])

    elements.append(overall_risk_banner(confirmed, styles))
    elements.append(Spacer(1, 0.5 * cm))

    sev_counts = {}
    for f in confirmed:
        sev = f.get("severity", "Informational")
        sev_counts[sev] = sev_counts.get(sev, 0) + 1

    summary_rows = [["Kategori", "Jumlah"]]
    for sev in ["Critical", "High", "Medium", "Low", "Informational"]:
        if sev_counts.get(sev):
            summary_rows.append([sev, str(sev_counts[sev])])
    summary_rows.append(["Total Terkonfirmasi", str(len(confirmed))])
    summary_rows.append(["Total Dugaan (perlu verifikasi manual)", str(len(suspected))])
    summary_rows.append(["Area belum sempat diuji", str(len(not_tested))])

    summary_table = Table(summary_rows, colWidths=[10 * cm, 4 * cm])
    summary_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dddddd")),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
    ]))
    elements.append(summary_table)

    recon = data.get("recon_summary", {})
    if recon:
        elements.append(Spacer(1, 0.5 * cm))
        recon_text = (
            f"<b>Port kebuka:</b> {esc(', '.join(recon.get('open_ports', [])) or '-')}<br/>"
            f"<b>Server:</b> {esc(recon.get('server_header', '-'))}<br/>"
            f"<b>WordPress:</b> {'Ya' if recon.get('is_wordpress') else 'Tidak'}"
        )
        elements.append(Paragraph(recon_text, styles["Body"]))

    elements.append(PageBreak())

    # --- Confirmed findings ---
    elements.append(Paragraph("Temuan Terkonfirmasi", styles["SectionHeader"]))
    elements.append(Paragraph(
        "Setiap temuan di bagian ini disertai bukti request/response nyata "
        "dan reproducible. Lihat evidence-rules.md untuk standar bukti yang dipakai.",
        styles["Body"]))
    elements.append(Spacer(1, 8))
    if not confirmed:
        elements.append(Paragraph("Tidak ada temuan terkonfirmasi.", styles["Body"]))
    else:
        # Urutin severity paling tinggi dulu
        order = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Informational": 4}
        confirmed_sorted = sorted(confirmed, key=lambda f: order.get(f.get("severity", "Informational"), 5))
        for i, f in enumerate(confirmed_sorted, 1):
            render_confirmed_finding(f, i, styles, elements)

    # --- Suspected findings ---
    elements.append(PageBreak())
    elements.append(Paragraph("Dugaan — Perlu Verifikasi Manual", styles["SectionHeader"]))
    elements.append(Paragraph(
        "Bagian ini berisi indikasi yang MENCURIGAKAN tapi belum ada bukti definitif. "
        "JANGAN dianggap sebagai kerentanan yang pasti ada — perlu dicek manual.",
        styles["Body"]))
    elements.append(Spacer(1, 8))
    if not suspected:
        elements.append(Paragraph("Tidak ada dugaan yang tercatat.", styles["Body"]))
    else:
        for i, f in enumerate(suspected, 1):
            render_suspected_finding(f, i, styles, elements)

    # --- Not tested ---
    if not_tested:
        elements.append(PageBreak())
        elements.append(Paragraph("Area Belum Sempat Diuji", styles["SectionHeader"]))
        for item in not_tested:
            elements.append(Paragraph(
                f"<b>{esc(item.get('area', '-'))}:</b> {esc(item.get('reason', '-'))}",
                styles["Body"]))
            elements.append(Spacer(1, 4))

    doc.build(elements)
    print(f"PDF berhasil dibuat: {out_path}")
    return out_path


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: generate_pdf.py <findings.json>")
        sys.exit(1)
    generate(sys.argv[1])
