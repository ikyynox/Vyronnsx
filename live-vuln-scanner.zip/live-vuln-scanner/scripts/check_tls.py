#!/usr/bin/env python3
"""
check_tls.py <target-host> [output-dir]

Cek konfigurasi SSL/TLS: cipher lemah, protokol usang (SSLv3/TLS1.0/1.1),
sertifikat expired/mismatch, HSTS header. Pakai testssl.sh kalau ada
(coverage paling lengkap), fallback ke modul ssl bawaan Python (gak butuh
install openssl CLI terpisah sama sekali -- lebih portable ke Windows).
"""

import sys
import os
import json
import re
import ssl
import socket
import shutil
import subprocess
import tempfile
import urllib.request
from datetime import datetime


def check_protocol_accepted(host, port, protocol):
    """Cek apakah server masih nerima protokol TLS/SSL usang tertentu."""
    try:
        ctx = ssl.SSLContext(protocol)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=5) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                return True, ssock.cipher()
    except Exception:
        return False, None


def get_cert_info(host, port=443):
    """Ambil detail sertifikat (subject/issuer/notBefore/notAfter) SEKALIGUS
    nyatet apakah verifikasi default (hostname + chain of trust) lolos.

    BUG versi lama: langkah terakhir selalu connect pakai verify_mode
    default (CERT_REQUIRED). Itu artinya kalau cert-nya expired/self-signed/
    hostname-mismatch -- JUSTRU kasus paling penting buat dicek scanner TLS
    -- connect itu sendiri bakal GAGAL (exception), jadi fungsi cuma balikin
    {"error": ...} tanpa notAfter/subject/issuer sama sekali. Yang mau tau
    "cert-nya kapan expired" malah gak dapet jawaban pas certnya expired.

    Fix: coba verify_mode default dulu (kalo lolos, cert valid & trusted).
    Kalau gagal verifikasi, connect ULANG pakai CERT_NONE (gak exception)
    buat tetep ambil raw cert-nya, terus di-decode manual tanpa perlu
    verifikasi -- jadi detail cert (termasuk notAfter buat ngecek expired)
    tetep kebaca walaupun cert-nya invalid/gak dipercaya."""
    verification_error = None
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=10) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                return {
                    "subject": dict(x[0] for x in cert.get("subject", [])),
                    "issuer": dict(x[0] for x in cert.get("issuer", [])),
                    "notBefore": cert.get("notBefore"),
                    "notAfter": cert.get("notAfter"),
                    "verified": True,
                }
    except ssl.SSLError as e:
        verification_error = str(e)
    except Exception as e:
        return {"error": str(e)}

    # Verifikasi default gagal (expired/self-signed/mismatch, dll) -- tetep
    # ambil raw cert tanpa verifikasi, karena justru ini kasus yang mau
    # dilaporkan sebagai temuan.
    try:
        ctx_noverify = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx_noverify.check_hostname = False
        ctx_noverify.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=10) as sock:
            with ctx_noverify.wrap_socket(sock, server_hostname=host) as ssock:
                der = ssock.getpeercert(binary_form=True)

        parsed = None
        if der:
            pem = ssl.DER_cert_to_PEM_cert(der)
            tmp_path = None
            try:
                with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as tmp:
                    tmp.write(pem)
                    tmp_path = tmp.name
                # _test_decode_cert: helper internal ssl module (dipake juga
                # di test suite cpython sendiri) buat decode cert dari file
                # TANPA perlu verifikasi -- gak ada API publik resmi buat ini
                # di stdlib polos (tanpa dependency tambahan kayak `cryptography`).
                parsed = ssl._ssl._test_decode_cert(tmp_path)
            except Exception:
                parsed = None
            finally:
                if tmp_path and os.path.exists(tmp_path):
                    os.unlink(tmp_path)

        if parsed:
            return {
                "subject": dict(x[0] for x in parsed.get("subject", [])),
                "issuer": dict(x[0] for x in parsed.get("issuer", [])),
                "notBefore": parsed.get("notBefore"),
                "notAfter": parsed.get("notAfter"),
                "verified": False,
                "verification_error": verification_error,
            }
        return {
            "verified": False,
            "verification_error": verification_error,
            "note": "Cert ketangkep tapi gagal didecode detail-nya (subject/issuer/tanggal) -- minimal udah tau verifikasi default-nya gagal.",
        }
    except Exception as e:
        return {"error": str(e), "verification_error": verification_error}


WEAK_CIPHER_GROUPS = {
    "RC4": "RC4",
    "3DES": "3DES",
    "DES (non-3DES)": "DES-CBC-SHA",
    "export-grade": "EXPORT",
    "NULL (tanpa enkripsi)": "eNULL",
    "anonymous (tanpa autentikasi)": "aNULL",
}


def check_weak_ciphers(host, port=443):
    """Coba connect pake cipher-suite yang SENGAJA cuma ngandung satu grup
    cipher lemah/usang (RC4, 3DES, NULL, dll) lewat ssl.SSLContext.set_ciphers().
    Kalau koneksinya SUKSES, artinya server itu MASIH NERIMA cipher itu --
    temuan valid (browser modern emang gak bakal milih cipher ini secara
    default, tapi server yang masih nerima tetep jadi celah downgrade-attack
    kalau ada yang maksain negotiate ke situ).

    Ini pure stdlib (modul ssl bawaan) -- gak butuh testssl.sh/binary
    eksternal sama sekali, jadi nutup sebagian besar gap coverage antara
    fallback ini sama testssl.sh buat bagian cipher suite."""
    results = {}
    for label, cipher_str in WEAK_CIPHER_GROUPS.items():
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        # PENTING: set_ciphers() cuma ngatur cipher list buat TLS <=1.2 --
        # ciphersuite TLS 1.3 (TLS_AES_*, dst) diatur terpisah lewat
        # set_ciphersuites() dan TETEP kepake walau kita udah batesin ke
        # cipher lemah kayak eNULL/aNULL/RC4. Tanpa baris ini, hasilnya
        # FALSE POSITIVE: koneksi lolos lewat TLS 1.3 normal, kedetect
        # seolah-olah server nerima cipher lemah padahal enggak sama sekali.
        ctx.maximum_version = ssl.TLSVersion.TLSv1_2
        try:
            ctx.set_ciphers(cipher_str)
        except ssl.SSLError:
            results[label] = ("gak bisa dicek -- OpenSSL lokal udah gak support cipher ini "
                               "sama sekali (versi modern emang sengaja ngilangin cipher "
                               "seusang ini, ini normal & bukan tanda error)")
            continue
        try:
            with socket.create_connection((host, port), timeout=5) as sock:
                with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                    cipher_used = ssock.cipher()
            results[label] = f"MASIH DITERIMA ({cipher_used[0] if cipher_used else '?'}) -- usang, harusnya di-disable di server"
        except Exception:
            results[label] = "ditolak (aman)"
    return results


def get_hsts_header(host):
    try:
        req = urllib.request.Request(f"https://{host}",
                                      headers={"User-Agent": "Mozilla/5.0 (compatible; SecurityRecon/1.0)"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.headers.get("Strict-Transport-Security", "TIDAK ADA")
    except Exception:
        return "TIDAK ADA (atau gagal konek)"


def main():
    if len(sys.argv) < 2:
        print("Usage: check_tls.py <target-host> [output-dir]")
        sys.exit(1)

    target = sys.argv[1]
    outdir = sys.argv[2] if len(sys.argv) > 2 else "reports"
    os.makedirs(outdir, exist_ok=True)

    host = re.sub(r"^https?://", "", target).split("/")[0].split(":")[0]
    safe_name = re.sub(r"[^a-zA-Z0-9.]", "_", host)
    out_path = os.path.join(outdir, f"{safe_name}_tls.json")

    print(f"== TLS/SSL check: {host} ==")

    if shutil.which("testssl.sh"):
        print("  testssl.sh ketemu, pakai itu buat coverage paling lengkap.")
        try:
            subprocess.run(["testssl.sh", "--jsonfile", out_path, "--quiet", host],
                            timeout=600)
            print(f"  Hasil lengkap (testssl.sh) tersimpen di {out_path}")
        except Exception as e:
            print(f"  testssl.sh gagal jalan ({e}), fallback ke ssl module.")
            run_fallback(host, out_path)
    else:
        print("  testssl.sh gak ketemu, fallback ke modul ssl bawaan Python.")
        print("  Mau coverage lebih lengkap (cipher suite detail, dll)? Install dulu")
        print("  (TANYA USER DULU sebelum ngejalanin ini, jangan auto -- lihat SKILL.md):")
        print("    git clone --depth 1 https://github.com/testssl/testssl.sh.git /tmp/testssl.sh")
        print("    chmod +x /tmp/testssl.sh/testssl.sh")
        print("    ln -sf /tmp/testssl.sh/testssl.sh /usr/local/bin/testssl.sh")
        print("  (butuh bash + openssl, yang udah pasti ada di environment Linux manapun --")
        print("   termasuk sandbox code execution Claude. TIDAK butuh WSL/Git Bash sama")
        print("   sekali kalau yang ngejalanin perintah ini Claude di sandbox-nya sendiri,")
        print("   bukan CMD/PowerShell lokal di Windows.)")
        run_fallback(host, out_path)

    print("== TLS check selesai ==")


def run_fallback(host, out_path):
    cert_info = get_cert_info(host)
    hsts = get_hsts_header(host)

    # SSLv3 udah gak ada constant-nya di Python modern (dihapus krn gak aman
    # sama sekali) -- cek TLS 1.0 & 1.1 aja yang masih relevan dicek.
    protocols_to_check = {}
    if hasattr(ssl, "TLSVersion"):
        for name, attr in [("TLSv1.0", "TLSv1"), ("TLSv1.1", "TLSv1_1")]:
            proto = getattr(ssl, f"PROTOCOL_{attr}", None)
            if proto is not None:
                accepted, cipher = check_protocol_accepted(host, 443, proto)
                protocols_to_check[name] = "MASIH DITERIMA (usang, harusnya di-disable)" if accepted else "ditolak (aman)"
            else:
                protocols_to_check[name] = "gak bisa dicek (Python build ini gak support protokol ini buat testing -- biasanya karena emang udah dianggap gak aman & dihapus)"

    print("  Cek cipher suite lemah (RC4/3DES/NULL/export/anonymous)...")
    weak_ciphers = check_weak_ciphers(host)

    data = {
        "host": host,
        "certificate_info": cert_info,
        "hsts_header": hsts,
        "legacy_protocols": protocols_to_check,
        "weak_ciphers": weak_ciphers,
        "note": "fallback ssl module (pure Python) -- testssl.sh opsional buat detail cipher suite yang lebih exhaustive",
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"  Hasil (fallback) tersimpen di {out_path}")


if __name__ == "__main__":
    main()
