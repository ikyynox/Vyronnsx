#!/usr/bin/env python3
"""
recon.py <target-domain-or-url> [output-dir] [--full-ports]

Fase 1: port scan + fingerprint tech stack + deteksi CMS. Ditulis PURE
PYTHON (bukan bash) biar jalan identik di Windows CMD, Linux, Mac -- gak
butuh Git Bash/WSL sama sekali, cukup python yang emang udah wajib ada
buat generate_pdf.py.

Kenapa port scan perlu: kerentanan paling sering ketemu itu BUKAN di web
app-nya sendiri, tapi service lain yang gak sengaja ke-expose ke publik
(database, admin panel di port lain, Redis tanpa auth, dll). Kalau cuma
tes :80/:443, semua itu gak akan pernah ketauan.

--full-ports (OPSIONAL, TANYA USER DULU sebelum dipake -- lihat SKILL.md):
default-nya scan cuma port umum (1000 teratas via nmap, atau ~38 port
hardcoded di fallback). Dengan flag ini, scan SEMUA 1-65535 port -- jauh
lebih lengkap (nangkep service di port acak/custom), tapi jauh lebih
lama & lebih "berisik" secara jaringan. Jangan dipake default ke semua
scan, cuma kalau emang dicurigai ada service tersembunyi di port non-standar.
"""

import sys
import os
import json
import socket
import subprocess
import shutil
import re
import urllib.request
import urllib.error
import concurrent.futures

COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 465, 587, 993,
                995, 1433, 1521, 3000, 3306, 3389, 5000, 5432, 5900, 5984,
                6379, 7001, 8000, 8080, 8081, 8443, 8888, 9000, 9090, 9200,
                11211, 27017, 50000]

USER_AGENT = "Mozilla/5.0 (compatible; SecurityRecon/1.0)"


def normalize_target(target):
    if target.startswith("http://") or target.startswith("https://"):
        full_url = target
        host = re.sub(r"^https?://", "", target).split("/")[0].split(":")[0]
    else:
        host = target
        full_url = f"https://{target}"
    return host, full_url


def port_scan_nmap(host):
    """Coba pakai nmap kalau keinstall -- lebih akurat & cepat dari socket scan manual."""
    try:
        result = subprocess.run(
            ["nmap", "-Pn", "--top-ports", "1000", "-T4", host],
            capture_output=True, text=True, timeout=180
        )
        ports = re.findall(r"^(\d+)/tcp\s+open", result.stdout, re.MULTILINE)
        return ports
    except Exception:
        return None


def port_scan_socket_fallback(host):
    """Fallback kalau nmap gak ada -- cuma cek port umum, lebih lambat &
    kurang lengkap dari nmap tapi gak butuh install apa pun (socket itu
    modul bawaan Python)."""
    open_ports = []
    for port in COMMON_PORTS:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.5)
        try:
            if s.connect_ex((host, port)) == 0:
                open_ports.append(str(port))
        except Exception:
            pass
        finally:
            s.close()
    return open_ports


def port_scan_nmap_full(host):
    """Full port scan (1-65535) pakai nmap -p-. JAUH lebih lama dari
    --top-ports 1000 (bisa belasan menit tergantung firewall/latency target),
    makanya ini SELALU opt-in (--full-ports), bukan default."""
    try:
        result = subprocess.run(
            ["nmap", "-Pn", "-p-", "-T4", host],
            capture_output=True, text=True, timeout=1800
        )
        ports = re.findall(r"^(\d+)/tcp\s+open", result.stdout, re.MULTILINE)
        return ports
    except Exception:
        return None


def port_scan_socket_full(host, max_workers=300, per_port_timeout=1.0):
    """Full port scan (1-65535) versi fallback tanpa nmap. Sequential bakal
    makan waktu >24 jam (65535 port x 1.5 detik satu-satu), jadi WAJIB
    paralel pakai thread pool. max_workers dibatasi 300 biar gak keliatan
    kayak serangan DoS ke jaringan sendiri/target -- full port scan itu
    sendiri udah cukup agresif, jangan dinaikin sembarangan tanpa alasan."""
    open_ports = []

    def check(port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(per_port_timeout)
        try:
            if s.connect_ex((host, port)) == 0:
                return port
        except Exception:
            pass
        finally:
            s.close()
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(check, p) for p in range(1, 65536)]
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            if result:
                open_ports.append(result)
    return [str(p) for p in sorted(open_ports)]


def grab_banner(host, port, timeout=2.0):
    """Coba ambil banner/respon awal dari port yang kebuka -- fingerprint
    cepet buat service yang gak keliatan dari HTTP doang (versi SSH, banner
    FTP, greeting SMTP, dll). Banyak service (HTTPS murni, dll) emang gak
    ngasih apa-apa tanpa request yang bener duluan -- banner kosong itu
    NORMAL, bukan berarti gagal."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        try:
            data = s.recv(256)
            return data.decode("utf-8", errors="ignore").strip() or None
        except Exception:
            return None
        finally:
            s.close()
    except Exception:
        return None


def fetch_headers_and_body(url):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            headers = dict(resp.headers)
            body = resp.read(200000).decode("utf-8", errors="ignore")  # cap 200KB, cukup buat fingerprint
            return headers, body
    except Exception as e:
        return {}, f""


def detect_wordpress(headers, body, full_url):
    if re.search(r"wp-content|wp-includes|generator.*wordpress", body, re.IGNORECASE):
        return True
    try:
        req = urllib.request.Request(f"{full_url.rstrip('/')}/wp-json/",
                                      headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status == 200:
                return True
    except Exception:
        pass
    return False


SECURITY_HEADERS_TO_CHECK = [
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
]


def check_security_headers(headers):
    """Cek header hardening standar (di luar HSTS, yang udah dicek
    check_tls.py). Header-header ini gak langsung jadi "kerentanan" kalau
    absen -- ini DEFENSE-IN-DEPTH, jadi dicatat sebagai info/low severity,
    bukan otomatis ditulis Critical/High. Reasoning soal seberapa penting
    tetep keputusan Fase 3, bukan skrip ini."""
    result = {}
    for h in SECURITY_HEADERS_TO_CHECK:
        result[h] = headers.get(h, "TIDAK ADA")
    return result


def enumerate_subdomains_crtsh(domain, timeout=20, limit=200):
    """Subdomain enumeration PASIF lewat Certificate Transparency log
    (crt.sh) -- query ke data publik yang emang udah ke-log pas CA nerbitin
    sertifikat buat domain itu/subdomainnya. BUKAN brute-force/scanning
    aktif ke domain-domain tersebut, jadi aman & gak ninggalin jejak ke
    target.

    PENTING: subdomain yang kekembali DARI SINI BELUM TENTU MASIH AKTIF --
    itu cuma riwayat sertifikat yang pernah diterbitin, bisa aja domainnya
    udah mati/pindah. JANGAN ditulis sebagai temuan tanpa verifikasi
    (resolve DNS / coba akses) dulu di Fase 3."""
    try:
        url = f"https://crt.sh/?q=%25.{domain}&output=json"
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        subs = set()
        for entry in data:
            name = entry.get("name_value", "")
            for line in name.split("\n"):
                line = line.strip().lower()
                if line.endswith(domain) and not line.startswith("*"):
                    subs.add(line)
        return sorted(subs)[:limit]
    except Exception as e:
        return {"error": f"crt.sh gak bisa diakses atau timeout ({e}) -- skip, bukan fatal"}


def check_robots_and_sitemap(full_url):
    """Cek robots.txt (ambil semua baris Disallow -- sering gak sengaja
    'ngasih tau' path admin/internal yang pengen disembunyiin dari search
    engine, padahal itu sendiri jadi petunjuk) + keberadaan sitemap.xml."""
    result = {"robots_txt": None, "disallowed_paths": [], "sitemap_xml_found": False}
    try:
        req = urllib.request.Request(f"{full_url.rstrip('/')}/robots.txt",
                                      headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status == 200:
                text = resp.read(50000).decode("utf-8", errors="ignore")
                result["robots_txt"] = "ADA"
                result["disallowed_paths"] = sorted(set(
                    re.findall(r"(?im)^Disallow:\s*(\S+)", text)
                ))
    except Exception:
        result["robots_txt"] = "TIDAK ADA / gagal diakses"

    try:
        req = urllib.request.Request(f"{full_url.rstrip('/')}/sitemap.xml",
                                      headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as resp:
            result["sitemap_xml_found"] = (resp.status == 200)
    except Exception:
        pass

    return result


COMMON_SENSITIVE_PATHS = [
    "/.git/config", "/.git/HEAD", "/.env", "/.env.example", "/.env.local",
    "/docker-compose.yml", "/docker-compose.yaml", "/.DS_Store",
    "/backup.sql", "/backup.zip", "/db_backup.sql", "/.aws/credentials",
    "/.htpasswd", "/web.config", "/phpinfo.php", "/wp-config.php.bak",
    "/config.php.bak", "/.svn/entries", "/composer.json.bak",
]


def check_exposed_paths(full_url, timeout=8):
    """Cek keberadaan SEDIKIT path sensitif yang sangat umum ke-expose gak
    sengaja (.git/, .env, backup file, dll). INI BUKAN directory
    brute-force/wordlist besar -- cuma ~19 path dengan signal tinggi yang
    SERING ketinggalan ke-deploy ke production. Dicek pake HEAD dulu (lebih
    ringan), fallback GET kalau server gak dukung HEAD, dan body CUMA
    dibaca dikit (bukan didownload penuh) buat mastiin bukan custom 404
    page yang balikin status 200."""
    found = []
    for path in COMMON_SENSITIVE_PATHS:
        url = f"{full_url.rstrip('/')}{path}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT}, method="HEAD")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status == 200:
                    found.append({"path": path, "status": resp.status})
        except urllib.error.HTTPError as e:
            if e.code == 405:  # method HEAD gak didukung, coba GET
                try:
                    req2 = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
                    with urllib.request.urlopen(req2, timeout=timeout) as resp2:
                        if resp2.status == 200:
                            found.append({"path": path, "status": resp2.status})
                except Exception:
                    pass
        except Exception:
            pass
    return found


TAKEOVER_FINGERPRINTS = {
    "GitHub Pages": "There isn't a GitHub Pages site here",
    "Heroku": "no-such-app.html",
    "AWS S3": "NoSuchBucket",
    "Azure": "404 Web Site not found",
    "Shopify": "Sorry, this shop is currently unavailable",
    "Fastly": "Fastly error: unknown domain",
    "Surge.sh": "project not found",
    "Netlify": "Not Found - Request ID",
}


def check_subdomain_takeover(subdomains, timeout=6, max_check=30):
    """Buat tiap subdomain yang ketemu di enumerate_subdomains_crtsh, coba
    akses & cocokin body response ke fingerprint error page layanan cloud
    yang dikenal (GitHub Pages, S3, Heroku, dll). Kalau MATCH, itu indikasi
    subdomain itu masih nunjuk (CNAME) ke layanan yang udah gak dipake lagi
    -- siapa pun bisa claim layanan itu & "ambil alih" subdomain ini
    (subdomain takeover).

    CATATAN: ini BUKAN bukti definitif, cuma indikasi kuat -- tetep masuk
    kategori 'Dugaan' sampai diverifikasi manual (coba claim beneran itu
    actionable tapi WAJIB mode --allow-mutating + extra hati-hati, ini
    DAFTAR BUAT DICEK, bukan buat dieksekusi otomatis). Dibatesin
    max_check (default 30) biar gak lambat/berisik kalau subdomain-nya
    ratusan."""
    if not isinstance(subdomains, list):
        return []
    results = []
    for sub in subdomains[:max_check]:
        body = None
        try:
            req = urllib.request.Request(f"http://{sub}/", headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read(5000).decode("utf-8", errors="ignore")
        except urllib.error.HTTPError as e:
            # PENTING: halaman fingerprint takeover (S3 NoSuchBucket, GitHub
            # Pages 404, dll) HAMPIR SELALU di-serve dengan status error
            # (404/403), yang bikin urllib raise HTTPError alih-alih balikin
            # response biasa. Tanpa nangkep ini secara eksplisit & tetep
            # baca body-nya dari exception object, fungsi ini bakal selalu
            # skip JUSTRU di kasus yang paling umum -- bug yang sempet
            # ke-ship sebelum ketauan pas testing.
            try:
                body = e.read(5000).decode("utf-8", errors="ignore")
            except Exception:
                body = None
        except Exception:
            body = None

        if body is None:
            continue
        for service, fingerprint in TAKEOVER_FINGERPRINTS.items():
            if fingerprint.lower() in body.lower():
                results.append({"subdomain": sub, "possible_service": service,
                                 "note": "DUGAAN -- verifikasi manual, jangan asumsikan pasti takeover"})
    return results


def _dns_txt_lookup(name, timeout=10):
    """Query TXT record lewat DNS-over-HTTPS (Google public resolver) --
    pure HTTP+JSON, gak butuh library dnspython atau shell out ke
    dig/nslookup (yang gak selalu ada, apalagi di Windows)."""
    try:
        url = f"https://dns.google/resolve?name={name}&type=TXT"
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        answers = data.get("Answer", [])
        return [a.get("data", "").strip('"') for a in answers]
    except Exception:
        return None


def check_email_security(domain):
    """Cek SPF (TXT di root domain) & DMARC (TXT di _dmarc.<domain>).
    Bukan 'exploit' langsung, tapi relevan kalau target punya fitur kirim
    email (invoice, notifikasi, reset password) -- SPF/DMARC yang
    lemah/absen bikin domain gampang dipake buat email spoofing/phishing
    yang keliatan 'resmi' dari domain itu.

    DKIM gak dicek detail di sini -- selector-nya beda-beda per provider
    email (gak ada 1 lokasi fixed buat di-query), jadi itu dicatet sebagai
    'perlu dicek manual sesuai provider email yang dipake' di findings."""
    result = {"spf": None, "dmarc": None}

    spf_records = _dns_txt_lookup(domain)
    if spf_records is None:
        result["spf"] = "gak bisa dicek (DNS lookup gagal/timeout)"
    else:
        spf = [r for r in spf_records if r.lower().startswith("v=spf1")]
        result["spf"] = spf[0] if spf else "TIDAK ADA record SPF"

    dmarc_records = _dns_txt_lookup(f"_dmarc.{domain}")
    if dmarc_records is None:
        result["dmarc"] = "gak bisa dicek (DNS lookup gagal/timeout)"
    else:
        dmarc = [r for r in dmarc_records if r.lower().startswith("v=dmarc1")]
        result["dmarc"] = dmarc[0] if dmarc else "TIDAK ADA record DMARC"

    return result


def main():
    args = sys.argv[1:]
    full_scan = "--full-ports" in args
    positional = [a for a in args if not a.startswith("--")]

    if len(positional) < 1:
        print("Usage: recon.py <target-domain-or-url> [output-dir] [--full-ports]")
        sys.exit(1)

    target = positional[0]
    outdir = positional[1] if len(positional) > 1 else "reports"
    os.makedirs(outdir, exist_ok=True)

    host, full_url = normalize_target(target)
    safe_name = re.sub(r"[^a-zA-Z0-9.]", "_", host)
    out_path = os.path.join(outdir, f"{safe_name}_recon.json")

    print(f"== Recon: {host} ==")

    print("[1/10] Port scan..." + (" (FULL 1-65535, bisa lama)" if full_scan else ""))
    ports = None
    if full_scan:
        if shutil.which("nmap"):
            ports = port_scan_nmap_full(host)
        if ports is None:
            print("  nmap gak ketemu/gagal, fallback ke socket scan PARALEL semua 65535 port"
                  " -- tetep bisa makan beberapa menit tergantung koneksi & firewall target.")
            ports = port_scan_socket_full(host)
    else:
        if shutil.which("nmap"):
            ports = port_scan_nmap(host)
        if ports is None:
            print("  nmap gak ketemu/gagal, fallback ke python socket scan (port umum aja, lebih terbatas).")
            ports = port_scan_socket_fallback(host)
    print(f"  Port kebuka: {ports}")

    print("[2/10] Banner grabbing...")
    banners = {}
    if ports and len(ports) <= 50:
        for p in ports:
            b = grab_banner(host, int(p))
            if b:
                banners[p] = b
        if banners:
            print(f"  Banner ketangkep buat {len(banners)} port: {list(banners.keys())}")
        else:
            print("  Gak ada banner yang ketangkep (normal buat HTTPS murni/service yang nunggu request duluan).")
    elif ports:
        print(f"  Port kebuka ada {len(ports)}, skip banner grab individual biar gak lambat"
              " -- cek manual per-port kalau perlu detail servicenya.")

    print("[3/10] Fingerprint HTTP header...")
    headers, body = fetch_headers_and_body(full_url)
    server_header = headers.get("Server", "")
    powered_by = headers.get("X-Powered-By", "")

    print("[4/10] Cek security header (CSP, X-Frame-Options, dll)...")
    sec_headers = check_security_headers(headers)
    missing = [h for h, v in sec_headers.items() if v == "TIDAK ADA"]
    if missing:
        print(f"  Header absen: {', '.join(missing)}")
    else:
        print("  Semua header standar yang dicek ada.")

    print("[5/10] Subdomain enumeration (pasif, via crt.sh)...")
    subdomains = enumerate_subdomains_crtsh(host)
    if isinstance(subdomains, list):
        print(f"  {len(subdomains)} subdomain ketemu di Certificate Transparency log"
              " (BELUM diverifikasi aktif/nggak -- itu kerjaan Fase 3).")
    else:
        print(f"  {subdomains.get('error')}")

    print("[6/10] Cek robots.txt & sitemap.xml...")
    robots_info = check_robots_and_sitemap(full_url)
    if robots_info["disallowed_paths"]:
        print(f"  {len(robots_info['disallowed_paths'])} path Disallow ketemu di robots.txt"
              " -- cek manual, kadang nunjukin area admin/internal.")

    print("[7/10] Cek path sensitif yang umum ke-expose (.git, .env, backup, dll)...")
    exposed = check_exposed_paths(full_url)
    if exposed:
        print(f"  !! {len(exposed)} path sensitif KEBUKA: {[e['path'] for e in exposed]}")
    else:
        print("  Gak ada dari ~19 path umum yang dicek yang kebuka.")

    print("[8/10] Cek indikasi subdomain takeover...")
    takeover_hits = check_subdomain_takeover(subdomains)
    if takeover_hits:
        print(f"  !! {len(takeover_hits)} subdomain nunjukin indikasi takeover (DUGAAN, verifikasi manual)")
    else:
        print("  Gak ada indikasi dari subdomain yang dicek.")

    print("[9/10] Cek email security (SPF/DMARC)...")
    email_sec = check_email_security(host)
    print(f"  SPF: {email_sec['spf']}")
    print(f"  DMARC: {email_sec['dmarc']}")

    print("[10/10] Deteksi CMS...")
    is_wp = detect_wordpress(headers, body, full_url)
    print(f"  WordPress kedeteksi: {is_wp}")

    data = {
        "host": host,
        "url": full_url,
        "full_port_scan": full_scan,
        "open_ports": ports,
        "port_banners": banners,
        "server_header": server_header,
        "x_powered_by": powered_by,
        "security_headers": sec_headers,
        "subdomains_crtsh": subdomains,
        "robots_sitemap": robots_info,
        "exposed_sensitive_paths": exposed,
        "subdomain_takeover_indications": takeover_hits,
        "email_security": email_sec,
        "is_wordpress": is_wp,
    }
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"  Hasil recon disimpen ke {out_path}")

    print("== Recon selesai ==")
    if is_wp:
        print("\n!! WordPress kedeteksi -- baca references/wordpress-checks.md sebelum lanjut Fase 3 buat area ini.")


if __name__ == "__main__":
    main()
