#!/usr/bin/env python3
"""
run_nuclei.py <target-url> [output-dir]

Fase 2 (Lapis 1): jalanin nuclei dengan template kategori yang relevan
buat web app security (CVE, exposure, misconfig, default-login, khusus
wordpress kalau kedeteksi). Ditulis pure Python (subprocess) biar konsisten
jalan di Windows CMD juga, bukan cuma Linux/Mac.
"""

import sys
import os
import json
import re
import shutil
import subprocess


def main():
    if len(sys.argv) < 2:
        print("Usage: run_nuclei.py <target-url> [output-dir]")
        sys.exit(1)

    target = sys.argv[1]
    outdir = sys.argv[2] if len(sys.argv) > 2 else "reports"
    os.makedirs(outdir, exist_ok=True)

    host = re.sub(r"^https?://", "", target).split("/")[0].split(":")[0]
    safe_name = re.sub(r"[^a-zA-Z0-9.]", "_", host)
    out_path = os.path.join(outdir, f"{safe_name}_nuclei.json")
    recon_path = os.path.join(outdir, f"{safe_name}_recon.json")

    if not shutil.which("nuclei"):
        print("PERINGATAN: nuclei gak keinstall. Install dulu:")
        print("  go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest")
        print("  atau: https://github.com/projectdiscovery/nuclei#install-nuclei")
        print("Lanjut ke Fase 3 tanpa hasil Lapis 1 -- coverage bakal lebih terbatas.")
        with open(out_path, "w") as f:
            f.write("")
        return

    print(f"== Nuclei scan: {target} ==")

    # "sqli" ditambahin eksplisit -- tanpa ini, nuclei cuma nangkep SQLi
    # kalau kebetulan match CVE spesifik yang ke-tag "cve", BUKAN generic
    # SQLi pattern testing. Ini nutup gap Lapis 1, TAPI tetep cuma pola
    # umum/known pattern -- SQLi yang spesifik ke logic aplikasi target
    # (custom query, dst) tetep cuma ketemu lewat reasoning manual Fase 3,
    # bukan dari nuclei doang.
    tags = "cve,exposure,misconfig,default-login,sqli"

    if os.path.exists(recon_path):
        try:
            with open(recon_path, encoding="utf-8") as f:
                recon = json.load(f)
            if recon.get("is_wordpress"):
                tags += ",wordpress,wp-plugin"
                print("  WordPress kedeteksi dari recon -- tag wordpress ditambahin.")
        except Exception:
            pass

    cmd = [
        "nuclei", "-u", target,
        "-tags", tags,
        "-severity", "low,medium,high,critical",
        "-rl", "50",
        "-timeout", "10",
        "-jsonl",
        "-o", out_path,
        "-silent",
    ]

    try:
        subprocess.run(cmd, timeout=1800)  # 30 menit max, biar gak nyangkut selamanya kalau target lambat
    except subprocess.TimeoutExpired:
        print("  Nuclei timeout (>30 menit) -- hasil sebagian (kalau ada) tetep dipakai.")
    except Exception as e:
        print(f"  Nuclei gagal jalan: {e}")

    found = 0
    if os.path.exists(out_path):
        with open(out_path, encoding="utf-8") as f:
            found = sum(1 for line in f if line.strip())

    print(f"== Nuclei selesai, {found} temuan mentah (blm dipisah Terkonfirmasi/Dugaan) tersimpen di {out_path} ==")
    print("CATATAN: hasil nuclei ini WAJIB direview ulang di Fase 3 sebelum masuk")
    print("laporan final -- nuclei kadang false-positive, dan severity-nya perlu")
    print("di-cross-check ke severity-rubric.md (nuclei gak ngerti konteks bisnis).")


if __name__ == "__main__":
    main()
