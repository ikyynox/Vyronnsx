#!/usr/bin/env python3
"""
serve_report.py <path-ke-pdf> [--port 8000] [--minutes 15]

Fase 4b (opsional): serve 1 file PDF report lewat HTTP sementara biar bisa
didownload dari HP/device lain -- skenario umum: skill ini dijalanin di
VPS lewat SSH-only client (JuiceSSH dkk) yang gak punya fitur transfer
file bawaan.

KENAPA GAK PAKAI `python -m http.server` POLOS:
report ini isinya DATA SENSITIF (URL admin panel, payload eksploitasi,
request/response asli) -- `http.server` polos nge-serve SELURUH folder
dengan directory listing, siapa pun yang tau IP:port bisa liat SEMUA
report yang pernah dibikin. Script ini sebagai gantinya:
1. Cuma serve SATU file spesifik yang dikasih di argumen (bukan folder)
2. URL-nya ada TOKEN ACAK (gak predictable, mustahil ditebak)
3. OTOMATIS MATI SENDIRI setelah N menit (default 15) -- gak akan
   ketinggalan nyala lupa dimatiin
4. Selain path token yang bener, semua request lain dibales 404 polos
   (gak ngasih tau ada apa di balik itu)

Ini mitigasi, BUKAN keamanan sempurna -- selama server nyala & token
belum expired, siapa pun yang KEBETULAN tau/nebak URL lengkapnya tetep
bisa akses. Download secepatnya, biarin auto-expire ngerjain sisanya.
"""
import sys
import os
import http.server
import socketserver
import secrets
import threading
import urllib.request
import socket


def detect_public_ip(timeout=5):
    """VPS biasanya punya public IP langsung di interface-nya, tapi gak
    ada cara 100% reliable buat tau itu dari DALEM box tanpa nanya ke
    layanan eksternal (bisa aja di balik NAT/load balancer). Coba 2
    layanan echo-IP publik yang simple, fallback None kalau dua2nya gagal
    (misal network egress dibatesin) -- user tinggal pake IP yang mereka
    udah tau dari dashboard provider."""
    for url in ("https://api.ipify.org", "https://ifconfig.me/ip"):
        try:
            with urllib.request.urlopen(url, timeout=timeout) as resp:
                ip = resp.read().decode().strip()
                if ip:
                    return ip
        except Exception:
            continue
    return None


def make_handler(token, filepath):
    filename = os.path.basename(filepath)
    expected_path = f"/{token}/{filename}"

    class SingleFileHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path != expected_path:
                self.send_response(404)
                self.end_headers()
                return
            try:
                with open(filepath, "rb") as f:
                    data = f.read()
            except Exception:
                self.send_response(500)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/pdf")
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, fmt, *args):
            pass  # senyapin access log default biar output bersih

    return SingleFileHandler


def main():
    args = sys.argv[1:]
    if not args or args[0].startswith("--"):
        print("Usage: serve_report.py <path-ke-pdf> [--port 8000] [--minutes 15]")
        sys.exit(1)

    filepath = args[0]
    if not os.path.isfile(filepath):
        print(f"ERROR: file gak ketemu: {filepath}")
        sys.exit(1)

    port = 8000
    minutes = 15
    if "--port" in args:
        port = int(args[args.index("--port") + 1])
    if "--minutes" in args:
        minutes = float(args[args.index("--minutes") + 1])

    token = secrets.token_urlsafe(16)
    filename = os.path.basename(filepath)

    httpd = socketserver.TCPServer(("0.0.0.0", port), make_handler(token, filepath))

    def shutdown_later():
        httpd.shutdown()

    timer = threading.Timer(minutes * 60, shutdown_later)
    timer.daemon = True
    timer.start()

    public_ip = detect_public_ip()
    url_host = public_ip if public_ip else "<IP-VPS-LO>"
    full_url = f"http://{url_host}:{port}/{token}/{filename}"

    print("== Serve report sementara ==")
    if not public_ip:
        print("  (gak bisa auto-deteksi public IP -- pakai IP VPS yang udah lo tau dari dashboard provider)")
    print(f"  URL: {full_url}")
    print(f"  Auto-mati dalam {minutes} menit, atau Ctrl+C buat matiin sekarang.")
    print("  CATATAN: kalau ada firewall/Cloud Firewall (DigitalOcean/Linode dkk),")
    print(f"  pastiin port {port} ke-allow dulu buat inbound TCP.")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        timer.cancel()
        httpd.server_close()
        print("\n  Server dimatiin.")


if __name__ == "__main__":
    main()
