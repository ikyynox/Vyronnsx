# Checklist Kategori Kerentanan (live testing)

Ini daftar KATEGORI yang harus tercover di Fase 2+3, bukan checklist
payload siap-pakai. Dipakai buat mastiin coverage luas (universal, gak
cuma SQLi/XSS doang) — cara nguji tiap kategori tetep ikutin prinsip
Lapis 2 di methodology.md, react ke kondisi yang beneran ditemuin, bukan
jalanin payload generik buta.

## Injection
- SQL injection (error-based, boolean-blind, time-based)
- NoSQL injection (kalau backend pakai MongoDB dkk)
- Command injection (kalau ada fitur yang keliatan manggil sistem/shell)
- LDAP/XPath injection (kalau relevan sama stack yang kedeteksi)
- Server-Side Template Injection (SSTI) — cek kalau ada fitur render
  template dinamis (nama, custom message, dll)

## Cross-Site Scripting (XSS)
- Reflected — input di URL/parameter dipantulin balik ke halaman
- Stored — input tersimpan (komentar, profil, dll) muncul lagi ke user lain
- DOM-based — cek client-side JS yang proses input tanpa sanitasi

## Broken Authentication
- Brute-force protection (rate limiting di login, cek beneran ada)
- Password policy lemah
- Session fixation / session token gak di-regenerate abis login
- "Remember me" / token persistent yang gak aman
- Multi-factor bypass (kalau ada MFA, cek apakah bisa dilewatin)
- **JWT/token security** (kalau auth-nya pakai JWT, makin umum di API/SPA):
  - Coba ganti algoritma di header JWT jadi `none` (`alg: none`), hapus
    signature-nya — cek apakah server tetep nerima token itu sebagai valid
  - Coba brute-force/tebak secret key kalau algoritmanya HS256 (symmetric)
    dan keliatan secret-nya lemah/predictable
  - Cek apakah token expired beneran ditolak, atau cuma dicek expiry-nya
    di client doang
  - Cek apakah ada mekanisme revoke token pas logout, atau token lama
    tetep valid sampai expired walau user udah "logout"
  - Decode payload JWT (base64 doang, bukan terenkripsi) — cek ada data
    sensitif yang ke-expose di situ (bukan buat exploit, tapi indikasi
    data leakage)

## Broken Access Control
- IDOR (Insecure Direct Object Reference) — ganti ID di URL/parameter,
  cek apakah bisa akses data user lain
- Privilege escalation (user biasa akses fungsi admin)
- Path traversal (`../../`, dll di parameter file/path)
- Forced browsing ke endpoint yang harusnya butuh auth

## Security Misconfiguration
- Header security kurang (CSP, X-Frame-Options, HSTS, dll)
- Directory listing aktif
- Default credential masih aktif (admin/admin, dll)
- Error message expose stack trace/informasi internal
- CORS misconfiguration (`Access-Control-Allow-Origin: *` di endpoint
  sensitif/butuh auth)

## Sensitive Data Exposure
- File exposed: `.env`, `.git/`, backup file (`.sql`, `.zip`, `.bak`),
  config file
- Data sensitif di response yang harusnya di-filter (password hash, token
  internal, dll ke-include di JSON response padahal gak dipakai frontend)
- Transmisi data sensitif tanpa enkripsi (HTTP bukan HTTPS di form
  sensitif)

## SSRF (Server-Side Request Forgery)
- Fitur yang nerima URL dari user (fetch preview, import dari URL, webhook
  config) — coba arahin ke internal address (`127.0.0.1`, `169.254.169.254`
  buat cloud metadata, dll)

## Insecure Deserialization
- Cek format data yang dipakai (kalau ada serialized object/token custom),
  apakah bisa dimanipulasi buat eksekusi kode

## File Upload
- Validasi tipe file (server-side, bukan cuma client)
- Path/nama file hasil upload bisa dimanipulasi (path traversal lewat nama
  file)
- File yang di-upload bisa dieksekusi langsung (misal upload .php ke
  folder yang web-accessible)

## Business Logic
- Kategori ini SANGAT kontekstual, gak bisa di-template-in generik — lihat
  references/payment-gaming-checks.md untuk target transaksional
- Step yang bisa di-skip di alur multi-step (checkout, registrasi, dll)
- Validasi cuma di client, gak di-cross-check di server

## Rate Limiting & DoS
- Endpoint yang berat (search, export, dll) tanpa rate limit
- Account lockout / OTP request tanpa limit (bisa dipakai spam ke user lain)

## Third-Party / Supply Chain
- Library/dependency dengan CVE dikenal (bagian ini dicover otomatis di
  Fase 2 lewat nuclei, tapi worth di-double-check manual kalau tech stack
  kedeteksi pakai versi lama)
- CDN/script eksternal yang di-load tanpa Subresource Integrity (SRI)

## Port & service (dari Fase 1 recon)
- Service yang harusnya cuma internal tapi ke-expose publik (database,
  Redis, admin panel di port non-standar, dll)
- Service dengan versi lama yang ada CVE dikenal
