# Checklist Khusus: Website Top-Up / Payment Gaming

Kategori ini SERING kelewat sama scanner generik (nuclei dkk) karena
sifatnya business logic, bukan pola teknis yang bisa di-template-in.
Prioritas TINGGI kalau target-nya transaksional. Ini panduan AREA yang
harus dieksplorasi, bukan payload siap-pakai — cara nyobanya ikutin
prinsip Lapis 2 di methodology.md (observasi -> adaptasi).

## 1. Manipulasi harga/nominal

Cek apakah validasi harga/jumlah top-up beneran di server, atau cuma di
client (JS)/hidden field.

Area yang perlu dicoba (react ke apa yang beneran diliat di request):
- Ubah field harga di request (kalau ada) jadi nilai lebih kecil dari yang
  seharusnya, cek apakah server tetep proses pakai harga yang dikirim
  client atau re-validasi ke harga asli di database
- Angka negatif di field amount/quantity/price
- Angka desimal kecil (0.001, dst) — nyari celah rounding/floating-point
- Angka sangat besar (integer overflow) — cek apakah ada batas atas yang
  divalidasi
- Ubah currency/mata uang kalau ada opsi multi-currency (exploit selisih
  kurs yang gak ke-refresh real-time)
- Ubah ID produk/paket tapi harga di request tetep yang lama (race
  antara pilih paket A harga rendah, kirim ID paket B yang lebih mahal)

## 2. Race condition di saldo/wallet

Kirim beberapa request top-up/transaksi SECARA BERSAMAAN (concurrent, bukan
berurutan) ke endpoint yang sama, cek apakah saldo ke-update lebih dari
yang seharusnya (indikasi gak ada locking/transaction isolation yang
bener di server).

CATATAN SAFETY: ini kategori paling gampang numpuk data sampah/transaksi
ganda di production. Kalau mode --allow-mutating OFF, cukup dokumentasiin
sebagai "perlu diuji manual di staging", JANGAN dieksekusi ke production
tanpa mode itu eksplisit ON.

## 3. Verifikasi signature webhook payment gateway

Kalau ada endpoint webhook (biasanya `/webhook`, `/callback`,
`/notification` dari payment gateway) — cek:
- Apakah endpoint itu beneran verifikasi signature/HMAC dari payment
  gateway, atau nerima payload apa pun tanpa validasi
- Coba kirim payload webhook palsu (status "paid"/"success") TANPA
  signature yang valid, lihat apakah diproses sebagai pembayaran sukses
- Kalau ada signature check, coba tebak/manipulasi apakah bisa dilewatin
  (misal signature dari algoritma lemah, atau secret key yang predictable)

Ini salah satu kategori PALING FATAL buat website top-up — kalau tembus,
artinya siapa pun bisa "bayar" tanpa beneran transfer duit.

## 4. IDOR (Insecure Direct Object Reference) di transaksi

- Login/dapet akun test, buat 1 transaksi, catat ID transaksinya
- Coba akses/ubah detail transaksi pakai ID lain (transaksi user lain)
  lewat parameter URL/body yang keliatan predictable (angka urut, dst)
- Cek endpoint riwayat transaksi, invoice, status pembayaran — apakah
  otorisasinya bener-bener cek "ini transaksi milik user yang login" atau
  cuma cek "user ini login" (tanpa cek kepemilikan)

## 5. Abuse kode promo/voucher

- Coba pakai kode promo yang sama berkali-kali (cek rate-limit/one-time-use
  beneran ditegakkan di server)
- Coba kombinasi promo yang seharusnya gak bisa digabung
- Kalau ada sistem referral/cashback, cek apakah bisa dipakai buat
  self-referral atau nominal yang gak wajar

## 6. Validasi status transaksi di sisi client vs server

- Cek apakah halaman "sukses" bisa diakses langsung (ubah URL/parameter)
  tanpa transaksi beneran selesai — indikasi status ditentuin di
  client-side redirect, bukan dicek ulang ke server tiap render halaman

## Format laporan khusus kategori ini

Karena dampaknya finansial langsung, tiap temuan di kategori ini WAJIB
(selain 3 komponen bukti standar di evidence-rules.md) juga sertain:
- Estimasi dampak finansial konkret (kalau dieksploitasi berulang, potensi
  kerugian per-transaksi x seberapa gampang di-otomatisasi)
- Severity default minimal High untuk kategori 1-3, kecuali ada mitigasi
  lain yang kebukti (misal ada reconciliation manual harian yang bakal
  nangkep anomali — sebutin kalau itu diketahui, tapi tetep gak
  ngurangin severity teknisnya)
