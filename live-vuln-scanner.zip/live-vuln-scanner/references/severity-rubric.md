# Rubrik Severity

Dipakai konsisten buat semua temuan kategori "Terkonfirmasi" (temuan
kategori "Dugaan" gak dikasih severity pasti, lihat evidence-rules.md).

## Critical
- Bisa akses/ubah data user LAIN secara luas (bukan cuma 1 user spesifik)
  tanpa auth atau dengan bypass auth
- Bisa eksekusi kode di server (RCE)
- Bisa manipulasi transaksi finansial (bayar tanpa transfer beneran,
  webhook signature bypass, dll) — payment/top-up context
- Credential/secret admin ke-expose (bisa dipakai full takeover)

## High
- SQL injection / NoSQL injection yang kebukti (walau scope terbatas)
- IDOR yang expose data sensitif user lain (PII, riwayat transaksi, dll)
- Auth bypass ke fungsi admin/privileged
- Stored XSS yang bisa kena ke user lain (bukan cuma reflected ke diri
  sendiri)
- Manipulasi harga/nominal yang kebukti jalan (payment context)

## Medium
- Reflected XSS
- CSRF di aksi yang berdampak (ubah data, bukan cuma preference kosmetik)
- Informasi sensitif ke-expose tapi butuh kondisi spesifik buat
  dieksploitasi (misal butuh tau ID valid dulu)
- Security header kurang di halaman yang handle data sensitif
- Rate limiting gak ada di endpoint yang bisa disalahgunakan (tapi dampak
  terbatas, bukan langsung finansial)

## Low
- Informasi non-sensitif ke-expose (versi software, dll) yang mempermudah
  reconnaissance lanjutan tapi gak langsung exploitable
- Security header kurang di halaman non-sensitif
- Best practice gak diikutin tapi gak ada exploit path jelas

## Informational
- Observasi yang worth dicatat tapi bukan kerentanan per se (misal:
  praktik yang oke sekarang tapi berpotensi masalah kalau scope berubah)

## Aturan tambahan

- Severity dari nuclei/scanner Tier 1 BOLEH dipakai sebagai starting
  point, tapi AI tetap harus review ulang — scanner sering over/under-rate
  karena gak ngerti konteks bisnis (misal: nuclei kasih "info" ke endpoint
  yang ternyata expose data transaksi, padahal konteksnya harusnya High).
- Kalau ragu antara 2 level severity, pilih yang LEBIH RENDAH kecuali ada
  bukti dampak konkret buat level yang lebih tinggi (sama prinsipnya kayak
  evidence-rules.md: under-claim lebih aman daripada over-claim).
