# Checklist Khusus: API Endpoint (REST/GraphQL)

PENTING: kategori ini SENGAJA gak cuma "coba endpoint yang umum kayak
/api/users" (itu pola generik, gampang ketauan). Fokusnya eksplorasi
AKTIF ke struktur API SPESIFIK target ini — baca dulu gimana API-nya
didesain (dari Fase 1 recon + respons yang kelihatan), baru react ke
pola yang kedeteksi. Banyak API modern (SPA, mobile backend, dsb) justru
SELURUH permukaan seranganya ada di sini, bukan di halaman web biasa.

## 0. Peta dulu sebelum nyoba — jangan tebak endpoint secara acak

- Buka DevTools/baca response HTML-nya: cari file JS yang nge-fetch ke
  `/api/`, `/graphql`, `/v1/`, `/v2/`, dst — API client-side biasanya
  ngasih tau semua endpoint yang dipake lewat bundle JS-nya
  (`main.*.js`, dsb berisi path endpoint kalau gak di-minify ekstrem)
- Cek ada dokumentasi API yang ke-expose gak sengaja: `/swagger`,
  `/swagger.json`, `/api-docs`, `/openapi.json`, `/redoc`, `/.well-known/`
  — kalau ketemu, itu peta LENGKAP semua endpoint + parameter yang
  diterima, gak perlu nebak-nebak lagi
- Kalau GraphQL: cek apakah introspection query (`__schema`) masih
  aktif — kalau iya, itu dump lengkap semua type/field/mutation yang ada,
  termasuk yang harusnya "tersembunyi" dari UI

## 1. BOLA (Broken Object Level Authorization) — paling sering & paling fatal

Beda sama IDOR di halaman web biasa, di API ini lebih gampang luput
karena developer cenderung mikir "yang penting user login" tanpa cek ulang
tiap endpoint.

- Login 2 akun test beda, ambil ID resource (order, profile, dokumen,
  pesan, dll) dari akun A, coba akses/ubah lewat akun B pake ID itu
- Cek SEMUA HTTP method per endpoint, bukan cuma GET — kadang GET
  `/api/orders/123` udah dicek otorisasinya tapi PATCH/DELETE
  `/api/orders/123` kelupaan
- Kalau ID-nya UUID (keliatan "aman" karena gak predictable) — cek
  apakah UUID itu bocor di tempat lain (response list endpoint,
  notifikasi, URL yang di-share), karena UUID doang bukan access control

## 2. Broken Function Level Authorization

- Endpoint admin/internal yang cuma "disembunyiin" dari UI biasa (gak
  ada link-nya di frontend) tapi backend-nya tetep nerima request kalau
  tau path-nya — cek dari peta di langkah 0 (bundle JS seringkali tetep
  nyertain kode buat fitur admin walau UI-nya disembunyiin dari user
  biasa)
- Ganti role/permission di request body kalau ada field kayak `role`,
  `isAdmin`, `permissions` yang dikirim DARI CLIENT — cek apakah server
  percaya field itu atau re-validasi dari session/database

## 3. Mass Assignment

- Endpoint update profile/resource — coba kirim field EKSTRA yang gak
  ada di form aslinya (`role: "admin"`, `isVerified: true`,
  `balance: 999999`, `price: 0`) di body request, cek apakah server
  nerima & nyimpen field yang gak diminta itu (indikasi backend langsung
  `bind`/`assign` semua field dari request tanpa whitelist)

## 4. Excessive Data Exposure

- Bandingin field yang BENERAN dipake di UI vs field yang ADA di response
  JSON — API sering balikin seluruh object dari database (termasuk
  password hash, token internal, data user lain yang ketempel di
  nested object) padahal frontend cuma pake 3 field doang
- Ini KHUSUSNYA relevan di endpoint list/search yang nested-include
  related object (misal `/api/orders` include full `user` object di
  tiap item, padahal cuma butuh nama doang)

## 5. Rate Limiting per-endpoint (beda dari login brute-force di checklist.md)

- Endpoint yang mahal secara komputasi (search, export, generate report,
  resend OTP/email) — cek apakah ada limit SPESIFIK di endpoint itu,
  jangan asumsi rate-limit global di level gateway udah cukup
- Endpoint yang nerima ID buat lookup (misal cek status order by ID) —
  tanpa rate limit, bisa dipake enumerasi ID yang valid satu-satu

## 6. Mass/bulk endpoint yang gak konsisten validasinya

- Kalau ada endpoint versi "bulk" (`/api/orders/bulk-update`,
  `/api/users/import`, dst) — cek apakah validasi per-item di dalam
  bulk request SEKETAT validasi endpoint single-nya, developer sering
  lebih longgar di jalur bulk karena fokusnya ke performance

## 7. Versioning & API lama yang masih aktif

- Kalau API-nya versioned (`/v1/`, `/v2/`), coba akses versi LAMA yang
  harusnya udah deprecated — sering kali v1 masih aktif di server tapi
  validasinya belum di-patch sama kayak v2 (improper assets management)

## 8. Khusus GraphQL (kalau kedeteksi)

- Query batching / alias — satu request HTTP bisa isi puluhan query
  sekaligus (lewat alias), ini bisa dipake bypass rate-limit yang
  ngitung per-request HTTP, bukan per-query
- Query depth yang gak dibatesin (nested relasi berulang) — potensi DoS
  sekaligus kadang nge-expose data lewat relasi yang gak sengaja
  accessible (user -> posts -> author -> private_field)
- Error message GraphQL default suka verbose banget (expose nama field
  internal, struktur schema) — cek apakah error handling custom atau
  masih default development mode

## Format laporan

Sama kayak kategori lain — WAJIB evidence-rules.md (request+response
nyata). Untuk BOLA/mass assignment, sertain di `explanation` perbandingan
EKSPLISIT: apa yang SEHARUSNYA kejadian (ditolak) vs apa yang BENERAN
kejadian (diterima/diproses) di response yang dikutip.
