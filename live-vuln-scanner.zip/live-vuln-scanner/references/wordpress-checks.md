# Checklist Khusus: WordPress

PENTING: kategori ini SENGAJA gak cuma "cek versi WP/plugin terus cocokin
ke database CVE publik" (itu udah dikerjain otomatis sama nuclei di Fase 2
dengan template wordpress/). Bagian ini fokus ke eksplorasi AKTIF yang gak
akan pernah ketemu scanner CVE-matching, karena sifatnya kontekstual ke
instalasi spesifik ini (plugin custom, konfigurasi salah, dll yang gak ada
di database publik manapun).

## 1. REST API exposure (WAJIB dicek, ini yang paling sering kelewat)

WordPress modern expose REST API di `/wp-json/`. Banyak instalasi lupa
restrict endpoint yang harusnya butuh auth.

- Akses `/wp-json/wp/v2/users` — kalau balik daftar user LENGKAP (bukan
  cuma yang publish post), itu user enumeration yang bisa dipakai buat
  brute-force login lebih presisi
- Cek endpoint custom dari plugin yang keinstall (bukan cuma endpoint
  core WP) — plugin custom sering bikin REST endpoint sendiri TANPA
  permission_callback yang bener (bug WordPress plugin paling umum:
  register_rest_route tanpa cek capability)
- Coba akses `/wp-json/` root, liat daftar SEMUA namespace endpoint yang
  ke-register — ini nunjukin plugin apa aja yang bikin API sendiri, jadi
  peta buat dieksplorasi satu-satu

## 2. xmlrpc.php abuse

- Cek apakah `/xmlrpc.php` masih aktif (harusnya di-disable kalau gak
  dipakai)
- Kalau aktif, ini bisa dipakai buat brute-force login yang bypass
  rate-limiting normal (system.multicall bisa coba ratusan password
  dalam SATU request HTTP)
- Cek juga apakah bisa dipakai buat amplifikasi DDoS (pingback ke situs
  lain)

## 3. Fingerprint plugin/tema yang JARANG (bukan yang populer)

Plugin populer (WooCommerce, Yoast, dll) udah pasti ke-cover database CVE
nuclei. Yang perlu perhatian ekstra itu plugin CUSTOM atau yang jarang
dipakai (dev internal, freelancer, dll) — biasanya:
- Cari file `readme.txt` di tiap folder `/wp-content/plugins/<nama>/` yang
  kedeteksi, baca versi + author-nya
- Kalau ada plugin yang keliatan custom-built (nama gak umum, author bukan
  nama besar) — INI yang harus dieksplorasi manual lebih dalam (parameter
  apa yang diterima, ada form/AJAX handler apa), karena gak ada siapa pun
  yang udah pernah nge-report CVE buat plugin ini

## 4. AJAX handler exposure

WordPress pakai `/wp-admin/admin-ajax.php` buat banyak fungsi, termasuk
dari plugin custom. Action yang di-register lewat `wp_ajax_nopriv_*`
sengaja bisa diakses TANPA login — cek apakah ada action nopriv yang
harusnya butuh auth tapi lupa dicek ulang di dalam handler-nya (common bug:
developer pikir "nopriv" cuma buat guest checkout dll, padahal action-nya
sensitif kayak ubah data).

## 5. File upload & permission

- Cek `/wp-content/uploads/` — apakah listing folder ke-enable (bisa liat
  semua file yang pernah di-upload)
- Kalau ada form upload (dari plugin custom/tema), cek validasi tipe file
  di server (bukan cuma di JS) — coba upload file dengan ekstensi ganda
  atau MIME type yang dipalsuin
- Cek permission file `wp-config.php` kalau somehow accessible (harusnya
  gak pernah bisa diakses lewat HTTP sama sekali)

## 6. User enumeration di luar REST API

- `/?author=1`, `/?author=2`, dst — WordPress default redirect ke halaman
  author, URL-nya biasanya kebaca username asli, dipakai enumerasi tanpa
  butuh REST API sama sekali
- Login error message — cek apakah beda pesan antara "username salah" vs
  "password salah" (kalau beda, itu bisa dipakai enumerasi user valid)

## 7. Konfigurasi khusus instalasi ini

Ini yang paling "gak generic" — liat SPESIFIK gimana WordPress ini
dipasang & disesuaikan, jangan asumsi instalasi default:
- Ada integrasi custom ke sistem lain (payment gateway, API eksternal)?
  Kalau ya, plugin/kode yang nyambungin itu WAJIB dicek manual (ini
  hampir pasti custom-built, gak ada CVE publik)
- Tema custom (bukan tema marketplace umum)? Cek functions.php-nya kalau
  somehow accessible, atau cek AJAX/REST endpoint yang didaftarin dari situ

## Format laporan

Sama kayak kategori lain — WAJIB evidence-rules.md (request+response
nyata). Untuk temuan REST API/AJAX exposure, sertain juga: apakah data
yang ke-expose itu sensitif (PII, kredensial, dll) atau cuma metadata
biasa — ini nentuin severity-nya.
