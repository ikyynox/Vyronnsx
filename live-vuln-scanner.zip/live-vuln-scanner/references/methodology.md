# Metodologi

## Filosofi 2 lapis

**Lapis 1 (scanner otomatis)** — breadth, cepet, nutupin kerentanan yang
udah terdokumentasi luas (CVE, misconfig umum, exposed file). Dikerjain
scripts/, deterministic, sama hasilnya tiap dijalanin ke kondisi yang sama.

**Lapis 2 (AI reasoning aktif)** — ini yang bikin hasilnya gak jadi
checklist statis yang sama ke semua website. AI baca hasil Lapis 1, terus
REACT ke kondisi spesifik yang ditemuin, bukan jalanin daftar payload
generik buta ke semua endpoint.

Contoh alur Lapis 2 (bukan resep tetap, ilustrasi cara mikir):
```
AI liat endpoint /api/topup terima parameter "amount"
    -> coba amount=-1000 (react ke NAMA parameter yang dilihat sendiri)
    -> response: "amount must be positive" (ada validasi)
    -> AI mikir: validasi angka negatif ada, kemungkinan ada validasi lain
    -> ganti pendekatan: coba amount=0.001 (desimal kecil, kategori beda
       dari validasi negative-number tadi -- nyari celah rounding)
    -> response: sukses, tapi saldo nambah lebih dari yang dibayar
    -> INI baru jadi temuan -- karena ada bukti nyata, bukan karena
       "amount=0.001" ada di payload library manapun
```

Urutannya: **kondisi website -> observasi -> AI nentuin langkah
selanjutnya berdasarkan hasil observasi**. Tiap website beda hasil
eksplorasinya karena kondisinya beda-beda.

Payload boleh dari references/payload-library.md (starting point, baseline
coverage cepat) ATAU improvisasi AI di tempat (react ke kondisi spesifik).
Dua-duanya sah dipakai buat NYOBA. Yang gak boleh cuma satu: laporan tanpa
bukti nyata (lihat evidence-rules.md, WAJIB dibaca terpisah).

## Fase kerja

### Fase 0 — Setup & konfirmasi safety
1. Konfirmasi target URL ke user, dan ini domain milik user sendiri.
2. Tanya (kalau belum dikasih tau di prompt) apakah mode `--allow-mutating`
   diaktifkan. Default: OFF (read-only/non-destruktif).
   - Mode OFF: semua probing berhenti sebelum titik yang bisa BENERAN
     ngubah data production (submit transaksi asli, checkout beneran,
     dll). Boleh tetap kirim request yang formatnya "kayak" transaksi
     (buat lihat validasi/response), tapi hindari yang bakal kepastian
     approve/ke-charge/ke-catat sebagai order sungguhan.
   - Mode ON: user udah sadar resikonya (bisa numpuk data sampah di DB
     production, atau ke-trigger sistem anti-fraud sendiri).
3. Buat folder reports/ kalau belum ada.

### Fase 1 — Recon
Jalanin `scripts/recon.py <target>`. Ini ngerjain:
- Port scan (nmap kalau ada, fallback python socket scan)
- Fingerprint tech stack (header, meta generator, favicon hash)
- Deteksi CMS (khususnya WordPress -- kalau kedeteksi, baca
  references/wordpress-checks.md SEBELUM lanjut Fase 2 buat area itu)
- Simpen hasil recon ke reports/<target>_recon.json, dipakai fase
  berikutnya biar gak scan ulang dari nol

### Fase 2 — Scanning otomatis (Lapis 1)
Jalanin `scripts/run_nuclei.py <target>` (CVE, exposure, misconfig
templates) dan `scripts/check_tls.py <target>` (SSL/TLS issues). Simpen
raw output ke reports/<target>_nuclei.json dan reports/<target>_tls.json.

Baca references/checklist.md buat kategori kerentanan yang harus tercover
di fase ini (dipakai buat mastiin gak ada kategori besar yang kelewat,
bukan checklist payload).

### Fase 3 — AI reasoning aktif (Lapis 2)
Ini fase INTI, gak bisa di-scriptkan penuh karena butuh reasoning adaptif.
Fase ini WAJIB dikerjain 2 tahap BERURUTAN -- 3b TIDAK BOLEH mulai
sebelum 3a kelar. Alasannya: tanpa urutan ini, AI gampang kebawa
eksplorasi kreatif yang "seru" duluan dan kelewat kategori dasar yang
justru lebih sering jadi penyebab breach nyata (IDOR, misconfig, dll).
Kreativitas itu BONUS di atas fondasi yang solid, bukan pengganti.

**Fase 3a — Checklist coverage (WAJIB, GATE, dikerjain DULUAN)**
1. Baca semua hasil Fase 1+2.
2. Buat tiap endpoint/parameter yang menarik (nerima input user, ada di
   flow transaksi/auth/upload, dll), lakuin siklus:
   observasi -> hipotesis -> coba -> baca response -> adaptasi -> ulang
3. Kerjain SEMUA 13 kategori di references/checklist.md -- lihat GATE
   WAJIB di SKILL.md. Tiap kategori WAJIB berakhir di confirmed_findings,
   suspected_findings, ATAU not_tested (dengan alasan jujur) sebelum
   lanjut ke 3b.
4. KHUSUS kalau target-nya website top-up/payment (cek dulu
   references/payment-gaming-checks.md) -- kategori ini priority tinggi,
   jangan di-skip walau Fase 1+2 gak nemu apa-apa di situ.
5. KHUSUS kalau WordPress kedeteksi di Fase 1 -- baca
   references/wordpress-checks.md, JANGAN cuma andelin CVE matching dari
   nuclei.
6. KHUSUS kalau ada permukaan API -- baca references/api-checks.md.

**Fase 3b — Eksplorasi bebas DI LUAR checklist.md (opsional tapi
dianjurkan, HANYA SETELAH 3a kelar)**
Checklist.md itu universal -- gak mungkin nyertain kerentanan yang
SPESIFIK ke desain aneh/unik aplikasi target ini. Di tahap ini, mikir
bebas kayak attacker beneran yang udah paham aplikasinya (dari hasil 3a):
- Ada fitur/alur yang KELIATAN JANGGAL/gak biasa dari aplikasi lain
  sejenis? (flow approval custom, sistem poin/reward unik, integrasi
  antar-modul yang gak lazim) -- itu kandidat kuat buat dieksplorasi,
  karena kemungkinan besar belum pernah "dipikirin" developernya dari
  sudut pandang attacker
- Ada 2+ fitur yang KALAU DIGABUNG bisa jadi masalah, padahal
  masing-masing sendiri-sendiri aman? (chaining -- misal fitur A bocorin
  info kecil yang gak dianggap sensitif, fitur B butuh info itu buat
  bypass sesuatu)
- Pola error/response aneh yang kelihat pas Fase 1-3a tapi belum
  dieksplorasi penuh karena gak masuk kategori manapun di checklist.md
- Boleh pakai web search buat riset arsitektur/tech stack yang kedeteksi,
  cari tau kelemahan desain yang dikenal di komunitas security buat
  pola serupa (BUKAN buat laporan langsung, cuma buat ngarahin hipotesis
  -- aturan evidence-rules.md tetap berlaku penuh)
- SEMUA temuan dari tahap ini tetap WAJIB evidence-rules.md -- kreatif di
  cara nyari, tapi gak ada pengecualian di cara ngelaporin

7. Manfaatin web search (kalau tersedia di setup ini) buat riset
   tambahan selama investigasi (berlaku di 3a maupun 3b) -- contoh
   kegunaan sah: cek apakah versi plugin/software yang kedeteksi ada CVE
   publik yang belum tercover nuclei template, cari tau arti error
   message spesifik yang jarang ditemuin, cek advisory terbaru buat
   CMS/framework yang kedeteksi.
   INGAT: hasil web search itu KONTEKS BUAT NGARAHIN investigasi, BUKAN
   bukti buat laporan -- klaim di laporan tetap wajib nempel ke
   request+response nyata yang beneran dicoba di sesi ini sendiri (lihat
   evidence-rules.md), bukan ke apa yang "kata artikel di internet".
8. Tiap kali mau nulis sesuatu ke laporan, cek ulang ke evidence-rules.md.

### Fase 4 — Generate laporan
1. Susun semua temuan (Terkonfirmasi + Dugaan, dipisah jelas, lihat
   evidence-rules.md) ke reports/<target>_findings.json mengikuti schema
   di scripts/generate_pdf.py bagian docstring.
2. Jalanin `python scripts/generate_pdf.py reports/<target>_findings.json`
3. PDF final ada di reports/<target>_<timestamp>.pdf -- kasih tau user
   path lengkapnya di akhir, jangan cuma bilang "sudah selesai".

## Batas yang harus dijaga

- Target HANYA domain yang eksplisit dikasih user. Jangan pernah nyasar
  scan ke domain lain meski ketemu link keluar pas crawling.
- Rate-limit request (jangan flood) -- kalau scripts/ punya opsi
  `--rate-limit`, pakai, jangan bikin efek DoS gak sengaja ke server
  sendiri.
- Kalau nemu sesuatu yang KELIHATAN kayak udah dieksploitasi orang lain
  (backdoor, webshell, user admin gak dikenal) -- STOP, laporin ke user
  segera SEBAGAI PRIORITAS, jangan lanjut scan biasa dulu.
