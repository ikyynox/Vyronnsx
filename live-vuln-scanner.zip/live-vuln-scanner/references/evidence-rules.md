# Aturan Bukti (WAJIB dibaca sebelum nulis temuan apa pun)

Ini aturan paling penting di seluruh skill ini. Laporan security yang isinya
karangan itu LEBIH BERBAHAYA daripada gak ada laporan sama sekali — bisa
bikin false confidence ke celah yang sebenernya masih ada, atau buang waktu
ngejar bug yang gak nyata. Baca ini SEBELUM nulis satu baris pun ke laporan.

## Aturan mutlak

Setiap temuan yang diklaim sebagai **"Terkonfirmasi"** WAJIB punya 3 komponen,
gak boleh kurang satu pun:

1. **Request mentah** — method, URL lengkap, header relevan, body (kalau
   ada). Bukan ringkasan, kutip PERSIS apa yang beneran dikirim.
2. **Response mentah** — status code, header relevan, potongan body yang
   relevan (kutip PERSIS, bukan parafrase). Kalau body panjang, kutip
   bagian yang relevan aja + jelasin di mana lokasinya (baris/field mana).
3. **Penjelasan yang eksplisit ngerujuk balik ke bukti itu** — bukan
   kesimpulan umum, tapi "response di atas nunjukin field X berubah jadi Y
   meski request gak nyertain parameter itu, ini indikasi Z".

## Dua kategori temuan, JANGAN dicampur

Setiap temuan di laporan HARUS masuk salah satu dari dua kategori ini,
ditandain jelas di judulnya:

### ✅ TERKONFIRMASI
- Ada bukti request+response nyata (3 komponen di atas, lengkap)
- Reproducible — orang lain bisa ulang langkah yang sama dan dapet hasil
  yang sama
- Severity boleh di-assign (Low/Medium/High/Critical, lihat
  severity-rubric.md)

### ⚠️ DUGAAN / PERLU VERIFIKASI MANUAL
- Ada indikasi mencurigakan (error message aneh, response time gak wajar,
  behavior yang beda dari ekspektasi) TAPI belum ada bukti definitif
- JANGAN di-assign severity pasti — tulis "berpotensi jadi [kategori],
  butuh verifikasi manual lebih lanjut"
- JANGAN pakai kata "ditemukan" atau "vulnerable" — pakai "terindikasi"
  atau "mencurigakan, worth diperiksa manusia"

Kalau ragu masuk kategori mana → **selalu turunin ke kategori Dugaan**.
Lebih baik under-claim (nanti manusia verifikasi, ternyata beneran bug)
daripada over-claim (manusia percaya, ternyata gak ada apa-apa, atau lebih
parah: manusia SKIP verifikasi manual karena udah "yakin" dari laporan AI).

## Larangan eksplisit

- **JANGAN PERNAH** nulis "kemungkinan ada SQL injection di endpoint ini"
  tanpa nunjukin payload yang beneran dikirim + response yang beneran
  balik. Dugaan tanpa pernah dicoba = gak boleh masuk laporan sama sekali
  (bukan kategori Dugaan, itu levelnya "gak dicoba" — kalau emang gak
  sempat dicoba, tulis di bagian "Belum sempat diuji" terpisah, bukan
  dicampur ke temuan).
- **JANGAN** generalisasi dari satu observasi ke klaim luas. Nemu satu
  endpoint yang gak validasi input bukan berarti "seluruh API gak ada
  validasi" — klaim itu scope-nya cuma ke endpoint yang beneran diuji.
- **JANGAN** kutip status code/response tanpa beneran ngirim request itu di
  sesi ini. Kalau ngutip hasil dari scanner Tier 1 (nuclei dll), tandain
  sumbernya ("dari hasil nuclei template X"), jangan diklaim seolah AI
  yang manual coba.
- **JANGAN** nulis rekomendasi perbaikan yang generik banget ("perbaiki
  validasi input") tanpa ngerujuk ke bug spesifik yang ditemuin + kasih
  contoh konkret sesuai tech stack yang kedeteksi.

## Soal payload: boleh improvisasi, laporan tetap harus berbasis bukti

AI BOLEH dan DIANJURIN improvisasi payload di luar yang ada di
references/payload-library.md — react ke kondisi yang beneran ditemuin
(lihat references/methodology.md bagian "Lapis 2"). Batasannya bukan di
mana asal payload-nya, tapi di laporan: payload apa pun sumbernya (dari
library atau improvisasi di tempat), begitu mau diklaim jadi temuan, tetap
WAJIB nempel ke request+response nyata yang beneran terjadi di sesi ini.

## Checklist self-review sebelum submit laporan

Sebelum generate_pdf.py dijalanin, baca ulang tiap temuan dan tanya:
- [ ] Ada request mentah yang dikutip persis?
- [ ] Ada response mentah yang dikutip persis?
- [ ] Penjelasan eksplisit ngerujuk ke bagian spesifik dari bukti itu?
- [ ] Kategori (Terkonfirmasi/Dugaan) udah bener sesuai kekuatan bukti?
- [ ] Severity match sama dampak nyata (bukan di-lebih-lebihin)?
- [ ] Rekomendasi perbaikan konkret & sesuai tech stack, bukan generik?

Kalau ada satu aja yang jawabannya "gak yakin" — turunin ke kategori Dugaan
atau pindahin ke "Belum sempat diuji", JANGAN dipaksain jadi temuan pasti.
