---
name: live-vuln-scanner
description: Actively scan a live website the user owns for security vulnerabilities (SQLi, XSS, IDOR, auth bypass, payment/business-logic flaws, WordPress-specific issues, exposed ports/services, etc), ranging from common to advanced, then generate a detailed evidence-based PDF report. Use whenever the user asks to scan, audit, pentest, or check for bugs/security holes in their own live website/domain by giving a URL.
license: MIT
---

# Live Website Vulnerability Scanner

Skill ini beda dari `security-audit` (yang buat review source code statis).
Skill ini AKTIF probing website yang lagi jalan (live URL) — kirim
request beneran, baca response beneran, cari kerentanan lewat kombinasi
scanner otomatis + reasoning AI adaptif.

**WAJIB baca `references/evidence-rules.md` SEBELUM nulis temuan apa pun.**
Ini aturan paling penting di skill ini — laporan tanpa bukti nyata dilarang
keras, lihat file itu buat detail lengkap kenapa dan gimana.

## Kapan skill ini dipakai

User kasih URL/domain + minta dicariin bug/celah keamanan di website itu.
Contoh trigger: "scan website gw", "cek celah keamanan di
domain.com", "cari bug di situs top-up gw".

## Sebelum mulai — safety check WAJIB

1. **Konfirmasi kepemilikan** — pastikan target ini domain milik user
   sendiri (skill ini gak boleh dipakai scan domain orang lain tanpa izin
   eksplisit yang jelas).
2. **Tanya mode mutating** kalau belum disebut di prompt user:
   - Default **OFF** (read-only) — semua probing berhenti sebelum titik
     yang bisa BENERAN ngubah data production (transaksi asli, checkout
     beneran selesai, dll)
   - User bisa eksplisit nyalain `--allow-mutating` kalau paham resikonya
     (bisa numpuk data sampah/test transaction di production)
3. **Cek & install dependency otomatis, JANGAN nunggu user setup manual.**
   Sebelum Fase 4, jalanin `python -c "import reportlab"` — kalau error
   (`ModuleNotFoundError`), langsung jalanin `pip install reportlab`
   sendiri (via shell tool yang sama kayak buat script lain), baru lanjut.
   Ini package standar, aman diinstall tanpa nanya konfirmasi user dulu.

   **Catatan Linux (Ubuntu 23.04+/24.04, Debian 12+):** distro ini nerapin
   PEP 668 ("externally-managed-environment") -- `pip install reportlab`
   polos bakal GAGAL dengan error itu. Kalau ketemu error ini, retry pakai
   `pip install reportlab --break-system-packages` (aman buat 1 package
   kecil & stabil kayak reportlab) ATAU bikin venv dulu
   (`python3 -m venv .venv && .venv/bin/pip install reportlab`, lalu pastiin
   script-script selanjutnya dipanggil pakai `.venv/bin/python`, bukan
   `python` sistem). Ubuntu 22.04/Windows/Mac gak kena isu ini, `pip install`
   biasa langsung jalan.
   Untuk `nuclei`/`nmap`/`testssl.sh` (opsional, ada fallback bawaan di
   script kalau gak ada) -- JANGAN auto-install tanpa nanya user dulu,
   soalnya itu instalasi lebih besar (binary terpisah, bukan cuma pip),
   biarin scripts/ jalan pakai fallback-nya kalau emang gak ada.
3. Baca `references/methodology.md` buat alur kerja lengkap 4 fase di
   bawah ini.

## Alur kerja (ringkas — detail penuh di references/methodology.md)

| Fase | Apa yang dikerjain | Tool |
|---|---|---|
| 0. Setup | Konfirmasi target + mode mutating | - |
| 1. Recon | Port scan (opsional full 1-65535 via `--full-ports`) + banner grabbing + fingerprint tech stack + security headers + subdomain enum (crt.sh, pasif) + indikasi subdomain takeover + path sensitif umum (.git/.env/backup) + robots.txt/sitemap.xml + SPF/DMARC + deteksi WordPress | `scripts/recon.py` |
| 2. Scan otomatis (Lapis 1) | CVE, exposure, misconfig, TLS issues (termasuk cipher suite lemah) — breadth, cepat | `scripts/run_nuclei.py`, `scripts/check_tls.py` |
| 3a. Reasoning — checklist (WAJIB) | Cover 13 kategori checklist.md, GATE sebelum lanjut | manual (agent reasoning) |
| 3b. Reasoning — eksplorasi bebas (SETELAH 3a) | Mikir kreatif DI LUAR checklist.md -- fitur unik/janggal, chaining antar-fitur, pola aneh yang kelihat tapi belum masuk kategori manapun | manual (agent reasoning) |
| 4. Laporan | Susun findings.json → PDF | `scripts/generate_pdf.py` |
| 4b. Serve link download (OPSIONAL, kalau diminta) | Serve PDF lewat HTTP sementara (token acak + auto-expire) buat didownload dari device lain (HP, dll) | `scripts/serve_report.py` |

**Fase 3 adalah inti skill ini** — baca `references/methodology.md` bagian
"Filosofi 2 lapis" buat paham gimana harusnya AI berpikir di fase ini
(observasi → hipotesis → coba → adaptasi, BUKAN jalanin payload generik
buta ke semua endpoint). Kalau target-nya website transaksional/top-up,
WAJIB baca `references/payment-gaming-checks.md` — kategori ini sering
kelewat scanner otomatis karena sifatnya business logic. Kalau WordPress
kedeteksi di Fase 1, WAJIB baca `references/wordpress-checks.md` — JANGAN
cuma andelin CVE matching dari nuclei. Kalau target-nya punya permukaan
API (SPA, mobile backend, endpoint `/api/`/`/graphql` kedeteksi di
Fase 1), WAJIB baca `references/api-checks.md` — kategori BOLA/mass
assignment/excessive data exposure ini SANGAT sering jadi celah paling
fatal di aplikasi modern, gak kalah penting dari XSS/SQLi klasik.

**Soal output baru di `recon.py`** (`exposed_sensitive_paths`,
`subdomain_takeover_indications`, `email_security`): ini SEMUA hasil
pasif, BUKAN temuan final — tetep WAJIB diproses lewat evidence-rules.md
di Fase 3. `exposed_sensitive_paths` yang kebuka (misal `.git/config`
bener-bener diakses & isinya kebaca) bisa langsung masuk
`confirmed_findings` (request+response-nya udah ada dari recon.py).
`subdomain_takeover_indications` WAJIB masuk `suspected_findings`
(ditandai DUGAAN di evidence-rules.md), JANGAN pernah diklaim pasti tanpa
verifikasi manual claim beneran. `email_security` (SPF/DMARC absen)
masuk kategori Security Misconfiguration, severity biasanya Low/Medium
kecuali ada indikasi domain ini sering jadi sasaran phishing.

### GATE WAJIB sebelum Fase 4 — anti-skip Fase 3

`references/checklist.md` punya 13 kategori top-level (Injection, XSS,
Broken Auth, Broken Access Control, Security Misconfiguration, Sensitive
Data Exposure, SSRF, Insecure Deserialization, File Upload, Business
Logic, Rate Limiting & DoS, Third-Party/Supply Chain, Port & Service).

**ATURAN:** tiap 1 dari 13 kategori itu WAJIB berakhir di salah satu dari
3 tempat ini di `findings.json` sebelum `generate_pdf.py` boleh dijalanin:
1. Muncul di `confirmed_findings` (ada bukti), ATAU
2. Muncul di `suspected_findings` (dugaan, perlu verifikasi manual), ATAU
3. Muncul di `not_tested` dengan `reason` yang JUJUR dan SPESIFIK — bukan
   alasan generik kayak "gak sempat" atau "di luar scope", tapi alasan
   teknis nyata (misal: "gak ada form input yang nerima data buat SSTI,
   semua halaman statis" atau "fitur file upload gak ada di aplikasi ini").

Kategori yang SAMA SEKALI gak disebut di salah satu dari 3 tempat itu
artinya Fase 3a di-skip diam-diam buat kategori itu — ini PELANGGARAN,
bukan opsional. Sebelum manggil `generate_pdf.py`, hitung ulang: 13
kategori di checklist.md vs yang ke-cover di findings.json, kalau ada yang
kurang, balik ke Fase 3a dulu buat kategori itu (minimal tulis alasan
`not_tested`-nya).

**Fase 3b baru boleh mulai SETELAH gate di atas kelar.** Ini bukan
opsi "kalau sempat" yang boleh ditukar urutannya sama 3a — alasannya
di `methodology.md`: kategori checklist (IDOR, misconfig, dll) secara
statistik lebih sering jadi penyebab breach nyata dibanding bug eksotis
hasil eksplorasi kreatif, jadi fondasinya WAJIB solid dulu sebelum
"having fun" nyari yang di luar daftar. Fase 3b gak punya GATE kuantitatif
kayak 3a (gak ada "jumlah minimal" temuan kreatif yang wajib) — tapi tetap
WAJIB dicoba, bukan dilewatin gitu aja, dan baca `methodology.md` bagian
"Fase 3b" buat cara mikirnya (fitur janggal, chaining antar-fitur, dll).

## Cara jalanin

```bash
# Fase 1
python scripts/recon.py <target-domain-or-url>
# Opsional: --full-ports buat scan SEMUA port 1-65535 (bukan cuma port
# umum). TANYA USER DULU sebelum pakai flag ini -- jauh lebih lama &
# lebih "berisik" secara jaringan, cuma relevan kalau dicurigai ada
# service tersembunyi di port non-standar:
#   python scripts/recon.py <target-domain-or-url> --full-ports

# Fase 2
python scripts/run_nuclei.py <target-url>
python scripts/check_tls.py <target-host>
# check_tls.py fallback (tanpa testssl.sh) udah include cek cipher suite
# lemah (RC4/3DES/NULL/export/anonymous) pure Python -- testssl.sh tetep
# opsional buat detail yang lebih exhaustive, bukan satu-satunya cara
# buat dapet info cipher suite lagi.

# Fase 3: baca hasil reports/<host>_recon.json, *_nuclei.json, *_tls.json,
# lakuin reasoning aktif (lihat methodology.md), susun temuan ke
# reports/<host>_findings.json ikutin schema di scripts/generate_pdf.py
# docstring

# Fase 4
python scripts/generate_pdf.py reports/<host>_findings.json

# Fase 4b (OPSIONAL -- jalanin kalau environment-nya SSH-only/headless,
# misal VPS yang diakses lewat JuiceSSH dkk tanpa fitur transfer file
# bawaan, dan user butuh cara ambil PDF-nya). JANGAN jalanin blocking di
# foreground kalau sesi kerjanya masih dipakai buat hal lain -- jalanin di
# background (lihat catatan keamanan di dalam file-nya: token acak +
# auto-expire 15 menit, BUKAN directory listing polos):
python scripts/serve_report.py reports/<host>_<timestamp>.pdf --port 8000 --minutes 15 &
# ...lalu kasih tau user: URL yang di-print, DAN ingetin cek firewall
# (ufw di VPS + Cloud Firewall provider kayak DigitalOcean/Linode kalau
# ada) buat allow port yang dipake.
```

Semua script `.py` (bukan `.sh`) -- sengaja ditulis pure Python biar jalan
identik di Windows CMD, Linux, maupun Mac, gak butuh Git Bash/WSL sama
sekali. Cukup `python` yang emang udah wajib ada buat Fase 4.

**Catatan platform:** contoh di atas pakai command `python` (standar
Windows/python.org installer). Kalau environment-nya Linux/Mac, command
yang bener biasanya `python3` (Windows biasanya cuma daftarin `python`,
Linux/Mac biasanya cuma daftarin `python3`) -- kalau `python` gak
dikenali, coba `python3` sebagai gantinya, dan sebaliknya.

PDF final ada di `reports/<host>_<timestamp>.pdf` — kasih tau user path
lengkapnya di akhir percakapan.

## Referensi (baca sesuai kebutuhan, jangan load semua sekaligus)

- `references/evidence-rules.md` — **WAJIB**, aturan anti-halusinasi,
  baca sebelum nulis temuan apa pun
- `references/methodology.md` — alur kerja detail + filosofi 2 lapis
- `references/checklist.md` — kategori kerentanan yang harus tercover
  (universal, bukan cuma SQLi/XSS)
- `references/payment-gaming-checks.md` — khusus website
  top-up/transaksional, baca kalau relevan
- `references/wordpress-checks.md` — khusus WordPress, baca kalau
  kedeteksi di Fase 1
- `references/api-checks.md` — khusus API endpoint (REST/GraphQL): BOLA,
  broken function level auth, mass assignment, excessive data exposure,
  dll. Baca kalau target-nya SPA/aplikasi yang permukaan seranganya ada
  di `/api/`, `/graphql`, dst (banyak aplikasi modern kayak gini)
- `references/payload-library.md` — starting point payload (BUKAN batas,
  improvisasi tetap dianjurkan sesuai kondisi yang ditemuin)
- `references/severity-rubric.md` — kriteria Critical/High/Medium/Low
  yang konsisten

## Setup tool yang dibutuhin (sekali doang)

- `nuclei` — https://github.com/projectdiscovery/nuclei#install-nuclei
  (opsional tapi sangat disaranin, ada fallback kalau gak ada tapi
  coverage jauh lebih terbatas)
- `nmap` — opsional, ada fallback python socket scan (lebih terbatas,
  cuma port umum)
- `testssl.sh` — opsional, ada fallback pakai modul `ssl` bawaan Python (gak butuh install openssl CLI terpisah)
- Python: `pip install reportlab` (WAJIB buat Fase 4, gak ada fallback — pakai `pip` biasa di Windows, bukan `pip3`)

## Anti-Patterns

- **Problem**: Nulis temuan tanpa bukti request/response nyata.
  **Solution**: Selalu cek ke evidence-rules.md sebelum submit, turunin ke
  kategori "Dugaan" kalau ragu.
- **Problem**: Jalanin payload generik ke semua endpoint tanpa liat konteks.
  **Solution**: Ikutin siklus observasi→hipotesis→coba→adaptasi di Fase 3.
- **Problem**: Skip payment-gaming-checks.md/wordpress-checks.md karena
  Fase 1-2 gak nemu apa-apa di situ. **Solution**: Kategori business logic
  emang gak akan pernah ketemu scanner otomatis — WAJIB dicek manual di
  Fase 3 kalau relevan sama target.
- **Problem**: Eksekusi payload mutating (submit transaksi asli, dst) tanpa
  konfirmasi mode --allow-mutating. **Solution**: Selalu cek mode dulu di
  Fase 0, default read-only.
- **Problem**: Langsung lompat dari Fase 2 ke Fase 4 (generate PDF) tanpa
  reasoning aktif di Fase 3 -- hasilnya cuma nangkep pola umum dari nuclei,
  kategori kayak business logic/SQLi kontekstual/IDOR kelewat total.
  **Solution**: Jalanin GATE 13-kategori di atas sebelum manggil
  `generate_pdf.py` — tiap kategori checklist.md WAJIB ada jejaknya di
  findings.json (ketemu, dugaan, atau not_tested dengan alasan jujur).

## Validation

- Semua temuan di PDF final masuk kategori "Terkonfirmasi" (ada bukti
  request+response) atau "Dugaan" (ditandai jelas beda, gak dicampur).
- Fase 1 (recon) selalu jalan duluan sebelum Fase 2/3, hasilnya dipakai
  buat nentuin cabang mana yang relevan (WordPress checks, dst).
- File findings.json valid ikutin schema di scripts/generate_pdf.py
  sebelum generate_pdf.py dijalanin.
- Semua 13 kategori di references/checklist.md ke-cover di findings.json
  (confirmed, suspected, atau not_tested dengan alasan) -- lihat GATE
  WAJIB di atas. Ini dicek SEBELUM generate_pdf.py dipanggil, bukan
  setelahnya.
