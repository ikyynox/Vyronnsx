'use strict'
// ============================================================
// sidecar/control.js — pengendali sidecar FastProxy
//
//  - Firewall kill-switch: semua trafik keluar di-DROP, kecuali lewat tunnel (tun0) dan ke host FastProxy.
//    IPv6 di-DROP total. Kalau tunnel mati, Chrome tidak punya jalan keluar => IP VPS tidak mungkin bocor.
//  - tun2socks: seluruh trafik container masuk SOCKS5 FastProxy (FastProxy hanya TCP: tanpa UDP/HTTP3).
//  - Chrome dijalankan sebagai user biasa (tanpa NET_ADMIN), tanpa --proxy-server, jadi HTTP/3 dan WebRTC
//    lewat tunnel seperti Chrome asli.
//  - API (port SIDECAR_PORT, wajib token):
//      GET  /status            status ringkas
//      POST /ensure            pastikan tunnel + Chrome hidup dan IP dari FP_COUNTRY (ganti IP kalau perlu)
//      POST /rotate            paksa IP baru (session ID baru), ulangi sampai IP beda dan negara benar
//      WS   /cdp?t=TOKEN       pintu masuk Puppeteer (diteruskan ke Chrome)
// ============================================================
const http = require('http')
const net = require('net')
const fs = require('fs')
const crypto = require('crypto')
const { spawn, execFile } = require('child_process')
const { Resolver } = require('dns').promises
const dgram = require('dgram')
const https = require('https')

const E = process.env
const PORT = parseInt(E.SIDECAR_PORT || '9222', 10)
const CDP_PORT = 9223 // port debug Chrome, hanya di loopback
const TOKEN = String(E.SIDECAR_TOKEN || '')
const FP_HOST = String(E.FP_HOST || 'resi.fastproxy.to')
const FP_PORT = parseInt(E.FP_PORT || '9696', 10)
const FP_PASS = String(E.FP_PASS || '')
const FP_USER_TEMPLATE = String(E.FP_USER_TEMPLATE || '')
const COUNTRY = String(E.FP_COUNTRY || 'ID').toUpperCase()
const ROTATE_MAX = Math.max(1, parseInt(E.FP_ROTATE_MAX || '6', 10) || 6)
const CHROME_LANG = String(E.CHROME_LANG || 'id-ID,id')
// Seleksi kecepatan IP: setelah dapat IP (negara benar, IP baru), diukur waktu 1 permintaan HTTPS kecil lewat tunnel (termasuk DNS + TLS).
// Lebih lambat dari FP_MAX_LATENCY_MS => IP ditolak dan sidecar mencoba IP lain (maks FP_SPEED_TRIES kali, dan paling lama FP_SPEED_BUDGET_MS).
// Kalau semua yang dicoba lambat, dipakai yang tercepat. FP_MAX_LATENCY_MS=0 mematikan seleksi. Berlaku untuk SEMUA pemanggil (ensure/rotate).
const MAX_LATENCY_MS = Math.max(0, parseInt(E.FP_MAX_LATENCY_MS || '3000', 10) || 0)
const SPEED_TRIES = Math.max(0, parseInt(E.FP_SPEED_TRIES || '5', 10) || 0)
const SPEED_BUDGET_MS = Math.max(10000, parseInt(E.FP_SPEED_BUDGET_MS || '110000', 10) || 110000)
// IP sama / pernah dipakai saat rotasi: ini TIDAK dihitung sebagai kegagalan biasa. Sidecar terus mencari IP lain (kecepatan tidak
// dipakai sebagai syarat), tambahan maks FP_SAME_TRIES percobaan dan paling lama FP_SAME_BUDGET_MS sejak rotasi dimulai
// (harus < timeout rotate di bot = 170 dtk). Seleksi kecepatan di atas tetap berlaku untuk IP yang sudah berbeda.
const SAME_TRIES = Math.max(0, parseInt(E.FP_SAME_TRIES == null || E.FP_SAME_TRIES === '' ? '10' : E.FP_SAME_TRIES, 10) || 0)
const SAME_BUDGET_MS = Math.max(10000, parseInt(E.FP_SAME_BUDGET_MS || '150000', 10) || 150000)
const PROBE_URL = String(E.FP_PROBE_URL || 'https://www.google.com/generate_204')
const CHROME_BIN = '/usr/bin/google-chrome-stable'
const CHROME_UID = 1001
const PROFILE = '/tmp/chrome-profile'

const log = (...a) => console.log(new Date().toISOString(), ...a)
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

if (TOKEN.length < 16) { console.error('SIDECAR_TOKEN wajib diisi, minimal 16 karakter'); process.exit(1) }
if (!FP_PASS) { console.error('FP_PASS wajib diisi'); process.exit(1) }
if (!/\{sid\}/.test(FP_USER_TEMPLATE)) { console.error('FP_USER_TEMPLATE wajib diisi dan mengandung {sid}'); process.exit(1) }

// Buang kredensial dari log apa pun
const scrub = (s) => {
  let o = String(s)
  for (const secret of [FP_PASS, encodeURIComponent(FP_PASS)]) if (secret) o = o.split(secret).join('***')
  return o
}

const run = (cmd, args, opts = {}) => new Promise((resolve) => {
  execFile(cmd, args, { timeout: 20000, ...opts }, (err, stdout, stderr) => {
    resolve({ ok: !err, out: String(stdout || '') + String(stderr || '') })
  })
})

// ---------- Jaringan ----------
let WAN_IF = 'eth0'
let WAN_GW = ''
let PROXY_IPS = []

async function detectWan() {
  const r = await run('ip', ['route', 'show', 'default'])
  const m = r.out.match(/default via (\S+) dev (\S+)/)
  if (m) { WAN_GW = m[1]; WAN_IF = m[2] }
}

async function resolveProxyIps() {
  if (net.isIP(FP_HOST)) return [FP_HOST]
  // lewat DNS embedded Docker (loopback), bukan lewat tunnel
  const rs = new Resolver()
  rs.setServers(['127.0.0.11'])
  try {
    const ips = await rs.resolve4(FP_HOST)
    if (ips.length) return ips
  } catch {}
  return PROXY_IPS // gagal resolve: pakai hasil sebelumnya
}

async function ipt(args) { return run('iptables', args) }
async function ip6t(args) { return run('ip6tables', args).catch(() => ({ ok: false })) }

// Kill-switch. Urutan: kebijakan DROP dulu, baru flush, baru izin -> tidak pernah ada celah terbuka.
async function lockFirewall(ips) {
  for (const t of [ipt, ip6t]) {
    await t(['-P', 'INPUT', 'DROP']); await t(['-P', 'OUTPUT', 'DROP']); await t(['-P', 'FORWARD', 'DROP'])
    await t(['-F']); await t(['-X'])
  }
  const rules = [
    ['-A', 'INPUT', '-i', 'lo', '-j', 'ACCEPT'],
    ['-A', 'INPUT', '-m', 'conntrack', '--ctstate', 'ESTABLISHED,RELATED', '-j', 'ACCEPT'],
    ['-A', 'INPUT', '-i', WAN_IF, '-p', 'tcp', '--dport', String(PORT), '-j', 'ACCEPT'],
    ['-A', 'OUTPUT', '-o', 'lo', '-j', 'ACCEPT'],
    ['-A', 'OUTPUT', '-o', 'tun0', '-j', 'ACCEPT'],
    ['-A', 'OUTPUT', '-o', WAN_IF, '-m', 'conntrack', '--ctstate', 'ESTABLISHED,RELATED', '-j', 'ACCEPT'],
    ...ips.map((ip) => ['-A', 'OUTPUT', '-o', WAN_IF, '-d', ip, '-j', 'ACCEPT'])
  ]
  for (const r of rules) {
    const x = await ipt(r)
    if (!x.ok) throw new Error(`iptables gagal (${r.join(' ')}): ${x.out.trim().slice(0, 120)}`)
  }
}

// ---------- Tunnel (tun2socks) ----------
let t2s = null
let t2sIntentional = false
let curSid = ''

function stopTunnel() {
  if (t2s) { t2sIntentional = true; try { t2s.kill('SIGTERM') } catch {} t2s = null }
}
const tunnelAlive = () => !!t2s && t2s.exitCode === null

async function startTunnel(ips, forceSid) {
  stopTunnel()
  await sleep(400)
  curSid = forceSid || crypto.randomBytes(6).toString('hex')
  const user = FP_USER_TEMPLATE
    .replace(/\{sid\}/g, curSid)
    .replace(/\{country\}/g, COUNTRY.toLowerCase())
    .replace(/\{COUNTRY\}/g, COUNTRY)
  const proxyUrl = `socks5://${encodeURIComponent(user)}:${encodeURIComponent(FP_PASS)}@${ips[0]}:${FP_PORT}`

  // rute ke host FastProxy HARUS lewat jaringan asli (tun2socks di-bind ke WAN_IF)
  for (const ip of ips) await run('ip', ['route', 'replace', `${ip}/32`, 'via', WAN_GW, 'dev', WAN_IF])

  t2sIntentional = false
  const child = spawn('/usr/local/bin/tun2socks', ['-device', 'tun://tun0', '-proxy', proxyUrl, '-interface', WAN_IF, '-loglevel', 'error'], { stdio: ['ignore', 'pipe', 'pipe'] })
  t2s = child
  const pipeLog = (d) => String(d).split('\n').filter(Boolean).forEach((l) => log('[tun2socks]', scrub(l).slice(0, 200)))
  child.stdout.on('data', pipeLog); child.stderr.on('data', pipeLog)
  child.on('exit', (code) => {
    if (t2s === child) t2s = null
    if (!t2sIntentional) { log(`[tun2socks] berhenti sendiri (kode ${code}). Kill-switch tetap aktif, tunggu /ensure atau rotasi berikutnya.`); stopChrome() }
  })

  let up = false
  for (let i = 0; i < 20; i++) {
    if ((await run('ip', ['link', 'show', 'tun0'])).ok) { up = true; break }
    await sleep(300)
  }
  if (!up) throw new Error('device tun0 tidak muncul (cek /dev/net/tun dan NET_ADMIN)')
  await run('ip', ['addr', 'add', '198.18.0.1/15', 'dev', 'tun0'])
  await run('ip', ['link', 'set', 'dev', 'tun0', 'up'])
  await run('ip', ['route', 'replace', 'default', 'dev', 'tun0'])
  // DNS lewat stub lokal -> DoH di dalam tunnel (bukan lewat resolver Docker/VPS)
  try { fs.writeFileSync('/etc/resolv.conf', 'nameserver 127.0.0.1\noptions timeout:3 attempts:2\n') } catch {}
}

// ---------- DNS lewat DoH (HTTPS port 443) ----------
// Banyak proxy residential TIDAK meneruskan UDP, sehingga DNS UDP biasa mati dan Chrome tidak bisa me-resolve nama situs.
// Solusi: stub DNS lokal 127.0.0.1:53 (UDP, hanya di loopback) yang meneruskan tiap query lewat HTTPS ke DoH (TCP 443),
// lewat tunnel yang sama. resolv.conf diarahkan ke stub ini. DNS_DOH_URL bisa diganti, bawaan Cloudflare.
const DOH = new URL(E.DNS_DOH_URL || 'https://1.1.1.1/dns-query')
const dohAgent = new (DOH.protocol === 'http:' ? http : https).Agent({ keepAlive: true, maxSockets: 16 })
function dohOnce(buf) {
  return new Promise((resolve, reject) => {
    const mod = DOH.protocol === 'http:' ? http : https
    const req = mod.request({
      hostname: DOH.hostname, port: DOH.port || (DOH.protocol === 'http:' ? 80 : 443), path: DOH.pathname + DOH.search, method: 'POST', agent: dohAgent, timeout: 8000,
      headers: { 'content-type': 'application/dns-message', accept: 'application/dns-message', 'content-length': buf.length }
    }, (res) => {
      const parts = []
      res.on('data', (d) => parts.push(d))
      res.on('end', () => (res.statusCode === 200 ? resolve(Buffer.concat(parts)) : reject(new Error('DoH HTTP ' + res.statusCode))))
    })
    req.on('timeout', () => req.destroy(new Error('DoH timeout')))
    req.on('error', reject)
    req.end(buf)
  })
}
async function dohQuery(buf) {
  try { return await dohOnce(buf) } catch { return await dohOnce(buf) } // 1x ulang (koneksi keep-alive lama bisa mati setelah rotasi)
}
function startDnsStub() {
  const sock = dgram.createSocket('udp4')
  sock.on('message', (msg, rinfo) => {
    dohQuery(msg).then((r) => sock.send(r, rinfo.port, rinfo.address)).catch(() => {})
  })
  sock.on('error', (e) => log('[dns-stub] error:', String((e && e.message) || e)))
  sock.bind(53, '127.0.0.1', () => log('[dns-stub] aktif di 127.0.0.1:53 -> DoH', DOH.origin))
}

// Tes UDP mentah lewat tunnel (query DNS ke 1.1.1.1:53). Hanya penanda: kalau gagal, HTTP/3 (QUIC) dan STUN WebRTC tidak tersedia.
function udpWorks() {
  return new Promise((resolve) => {
    const s = dgram.createSocket('udp4')
    const q = Buffer.from('123401000001000000000000076578616d706c6503636f6d0000010001', 'hex')
    let done = false
    const fin = (v) => { if (done) return; done = true; try { s.close() } catch {} resolve(v) }
    s.on('message', () => fin(true)); s.on('error', () => fin(false))
    s.send(q, 53, '1.1.1.1', (e) => { if (e) fin(false) })
    setTimeout(() => fin(false), 3500)
  })
}

// ---------- Trace IP (lewat tunnel, tanpa DNS) ----------
async function readTrace() {
  const r = await run('curl', ['-s', '--max-time', '12', 'https://1.1.1.1/cdn-cgi/trace'])
  if (!r.ok) return null
  const o = {}
  for (const line of r.out.split('\n')) { const i = line.indexOf('='); if (i > 0) o[line.slice(0, i).trim()] = line.slice(i + 1).trim() }
  return o.ip ? { ip: o.ip, loc: String(o.loc || '').toUpperCase() } : null
}
// Zona waktu IP exit (supaya timezone browser sama dengan lokasi IP). Satu request kecil per IP, hasil di-cache.
const tzCache = new Map()
async function tzFor(ip) {
  if (!ip) return null
  if (tzCache.has(ip)) return tzCache.get(ip)
  let tz = null
  for (const [url, pick] of [
    ['https://ipwho.is/', (j) => j && j.success !== false && j.timezone && j.timezone.id],
    ['http://ip-api.com/json/?fields=status,timezone', (j) => j && j.status === 'success' && j.timezone]
  ]) {
    const r = await run('curl', ['-s', '--max-time', '10', url])
    if (!r.ok) continue
    try { const v = pick(JSON.parse(r.out)); if (v && /^[A-Za-z]+\/[A-Za-z0-9_+\/-]+$/.test(v)) { tz = v; break } } catch (e) {}
  }
  if (tz) { tzCache.set(ip, tz); if (tzCache.size > 300) tzCache.delete(tzCache.keys().next().value) }
  return tz
}
async function readTraceRetry(n = 3) {
  for (let i = 0; i < n; i++) { const t = await readTrace(); if (t) return t; await sleep(2000) }
  return null
}
// Ukur kecepatan IP: 2x permintaan kecil (204) lewat tunnel, diambil yang tercepat. Mengembalikan ms, atau null kalau gagal semua.
async function probeLatency() {
  let best = null
  for (let i = 0; i < 2; i++) {
    const r = await run('curl', ['-s', '-o', '/dev/null', '--max-time', '12', '-w', '%{http_code} %{time_total}', PROBE_URL])
    const m = r.ok ? r.out.trim().match(/^([23]\d\d) ([\d.]+)$/) : null
    if (m) { const ms = Math.round(parseFloat(m[2]) * 1000); if (best === null || ms < best) best = ms }
  }
  return best
}
async function dnsWorks() { return (await run('getent', ['hosts', 'example.com'])).ok }

// ---------- Chrome ----------
let chrome = null
let chromeWsPath = ''
const chromeAlive = () => !!chrome && chrome.exitCode === null && !!chromeWsPath

function stopChrome() {
  chromeWsPath = ''
  if (chrome) { try { chrome.kill('SIGKILL') } catch {} chrome = null }
}

// UA Chrome asli (tanpa kata "HeadlessChrome") dipasang di level proses, jadi berlaku juga di service worker/shared worker/iframe,
// bukan hanya di halaman. Versi diambil dari Chrome yang terpasang (UA modern: major.0.0.0).
let chromeUaCache = ''
async function chromeUa() {
  if (chromeUaCache) return chromeUaCache
  const r = await run(CHROME_BIN, ['--version'])
  const m = r.ok ? r.out.match(/(\d+)\.\d+\.\d+\.\d+/) : null
  if (m) chromeUaCache = `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${m[1]}.0.0.0 Safari/537.36`
  return chromeUaCache
}

async function startChrome() {
  stopChrome()
  const ua = await chromeUa()
  fs.rmSync(PROFILE, { recursive: true, force: true })
  fs.mkdirSync(PROFILE, { recursive: true })
  fs.chownSync(PROFILE, CHROME_UID, CHROME_UID)
  const args = [
    '--headless=new',
    '--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage',
    '--disable-blink-features=AutomationControlled',
    // WebGL software (sama seperti lib/browser.js)
    '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist',
    '--window-size=1280,720', `--lang=${CHROME_LANG.split(',')[0].trim()}`, `--accept-lang=${CHROME_LANG}`,
    ...(ua ? [`--user-agent=${ua}`] : []),
    // headless tidak punya perangkat penunjuk => CSS pointer/hover = none/none (ciri headless). Chrome desktop asli: pointer fine, hover hover.
    '--blink-settings=primaryPointerType=4,availablePointerTypes=4,primaryHoverType=2,availableHoverTypes=2',
    '--enable-quic',
    `--remote-debugging-port=${CDP_PORT}`, '--remote-debugging-address=127.0.0.1',
    `--user-data-dir=${PROFILE}`, '--no-first-run', '--no-default-browser-check'
    // SENGAJA tanpa --proxy-server dan tanpa --force-webrtc-ip-handling-policy:
    // semua trafik lewat tun0, jadi HTTP/3 dan WebRTC bekerja normal dan menampilkan IP residential.
  ]
  const child = spawn(CHROME_BIN, args, {
    uid: CHROME_UID, gid: CHROME_UID, stdio: 'ignore',
    env: { PATH: process.env.PATH, HOME: '/home/chrome', LANG: 'id_ID.UTF-8' }
  })
  chrome = child
  child.on('exit', () => { if (chrome === child) { chrome = null; chromeWsPath = '' } })
  for (let i = 0; i < 40; i++) {
    if (child.exitCode !== null) break
    try {
      const r = await fetch(`http://127.0.0.1:${CDP_PORT}/json/version`)
      const j = await r.json()
      chromeWsPath = new URL(j.webSocketDebuggerUrl).pathname
      return true
    } catch {}
    await sleep(500)
  }
  stopChrome()
  return false
}

// ---------- Siklus: naikkan tunnel, cek IP, nyalakan Chrome ----------
let state = { ip: '', loc: '' }
// IP yang sudah pernah dipakai (sejak container hidup). Rotasi paksa menolak IP yang sama dengan sebelumnya ATAU yang pernah dipakai.
const usedIps = []
const USED_MAX = 300
const markUsed = (ip) => { if (ip && !usedIps.includes(ip)) { usedIps.push(ip); if (usedIps.length > USED_MAX) usedIps.shift() } }
let activeWs = 0
let chain = Promise.resolve()
const lock = (fn) => { const p = chain.then(fn); chain = p.catch(() => {}); return p }

let ipChanges = 0
function adoptIp(t, dari) {
  log(`[ip-berubah] ${state.ip} -> ${t.ip} (${t.loc}) terdeteksi oleh ${dari}: session sticky FastProxy tidak bertahan, IP baru diterima`)
  ipChanges++
  state.ip = t.ip; state.loc = t.loc; state.ms = null
  markUsed(t.ip)
}
// Pantau IP saat ada sesi browser aktif (tiap 30 detik, hanya trafik kecil), supaya perubahan IP di tengah sesi terlihat di log dan status.
function startIpWatch() {
  setInterval(async () => {
    if (!activeWs || !tunnelAlive() || !state.ip) return
    const t = await readTrace()
    if (t && t.ip !== state.ip) adoptIp(t, 'pemantau')
  }, 30000).unref()
}

async function waitIdle(ms) {
  const end = Date.now() + ms
  while (activeWs > 0 && Date.now() < end) await sleep(500)
}

async function cycle({ forceNew }) {
  const prevIp = state.ip
  const t0 = Date.now()
  let why = 'tidak diketahui'
  let limit = ROTATE_MAX // naik 1 tiap IP ditolak karena lambat (maks SPEED_TRIES)
  let slowN = 0
  let sameN = 0 // IP sama/pernah dipakai yang ditolak (limit dinaikkan, tidak memakan jatah percobaan biasa)
  let bestTried = false // sudah pernah mencoba kembali ke IP tercepat
  let best = null // IP tercepat yang pernah dicoba di siklus ini
  for (let n = 1; n <= limit; n++) {
    try {
      stopChrome()
      const ips = await resolveProxyIps()
      if (!ips.length) throw new Error(`gagal resolve ${FP_HOST}`)
      PROXY_IPS = ips
      await lockFirewall(ips)
      await startTunnel(ips)
      const t = await readTraceRetry(3)
      if (!t) { why = 'tidak bisa menjangkau internet lewat tunnel (cek user/password/format FP_USER_TEMPLATE, saldo, dan dukungan UDP)'; log(`[cycle ${n}/${limit}] ${why}`); continue }
      state = { ip: t.ip, loc: t.loc, udp: false, ms: null }
      const okCountry = !COUNTRY || t.loc === COUNTRY
      const okIp = !forceNew || !prevIp || (t.ip !== prevIp && !usedIps.includes(t.ip))
      log(`[cycle ${n}/${limit}] IP ${t.ip} (${t.loc || '?'})${okCountry ? '' : ' - bukan ' + COUNTRY}${okIp ? '' : ' - IP sama/pernah dipakai'}`)
      if (!okCountry) { why = `IP kebaca ${t.loc || '?'} (bukan ${COUNTRY})`; continue }
      if (!okIp) {
        why = 'IP tetap sama / pernah dipakai setelah ganti session'
        if (sameN < SAME_TRIES && Date.now() - t0 < SAME_BUDGET_MS) { sameN++; limit++; await sleep(1000) }
        continue
      }
      markUsed(t.ip)

      // seleksi kecepatan
      let ms = null
      if (MAX_LATENCY_MS > 0) {
        ms = await probeLatency()
        let slow = ms === null || ms > MAX_LATENCY_MS
        log(`[cycle ${n}/${limit}] kecepatan: ${ms === null ? 'uji gagal' : ms + ' ms'} (batas ${MAX_LATENCY_MS} ms) ${slow ? 'LAMBAT' : 'ok'}`)
        if (ms !== null && (!best || ms < best.ms)) best = { sid: curSid, ip: t.ip, loc: t.loc, ms }
        if (slow) {
          if (slowN < SPEED_TRIES && Date.now() - t0 < SPEED_BUDGET_MS) { slowN++; limit++; why = `IP lambat (${ms === null ? 'uji gagal' : ms + ' ms'})`; continue }
          // kesempatan habis: pakai yang tercepat (kalau ada, dan bukan IP yang sedang aktif)
          if (best && best.sid !== curSid && !bestTried) {
            bestTried = true
            log(`[cycle ${n}/${limit}] semua IP yang dicoba lambat, kembali ke yang tercepat (${best.ip}, ${best.ms} ms)`)
            stopChrome()
            await startTunnel(ips, best.sid)
            const t2 = await readTraceRetry(3)
            // Kembali ke session lama bisa menghasilkan IP lain (tidak sticky), bahkan IP yang sama dengan sebelum rotasi.
            // Kecepatan hanya preferensi: IP harus tetap BEDA. Kalau tidak valid, cari lagi (cycle berikutnya memakai IP yang lolos, walau lambat).
            const okIp2 = t2 && (!forceNew || !prevIp || (t2.ip !== prevIp && (t2.ip === best.ip || !usedIps.includes(t2.ip))))
            if (!t2 || (COUNTRY && t2.loc !== COUNTRY) || !okIp2) { why = !okIp2 && t2 ? 'kembali ke IP tercepat memberi IP sama/pernah dipakai' : 'gagal kembali ke IP tercepat'; limit++; continue }
            state = { ip: t2.ip, loc: t2.loc, udp: false, ms: best.ms }
            markUsed(t2.ip)
            ms = best.ms
            if (t2.ip !== best.ip) log(`[cycle ${n}/${limit}] catatan: IP berganti ke ${t2.ip} (session lama sudah tidak sticky)`)
          } else log(`[cycle ${n}/${limit}] tidak ada IP yang lebih cepat, memakai IP ini`)
        }
        state.ms = ms
      }
      state.udp = await udpWorks()
      log(`[cycle ${n}/${limit}] UDP lewat tunnel: ${state.udp ? 'ya (HTTP/3 & WebRTC srflx bisa)' : 'TIDAK (proxy tidak meneruskan UDP: HTTP/3 off, DNS lewat DoH)'}`)
      if (!(await startChrome())) { why = 'Chrome gagal start'; continue }
      return { ok: true, ip: state.ip, loc: state.loc, tz: await tzFor(state.ip), prevIp: prevIp || state.ip, tries: n, ms, slow: MAX_LATENCY_MS > 0 && (ms === null || ms > MAX_LATENCY_MS) }
    } catch (e) {
      why = String((e && e.message) || e).slice(0, 200)
      log(`[cycle ${n}/${limit}] error: ${scrub(why)}`)
    }
  }
  stopChrome()
  return { ok: false, why: `${why} (sudah dicoba ${limit}x)`, ip: state.ip, loc: state.loc, prevIp }
}

const ensure = () => lock(async () => {
  if (tunnelAlive() && chromeAlive() && state.ip) {
    const t = await readTrace()
    if (t && t.ip === state.ip && (!COUNTRY || t.loc === COUNTRY)) return { ok: true, ip: state.ip, loc: state.loc, tz: await tzFor(state.ip), prevIp: state.ip, tries: 0, ms: state.ms || null }
    // IP berubah sendiri dari sisi FastProxy (peer residential offline/berganti padahal session sama) tapi negara masih benar:
    // terima IP baru, JANGAN bongkar tunnel dan Chrome (itu memutus halaman yang sedang berjalan dan memicu seleksi ulang).
    if (t && state.ip && t.ip !== state.ip && (!COUNTRY || t.loc === COUNTRY)) { adoptIp(t, 'ensure'); return { ok: true, ip: state.ip, loc: state.loc, tz: await tzFor(state.ip), prevIp: state.ip, tries: 0, ms: null } }
  }
  return cycle({ forceNew: false })
})
const rotate = () => lock(async () => {
  await waitIdle(15000)
  return cycle({ forceNew: true })
})

// ---------- HTTP API + proxy CDP ----------
function authOK(req, u) {
  const h = String(req.headers.authorization || '')
  const got = h.startsWith('Bearer ') ? h.slice(7) : String(u.searchParams.get('t') || '')
  const a = Buffer.from(got), b = Buffer.from(TOKEN)
  return a.length === b.length && crypto.timingSafeEqual(a, b)
}
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)) }

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://x')
  if (!authOK(req, u)) return send(res, 401, { ok: false, why: 'unauthorized' })
  try {
    if (req.method === 'GET' && u.pathname === '/status') {
      return send(res, 200, {
        ok: tunnelAlive() && chromeAlive(), tunnel: tunnelAlive(), chrome: chromeAlive(),
        ip: state.ip, loc: state.loc, tz: tzCache.get(state.ip) || null, ms: state.ms || null, maxMs: MAX_LATENCY_MS, ipChanges, dns: tunnelAlive() ? await dnsWorks() : false, udp: !!state.udp, activeWs, country: COUNTRY
      })
    }
    if (req.method === 'POST' && u.pathname === '/ensure') return send(res, 200, await ensure())
    if (req.method === 'POST' && u.pathname === '/rotate') return send(res, 200, await rotate())
    return send(res, 404, { ok: false, why: 'not found' })
  } catch (e) {
    return send(res, 500, { ok: false, why: scrub(String((e && e.message) || e)).slice(0, 200) })
  }
})

server.on('upgrade', (req, socket, head) => {
  const u = new URL(req.url, 'http://x')
  if (u.pathname !== '/cdp' || !authOK(req, u) || !chromeAlive()) { socket.destroy(); return }
  const up = net.connect(CDP_PORT, '127.0.0.1', () => {
    up.write(
      `GET ${chromeWsPath} HTTP/1.1\r\nHost: 127.0.0.1:${CDP_PORT}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n` +
      `Sec-WebSocket-Key: ${req.headers['sec-websocket-key']}\r\nSec-WebSocket-Version: 13\r\n\r\n`
    )
    if (head && head.length) up.write(head)
    up.pipe(socket); socket.pipe(up)
  })
  activeWs++
  let done = false
  const end = () => { if (done) return; done = true; activeWs = Math.max(0, activeWs - 1); try { up.destroy() } catch {} try { socket.destroy() } catch {} }
  up.on('error', end); up.on('close', end); socket.on('error', end); socket.on('close', end)
})

function shutdown() { stopChrome(); stopTunnel(); process.exit(0) }
process.on('SIGTERM', shutdown)
process.on('SIGINT', shutdown)

;(async () => {
  await detectWan()
  startDnsStub()
  startIpWatch()
  PROXY_IPS = await resolveProxyIps()
  // Kunci jaringan SEBELUM apa pun: tanpa tunnel, tidak ada yang bisa keluar
  await lockFirewall(PROXY_IPS)
  server.listen(PORT, '0.0.0.0', () => log(`sidecar siap di port ${PORT} (negara wajib ${COUNTRY}, wan ${WAN_IF} via ${WAN_GW})`))
  // naikkan tunnel di latar belakang; ulangi kalau gagal
  for (;;) {
    const r = await ensure()
    if (r.ok) { log(`siap: ${r.ip} (${r.loc})`); break }
    log(`belum siap: ${scrub(r.why)}. Coba lagi 30 detik.`)
    await sleep(30000)
  }
})().catch((e) => { console.error('fatal:', scrub(e && e.stack || e)); process.exit(1) })
