# CARA CEPAT (otomatis)
Di SSH VPS, dari folder hasil unzip: `bash pasang.sh`  (skrip mengurus semuanya, bagian manual di bawah cuma cadangan)

# Sidecar FastProxy (Chrome + tun2socks)

Jalan di VPS yang sama dengan bot, TAPI di luar Pterodactyl (lewat SSH + docker compose).

## Pasang
1. Taruh folder ini di VPS, mis. `/opt/fp-sidecar`.
2. Buat file `.env` di folder itu (nano .env) dengan isi: `SIDECAR_TOKEN` (acak panjang: `openssl rand -hex 24`), `FP_PASS`, `FP_USER_TEMPLATE`
   (harus ada `{sid}`; bentuknya ikut format di Proxy Generator FastProxy, mode SOCKS5, port 9696).
3. `docker compose up -d --build`
4. `docker logs -f fp-sidecar` -> tunggu baris `siap: <IP> (ID)`.
   Container ini masuk jaringan `pterodactyl_nw` dengan IP tetap `172.18.0.250`, tidak ada port yang dibuka ke internet.
   Kalau IP itu sudah dipakai, ganti `ipv4_address` di docker-compose.yml dan `SIDECAR_URL` di bot.

## Di bot (.env)
```
BROWSER_PROXY_MODE=sidecar
SIDECAR_URL=http://172.18.0.250:9222
SIDECAR_TOKEN=<sama dengan token sidecar>
```
ENABLE_WARP=1 dan YTDLP_PROXY=warp tetap (dipakai yt-dlp saja). Ganti dua file di bot: `lib/browser.js`, `lib/sidecarClient.js`.

## Tes (lakukan berurutan)
- Status: `docker exec fp-sidecar curl -s -H "Authorization: Bearer TOKEN" localhost:9222/status`
  (`dns:true` artinya UDP lewat tunnel jalan; `dns:false` berarti UDP/QUIC kemungkinan tidak didukung)
- Kill-switch: `docker exec fp-sidecar pkill tun2socks; docker exec fp-sidecar curl -m 5 https://1.1.1.1` -> HARUS gagal.
- WebRTC dan HTTP/3: jalankan `.cekdiag` dan halaman QUIC di vyron.js. Kandidat srflx harus IP residential, bukan IP VPS.
- Rotasi: `forceRotate` dua kali berturut-turut, IP harus beda dan tetap `loc=ID`.

## Catatan
- Rotasi menunggu koneksi bot putus (maks 15 detik), lalu restart tunnel + Chrome dengan session ID baru.
- Plugin lama yang memanggil puppeteer.launch() langsung tetap jalan lewat sidecar, tapi args/userDataDir/executablePath miliknya tidak berlaku.
- Mode lama (WARP) tetap ada: kosongkan BROWSER_PROXY_MODE untuk kembali.

## Cek jumlah font di sidecar
`docker exec fp-sidecar sh -c 'fc-list | wc -l; fc-list : family | sort -u | wc -l'`  (baris pertama = total face, kedua = jumlah family)
