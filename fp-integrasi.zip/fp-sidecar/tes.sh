#!/usr/bin/env bash
# ============================================================
# tes.sh — tes otomatis sidecar FastProxy. Bisa dijalankan kapan saja, aman (tidak mengubah apa pun).
#   bash /opt/fp-sidecar/tes.sh                 tes biasa
#   bash /opt/fp-sidecar/tes.sh --killswitch    + tes kill-switch (mematikan tunnel sebentar, lalu dipulihkan)
# Tidak pernah menampilkan password/token.
# ============================================================
set -uo pipefail
DEST="/opt/fp-sidecar"
PORT=9222
G='\033[1;32m'; R='\033[1;31m'; Y='\033[1;33m'; C='\033[1;36m'; N='\033[0m'
PASS=0; FAIL=0; WARN=0
ok()   { printf "${G}  [OK]${N} %s\n" "$*"; PASS=$((PASS+1)); }
bad()  { printf "${R}  [GAGAL]${N} %s\n" "$*"; FAIL=$((FAIL+1)); }
warn() { printf "${Y}  [!]${N} %s\n" "$*"; WARN=$((WARN+1)); }
say()  { printf "\n${C}==> %s${N}\n" "$*"; }

[ -f "$DEST/.env" ] || { echo "Tidak ada $DEST/.env. Pasang dulu: bash pasang.sh"; exit 1; }
TOKEN="$(grep -E '^SIDECAR_TOKEN=' "$DEST/.env" | head -n1 | cut -d= -f2-)"
dx()  { docker exec fp-sidecar "$@" 2>/dev/null; }
api() { dx curl -s -m "${2:-20}" ${3:+-X "$3"} -H "Authorization: Bearer $TOKEN" "http://localhost:$PORT$1"; }

say "1. Container"
if [ "$(docker inspect -f '{{.State.Running}}' fp-sidecar 2>/dev/null)" = "true" ]; then ok "fp-sidecar berjalan"
else bad "fp-sidecar tidak berjalan. Jalankan: cd $DEST && docker compose up -d"; echo; echo "Hasil: $PASS OK, $FAIL gagal"; exit 1; fi

say "2. Status & IP"
ST="$(api /status)"
if [ -z "$ST" ]; then bad "API sidecar tidak menjawab (belum siap? lihat: docker logs --tail 30 fp-sidecar)"
else
  IP="$(sed -n 's/.*"ip":"\([^"]*\)".*/\1/p' <<<"$ST")"; LOC="$(sed -n 's/.*"loc":"\([^"]*\)".*/\1/p' <<<"$ST")"
  grep -q '"tunnel":true' <<<"$ST" && ok "tunnel hidup" || bad "tunnel mati"
  grep -q '"chrome":true' <<<"$ST" && ok "Chrome hidup" || bad "Chrome mati"
  echo "  IP sidecar: ${IP:-?} (${LOC:-?})"
  MS="$(sed -n 's/.*"ms":\([0-9]*\).*/\1/p' <<<"$ST")"; MX="$(sed -n 's/.*"maxMs":\([0-9]*\).*/\1/p' <<<"$ST")"
  if [ -n "$MS" ]; then if [ -n "$MX" ] && [ "$MX" -gt 0 ] && [ "$MS" -gt "$MX" ]; then warn "kecepatan IP ${MS} ms, di atas batas ${MX} ms (tidak ada IP lebih cepat yang ketemu)"; else ok "kecepatan IP ${MS} ms (batas ${MX:-?} ms)"; fi; fi
  HOSTIP="$(curl -s -m 8 https://1.1.1.1/cdn-cgi/trace 2>/dev/null | sed -n 's/^ip=//p')"
  if [ -n "$HOSTIP" ] && [ "$HOSTIP" = "$IP" ]; then bad "IP sidecar SAMA dengan IP VPS ($HOSTIP): trafik tidak lewat proxy!"
  else ok "IP sidecar berbeda dari IP VPS${HOSTIP:+ ($HOSTIP)}"; fi
  [ "$LOC" = "ID" ] && ok "negara Indonesia (ID)" || warn "negara terbaca '${LOC:-?}', bukan ID"
fi

say "3. DNS lewat DoH"
docker logs fp-sidecar 2>&1 | grep -q 'dns-stub\] aktif' && ok "stub DoH aktif (log)" || bad "stub DoH tidak ada di log: control.js lama? Jalankan pasang.sh lagi"
dx cat /etc/resolv.conf | grep -q '^nameserver 127.0.0.1' && ok "resolv.conf mengarah ke stub (127.0.0.1)" || bad "resolv.conf bukan 127.0.0.1"
R="$(dx getent hosts example.com google.com youtube.com)"
if [ "$(wc -l <<<"$R")" -ge 3 ] && [ -n "$R" ]; then ok "resolve example.com, google.com, youtube.com berhasil"
else bad "resolve nama situs gagal (hasil: ${R:-kosong})"; fi
grep -q '"dns":true' <<<"$ST" && ok "/status dns:true" || bad "/status dns bukan true"

say "4. UDP / HTTP3"
if grep -q '"udp":true' <<<"$ST"; then ok "UDP lewat tunnel jalan: HTTP/3 dan WebRTC srflx bisa"
else warn "UDP tidak diteruskan proxy (HTTP/3 off, Chrome jatuh ke HTTP/2). Tidak ada kebocoran."; fi

say "5. Kunci jaringan (kill-switch & IPv6)"
POL="$(dx iptables -S OUTPUT | head -n1)"
[ "$POL" = "-P OUTPUT DROP" ] && ok "iptables OUTPUT = DROP" || bad "kebijakan OUTPUT bukan DROP ($POL)"
P6="$(dx ip6tables -S OUTPUT | head -n1)"
[ "$P6" = "-P OUTPUT DROP" ] && ok "ip6tables OUTPUT = DROP (IPv6 mati)" || warn "ip6tables: ${P6:-tidak ada}"
if dx curl -s -m 5 -o /dev/null -6 https://ipv6.google.com 2>/dev/null; then bad "IPv6 masih bisa keluar!"; else ok "IPv6 tidak bisa keluar"; fi

say "6. Bot (.env)"
WD="$(sed -n 's/^[[:space:]]*data:[[:space:]]*//p' /etc/pterodactyl/config.yml 2>/dev/null | head -n1 | tr -d '"'"'")"
FOUND=0
for D in "$WD" /var/lib/pterodactyl/volumes /srv/daemon-data; do
  [ -n "$D" ] && [ -d "$D" ] || continue
  for F in "$D"/*/.env; do
    [ -f "$F" ] || continue
    grep -q '^BROWSER_PROXY_MODE=sidecar' "$F" || continue
    FOUND=1; echo "  bot: $(dirname "$F")"
    grep -q '^SIDECAR_URL=' "$F" && ok "SIDECAR_URL ada" || bad "SIDECAR_URL tidak ada"
    T2="$(grep -E '^SIDECAR_TOKEN=' "$F" | head -n1 | cut -d= -f2-)"
    [ -n "$T2" ] && [ "$T2" = "$TOKEN" ] && ok "SIDECAR_TOKEN sama dengan sidecar" || bad "SIDECAR_TOKEN di bot beda/kosong"
    grep -qE '^ALLOW_DIRECT_IP=1' "$F" && bad "ALLOW_DIRECT_IP=1: IP VPS bisa dipakai! Hapus baris ini" || ok "ALLOW_DIRECT_IP tidak aktif"
  done
done
[ "$FOUND" -eq 1 ] || warn ".env bot dengan BROWSER_PROXY_MODE=sidecar tidak ditemukan di folder Wings (data: ${WD:-tidak terbaca}). Cek manual di panel."

if [ "${1:-}" = "--killswitch" ]; then
  say "7. Tes kill-switch (tunnel dimatikan sebentar)"
  dx pkill tun2socks >/dev/null; sleep 2
  if dx curl -s -m 6 -o /dev/null https://1.1.1.1; then bad "KILL-SWITCH GAGAL: masih bisa internet tanpa tunnel!"; else ok "tunnel mati, internet langsung terputus"; fi
  echo "  memulihkan tunnel (bisa sampai 3 menit)..."
  REC="$(api /ensure 170 POST)"
  grep -q '"ok":true' <<<"$REC" && ok "tunnel pulih (IP bisa berganti)" || bad "tunnel belum pulih: docker logs --tail 30 fp-sidecar"
else
  echo; echo "  (tes kill-switch dilewati. Jalankan: bash $DEST/tes.sh --killswitch)"
fi

echo
if [ "$FAIL" -eq 0 ]; then printf "${G}HASIL: SEMUA LOLOS${N} ($PASS OK, $WARN peringatan)\n"
else printf "${R}HASIL: $FAIL GAGAL${N} ($PASS OK, $WARN peringatan). Kirim keluaran ini ke Claude.\n"; fi
exit 0
