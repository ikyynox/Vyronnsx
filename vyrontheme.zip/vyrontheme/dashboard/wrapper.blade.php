@verbatim
<script>
(function () {
  if (window.__vyHeader) return;
  window.__vyHeader = true;

  // Ubah teks status di sini kalau mau
  var STATUS = {
    running:  { cls: 'vy-on',   text: '\u2714 ONLINE \u00B7 JANGAN MELEBIHI BATAS CPU & RAM!' },
    offline:  { cls: 'vy-off',  text: '\u26A0 SERVER MATI! CEK CONSOLE SEBELUM START!' },
    starting: { cls: 'vy-warn', text: '\u26A0 SEDANG START \u00B7 JANGAN SPAM TOMBOL!' },
    stopping: { cls: 'vy-warn', text: '\u26A0 SEDANG STOP \u00B7 TUNGGU SAMPAI MATI!' }
  };
  var SUSPENDED = { cls: 'vy-off', text: '\u26A0 DITANGGUHKAN \u00B7 HUBUNGI ADMIN!' };
  var LOADING = { cls: 'vy-warn', text: 'Memuat\u2026' };

  var ICON = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 3 7.5 12 12l9-4.5z"/><path d="M3 12l9 4.5 9-4.5"/><path d="M3 16.5 12 21l9-4.5"/></svg>';
  var cur = { id: null, name: '', state: null, suspended: false, last: 0, busy: false };

  function sid() {
    var m = location.pathname.match(/^\/server\/([^\/?#]+)/);
    return m ? m[1] : null;
  }

  function get(path) {
    return fetch('/api/client/servers/' + path, {
      credentials: 'same-origin',
      headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (r) {
      if (!r.ok) throw new Error(r.status);
      return r.json();
    });
  }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }

  function build(id) {
    var h = el('div');
    h.id = 'vy-server-header';
    var back = el('a', 'vy-back', '\u2039');
    back.href = '/';
    back.setAttribute('aria-label', 'Kembali');
    var icon = el('div', 'vy-icon');
    icon.innerHTML = ICON;
    var meta = el('div', 'vy-meta');
    meta.appendChild(el('div', 'vy-name', '\u2026'));
    meta.appendChild(el('div', 'vy-status vy-warn', 'Memuat\u2026'));
    var more = el('a', 'vy-more', '\u22EE');
    more.href = '/server/' + id + '/settings';
    more.setAttribute('aria-label', 'Pengaturan');
    h.appendChild(back); h.appendChild(icon); h.appendChild(meta); h.appendChild(more);
    return h;
  }

  // Hanya menyentuh DOM kalau isinya benar-benar berubah (sebelumnya ditulis ulang tiap detik)
  function paint(h) {
    if (!h) return;
    var st = cur.suspended ? SUSPENDED : (STATUS[cur.state] || LOADING);
    var name = cur.name || '\u2026';
    var key = name + '|' + st.cls + '|' + st.text;
    if (h.__vyKey === key) return;
    h.__vyKey = key;
    var n = h.querySelector('.vy-name');
    var s = h.querySelector('.vy-status');
    if (n) n.textContent = name;
    if (s) { s.className = 'vy-status ' + st.cls; s.textContent = st.text; }
  }

  function refresh() {
    if (document.hidden) return; // tab tidak aktif: jangan ambil data
    var now = Date.now();
    if (cur.busy || now - cur.last < 5000) { paint(document.getElementById('vy-server-header')); return; }
    cur.busy = true; cur.last = now;
    var id = cur.id, jobs = [];
    if (!cur.name) {
      jobs.push(get(id).then(function (j) {
        cur.name = j.attributes.name || '';
        cur.suspended = !!j.attributes.is_suspended;
      }));
    }
    jobs.push(get(id + '/resources').then(function (j) {
      cur.state = j.attributes.current_state;
    }));
    Promise.all(jobs).catch(function () {}).then(function () {
      cur.busy = false;
      paint(document.getElementById('vy-server-header'));
    });
  }

  function tick() {
    try {
      var id = sid();
      var old = document.getElementById('vy-server-header');
      if (!id) { if (old) old.remove(); cur.id = null; return; }
      if (cur.id !== id) {
        cur = { id: id, name: '', state: null, suspended: false, last: 0, busy: false };
        if (old) { old.remove(); old = null; }
      }
      if (!old) {
        var link = document.querySelector('a[href="/server/' + id + '/files"]');
        if (!link) return;
        var bar = link.parentElement;
        for (var i = 0; i < 3 && bar.parentElement && bar.parentElement.children.length === 1; i++) {
          bar = bar.parentElement;
        }
        bar.classList.add('vy-tabbar');
        bar.parentNode.insertBefore(build(id), bar);
      }
      refresh();
    } catch (e) {}
  }

  // ---- Pengganti :has() di CSS: tandai navbar & kartu login lewat kelas ----
  function tagStatic() {
    try {
      var lg = document.getElementById('logo');
      if (lg && lg.parentElement && lg.parentElement.tagName === 'DIV') {
        var nav = lg.parentElement.parentElement;
        if (nav && nav.tagName === 'DIV' && !nav.classList.contains('vy-nav')) nav.classList.add('vy-nav');
      }
      if (!document.querySelector('.vy-login')) {
        var im = document.querySelector('img[src*="pterodactyl"]');
        if (im) {
          var p = im.parentElement;
          if (p && p.tagName === 'DIV' && p.parentElement && p.parentElement.tagName === 'DIV') p.parentElement.classList.add('vy-login');
          var f = im.closest('form');
          if (f) f.classList.add('vy-loginform');
        }
      }
    } catch (x) {}
  }

  // ---- Putihkan semua blok abu-abu (tab bar, grafik, tombol abu) berdasarkan warna aslinya ----
  // Versi cepat: hanya elemen BARU yang diperiksa, baca-semua dulu baru tulis-semua (tanpa layout thrashing),
  // dan isi console (.xterm) dilewati.
  var TAGS = { DIV: 1, NAV: 1, BUTTON: 1, SECTION: 1, A: 1, LI: 1, UL: 1, HEADER: 1, MAIN: 1 };
  var seen = new WeakSet();
  function isGrayBg(cs) {
    var m = cs.backgroundColor.match(/rgba?\(([^)]+)\)/);
    if (!m) return false;
    var p = m[1].split(',').map(parseFloat);
    var a = p.length > 3 ? p[3] : 1;
    if (a < 0.3) return false;
    var mx = Math.max(p[0], p[1], p[2]), mn = Math.min(p[0], p[1], p[2]);
    var l = (mx + mn) / 510, d = mx - mn;
    var s = d === 0 ? 0 : (d / 255) / (1 - Math.abs(2 * l - 1));
    return l > 0.25 && l < 0.5 && s < 0.3;
  }
  function whiten(xt, hd) {
    var all = document.body.getElementsByTagName('*'), add = [], i, e;
    for (i = 0; i < all.length; i++) {
      e = all[i];
      if (!TAGS[e.tagName] || seen.has(e)) continue;
      if (e.classList.contains('vy-white')) { seen.add(e); continue; }
      if (xt && xt.contains(e)) continue;
      if (hd && hd.contains(e)) continue;
      if (!isGrayBg(getComputedStyle(e))) { seen.add(e); continue; }
      var r = e.getBoundingClientRect();
      if (r.width < 40 || r.height < 28 || r.width * r.height < 1500) continue; // mungkin nanti membesar: cek lagi
      seen.add(e);
      add.push(e);
    }
    for (i = 0; i < add.length; i++) add[i].classList.add('vy-white');
    // induk yang ukurannya sama persis dengan kartu putih ikut diputihkan (hanya untuk kartu baru)
    var pend = [];
    for (i = 0; i < add.length; i++) {
      var c = add[i], p = c.parentElement;
      if (!p || p === document.body || p.id === 'app' || p.classList.contains('vy-white')) continue;
      var pr = p.getBoundingClientRect(), cr = c.getBoundingClientRect();
      if (Math.abs(pr.width - cr.width) < 6 && pr.height >= cr.height - 1 && pr.height - cr.height < 14) {
        var bg = getComputedStyle(p).backgroundColor;
        if (bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent') pend.push(p);
      }
    }
    for (i = 0; i < pend.length; i++) pend[i].classList.add('vy-white');
  }

  // ---- Sejajarkan kartu console dengan kartu lain (induknya punya padding ekstra) lalu refit xterm ----
  var firing = false;
  function fireResize() {
    firing = true;
    try { window.dispatchEvent(new Event('resize')); } catch (x) {}
    firing = false;
  }
  function alignTerm(w) {
    try {
      var tw = document.documentElement.clientWidth - 44, changed = false;
      if (Math.abs(w.getBoundingClientRect().width - tw) > 1) {
        w.style.setProperty('width', tw + 'px', 'important');
        changed = true;
      }
      var r = w.getBoundingClientRect();
      if (Math.abs(r.left - 22) > 1) {
        var ml = parseFloat(getComputedStyle(w).marginLeft) || 0;
        w.style.setProperty('margin-left', (ml + 22 - r.left) + 'px', 'important');
        changed = true;
      }
      if (changed) { setTimeout(fireResize, 150); setTimeout(fireResize, 900); }
    } catch (x) {}
  }

  // ---- Bungkus console + kolom command jadi satu kartu membulat (tanpa bergantung pada #terminal) ----
  function wrapTerminal() {
    try {
      var inp = document.querySelector('input[aria-label="Console command input."]');
      if (!inp) return;
      var xt = document.querySelector('.xterm');
      var w = null;
      if (xt) {
        w = xt.parentElement;
        while (w && w !== document.body && !w.contains(inp)) w = w.parentElement;
      } else {
        w = inp.parentElement;
        while (w && w !== document.body && w.getBoundingClientRect().height < 250) w = w.parentElement;
      }
      if (!w || w === document.body || w === document.documentElement) return;
      if (!w.classList.contains('vy-term')) {
        w.classList.add('vy-term');
        if (xt && xt.parentElement && xt.parentElement !== w) xt.parentElement.classList.add('vy-termbox');
        setTimeout(fireResize, 400);
        setTimeout(fireResize, 1500);
      }
      alignTerm(w);
      resetScroll(w);
      checkFit();
    } catch (x) {}
  }

  // ---- Kembalikan scroll horizontal wadah console ke 0 (cegah isi tergeser ke kiri) ----
  function resetScroll(w) {
    try {
      var n = document.querySelector('.xterm');
      while (n && n !== document.body) {
        if (n.scrollLeft) n.scrollLeft = 0;
        if (n === w) break;
        n = n.parentElement;
      }
      if (w && w.scrollLeft) w.scrollLeft = 0;
      // koreksi cadangan: jika layar xterm masih lebih kiri dari kartu + padding, geser balik
      var sc = document.querySelector('.xterm-screen'), xe = document.querySelector('.xterm');
      if (sc && xe && w) {
        var d = sc.getBoundingClientRect().left - (w.getBoundingClientRect().left + 12);
        if (Math.abs(d) > 3 && Math.abs(d) < 80) {
          var m = parseFloat(xe.style.marginLeft) || 0;
          xe.style.setProperty('margin-left', (m - d) + 'px', 'important');
        }
      }
    } catch (x) {}
  }
  // Dulu: jalan di SETIAP scroll halaman (memaksa layout tiap event -> scroll patah-patah). Sekarang hanya scroll/fokus di dalam console.
  var rsPending = false;
  function resetScrollSoon() {
    if (rsPending) return;
    rsPending = true;
    requestAnimationFrame(function () {
      rsPending = false;
      var w = document.querySelector('.vy-term');
      if (w) resetScroll(w);
    });
  }
  document.addEventListener('scroll', function (e) {
    var w = document.querySelector('.vy-term');
    if (!w || !e.target || e.target === document || !w.contains(e.target)) return;
    resetScrollSoon();
  }, true);
  document.addEventListener('focusin', function (e) {
    var w = document.querySelector('.vy-term');
    if (w && e.target && w.contains(e.target)) resetScrollSoon();
  }, true);

  // ---- Kalau lebar layar xterm melebihi area yang tersedia (teks terpotong), paksa refit ----
  var lastFit = 0;
  function checkFit() {
    try {
      var xe = document.querySelector('.vy-termbox .xterm') || document.querySelector('.xterm');
      var sc = document.querySelector('.xterm-screen');
      if (!xe || !sc) return;
      var cs = getComputedStyle(xe);
      var avail = xe.clientWidth - (parseFloat(cs.paddingLeft) || 0) - (parseFloat(cs.paddingRight) || 0);
      var sw = sc.getBoundingClientRect().width;
      if (avail > 0 && Math.abs(sw - avail) > 20 && Date.now() - lastFit > 2500) {
        lastFit = Date.now();
        fireResize();
      }
    } catch (x) {}
  }

  // ---- Bulatkan semua tombol besar (Start / Stop / dll), tombol ikon kecil dibiarkan ----
  function roundButtons() {
    try {
      var b = document.getElementsByTagName('button'), pend = [], i, r;
      for (i = 0; i < b.length; i++) {
        if (b[i].classList.contains('vy-btn')) continue;
        r = b[i].getBoundingClientRect();
        if (r.width >= 80 && r.height >= 34) pend.push(b[i]);
      }
      for (i = 0; i < pend.length; i++) pend[i].classList.add('vy-btn');
    } catch (x) {}
  }

  // ---- Penjadwal tunggal: ganti 3x setInterval(800ms) yang jalan terus meski tidak ada perubahan ----
  var pending = false, lastPath = location.pathname;
  var ric = window.requestIdleCallback || function (f) { return setTimeout(f, 30); };
  function run() {
    pending = false;
    if (document.hidden) return;
    try {
      if (location.pathname !== lastPath) { lastPath = location.pathname; seen = new WeakSet(); }
      var xt = document.querySelector('.xterm');
      var hd = document.getElementById('vy-server-header');
      whiten(xt, hd);
      roundButtons();
      wrapTerminal();
    } catch (x) {}
  }
  function schedule() {
    if (pending) return;
    pending = true;
    setTimeout(function () { ric(run, { timeout: 800 }); }, 150);
  }

  function startObserver() {
    var mo = new MutationObserver(function (muts) {
      // Abaikan perubahan di dalam console (output server bisa ratusan mutasi per detik)
      var rel = false;
      for (var i = 0; i < muts.length; i++) {
        var n = muts[i].target;
        if (n.nodeType === 3) n = n.parentNode;
        if (n && n.closest && n.closest('.xterm')) continue;
        rel = true; break;
      }
      if (!rel) return;
      tagStatic();
      schedule();
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

  window.addEventListener('resize', function () { if (!firing) schedule(); });
  document.addEventListener('visibilitychange', function () { if (!document.hidden) schedule(); });

  if (document.body) startObserver();
  else document.addEventListener('DOMContentLoaded', startObserver);
  tagStatic();
  schedule();
  setInterval(schedule, 5000); // jaring pengaman, murah karena pemindaian bertahap
  setInterval(tick, 1000);
  tick();
})();
</script>
<script>
(function () {
  var ICON = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAXe0lEQVR42u2d+3Mc1ZXHv+fe290jaSSbh21s2JAABiPbmJDllVRinIRssgsxYCTzyiZs8hekskUqlZSsSiq11CbZ1FaqUhvyKsIjlnDAkAeGsMbZJQGTZG2MbYSNHcC2wPgh6zEz/bj37A/dPZoZjaRpWY+Z8XSVymNN6850f+6595zvOfc24TSOri4Wy/eAOntJx7/78V18YQbedQK4Rhv/eiKRAsxKglAAAwCooI3C12CAonMmOo+icys6r6jtBH/Dhf/nGWy73GsCwwTEchdgcpLUn4QQ2y3LfvGmR+jN+LyeDpa728Hd3WSmypCmA/wP/5nPD7S/nsjcwoZXKem0SSJowwAYgXbL3sTSm1LRzS7pAJOelwBQ+bZ5Btue6DXBFg4IBCUkAqMRaG+QBO0Uhp6QUm+8ubfl8Ol2hMQdoGs1q+5tFADA9+9xVyimL4PM7SnLaQ0M4Acu2ASGASYGEQAQiYblJ4Eftc0cA2UCSAgpbNkESxByQXYIjMcCo7+37vHWVwFg62pWayI2094BmJk2bAB1d5O5/+5Tl7Wg6T4mfbejUnbOz4FZBwCIGAIx90SAeGZuYi3CB0BjOjqDwSwYhgksSKoWqwWun/EI9HDWH7m/88kFfV1dLDZ0g6mohdPsAD0dLOPh/j/vyn2dhPiKY1nzsm4GDKMJJAhEU7fOBvyJ4YeNUIlJgtkQhGy1W5Hz3VMawXdu+VX6W6XMTqsDxEP+t24dXtzWbP2sybb/IePlwEYHRCTjNqgBfxbhF02HDLCWJFXaakE2yG45aYbv/dzjC/srmRKoEsv/986Bq5uc5s2WsBZnvJGACJKiYb4Bf3bhj9c2gxlgnbbmKd94/Tk9uHbd4wte5g6WNMFIICay/M5e0t+7Y6izyWnaIkguznjDgSBSVDDHN+DPPfwQJJGAUMP+qUBALG4WrVt+dctAJ/WS3rqaVaIO0NUVDvvfvXNwXTqV3mgMn+X6GSNIqOnxyBvwpxN+4WsJodxgxASsz5rvzNv4+NqT69Zso2C8TkDlYvzubjLfvXPgGkc1P83MbYHxIUCyAb+64Rd/b9YW2RBEgxl3+NO3/ebc7dzFgkq0gqK/6QKLboC/f8fwQiGtV6S0Fnqh5YsG/BqCH7XNbExKNQvNwVHf11esfSp9tAugbox2Aip1+na3g+fvyz7dbDfdmHFHAkHUGPZrCH4pI4YJWq15asQfevbPq1o/vWEPqNApFKUe/7zXh77ammrArwf4BEBAqCF/MJjntN541Y5TX6Ve0tzBsqgDdHWx6OiB+e492Uts6dyXcXOGCI05v8bhF0CWI27GpKRz3+abBy5BD0xXF4t8B1i+B0RETEHwDcey24zRpjDUa8CvXfgEgEAUIDBNKtUmBb5BRLx8TyzgRZ7hf9x96jKLUjuN0RaDCbGg34Bf0/ALr1CAWJHytfZWfebJeX3cxUJseP75MFPH6mu2sh3Dmhvw6wt+OAqAjNGckimHib4GABuef14QAPzg83yeCXJvENCkWYNA1FD46gd+PmMAZgkFIs46Fi5e05t+RwCA8TN3NlupZm20Fg349Qe/QC42CHTaamn2XL4TAERHR480zOsCZhChkdKtR/gF10oMCoyBIbOup6NHimvFJ5aAaJUfeABDNODXL/zoTeHqHABa1eZ9YolQwv6Io1JpNkFx6NeAX3fw45DQsG9SMpU2LD8iBOS1EiL0ERrw6xp+oTeohAWCuFYA5hptGPkCzgb8uoYfh4SB8QGYawRAzeN+0Qb8uoOPov9TswB4RaDdCku3G/DrAj6R8AIXAFaoylfsNODXA/zRthkCpEQD/pkIf/T9xrB/hsKP3xMN+Gcu/FAebsA/Y+ETypWFN+CfMfABQDUs/8yFXzQFNOCfefABQI02zDNzExvwqxJ+fgqY8U0OigQoQIjJb0o5+AwApuDiqhU+ASROAz4DbGbe8jHqA/CswdcekMvxGM+TKrR8K0WQ9tgbVE3wWQP+IE/Z8oUFWE1UQUfnaRlV1GzAFwQELmPRMon3Xa1gAgaJ8CKJAOaSdGVBmxy3R8BbLwY4vl/DcgjM1QnfaSUs67TjLTPGdHRmjPk9otGNBDD0lsGR5z0Ih8LfzSB8in2AmZ7zGQAJQnaAsXKtBSExpeO8FRK//ddMvtFqmvNJAP4pRvudDi5bb2Oqx1/+LQsTANIpM0pOM/wJlcBpdfgYUA5w4m8GL/zQBRBOB6wBU8EPa0D7wMLLJd53vYI3whP7ErPt8BFgPCB9gcAH/tGCCQAThN+7kh/jhSPDoed8vLXFh50OrX+m4Y+rBM6Et88aSLUR3tgW4MRBA2mHbwg5+Q9F/wLA39/rhFOAqR5vXwggGGEs/7wDuzUc+oUKv/ekPwIgBegsY3+PC6t59uDnlcDZCvWEAIIcY/vPvTzASg8SofPXtkTgsn+ywlFAVgn8DGPBlQoXfNQKHdQEUxxHc/+Bx30M7DNQKZTxb3jGwkgxm3E+G8BJE956OcDB/w1CqDpBJ4gcxivW20gvEDBeFHbNcZzPBlh5rwOhknXqGP5Iv8H+HhdOG+Xvx2zALz8FzLDIwwawHGBHjwc/wwWufiU9IPSW7RZC+y0WvGyBLzAH8EkA/jBjyfUWzlku80CTDW3A6w95CLKcHzlmCz6VSsGzofCBASsFHN+vsftJHyQAY5JPBctutrHgUokgO/ohc2H5qpmw8otOYm8/7izHdmgcetaDnQ6tfzbh56eARCCnQd41kUO4a5OHwX4DEUGteBTg0Mlqv81GkGMImn34JEPrv/DjFtLnixBepdYftcsa2POjXH7qmG344RQwS5ZfqvAJCXgZxs5feol3LCYZdpj3f1Th765V8IY5f/NnRduPwr7mhQKX3+OE4k6CoT8+/+1nfAzs05BNhZ7/7MGfPAycwcSOiVSz/f/to3+nzg/tSSODlXfYYTTAs5fYESIM25beasOZH8GjBNZPgDvA6HvQhUrNDXyaNAzEzGf1KLLml3/qjkYDXDl81sCCdolLPmXBGyrnRE0/fBKAzgJnXSpx8Vo7sePHJoxmXv+Fi+x7kR7Cs2/58cgv5jKlywawU4Tj+zT2/T50CJmTDAFh85ffZsNuKXWiZgB+FIoGLmPp7VHYx5Vbf6wRnDpgcOhZP+/4zYXlVzwFzHQ+nw2gUoQdD3vIDiQLC+Npo3WJQPvtNvzhEnFouuELwB9hLL5O4YKPqcSiT9wJ9v44B52L/ZbZhV96rWIu4ccXK20g857Bzkc8EE0hLGTg0psttCwQ0N5EexhPwyaMBli23kkc78dRwpE/+Dj6UgCrlcBmbuFPmAyazUoeaMBOE954zseJgwZCJg8L7TRhxd12KKiI6YdPEvCHGBd+0sY5KxKKPtE0EWQY+x8JHb9qgD/uFDAXZVwkAJ1j/PVnbvJogMIOc/GNFs5ZKvOdYDotn3VYqLHs7uSp3rizHHzcw+B+A5nisSPUHMCfpCx89uDHQ6vTSjj0coA3k+YJaNRKr/ySU1BgwtMCX0ggGGIs7XTQsjiZ6BPDz/QbvNHjwWoLR7xqgD9WCZzjAs4wT0DYtdFNnCeIHcJFqySWXKXgD4dh4WkXcBJgXKBpgcBFn7USiz7Fer8Zm8GcQ/hA2bLwuYEfK2RWCjixz2Dv5uR5gvi44gsOZFMZS0vq8MVhX45x+eecsFAjadiX1/tdWOmSbN8cwx/dFKpKSrcJYSWN00bY+5iHoYR5gnjamH+RwAc+XiwOJbb8aHgMMoz5l0hc+CkrL+Ik1fv3/igbFohUkeVTNDWKaqzbFxLwsoxdjybPEyAKC5fdbqPpHAIHEbQp1u2zAS6/xxntSJVaf17v93Bqn4ZqotFq5iqwfEwWBs7log3WYeHIwed8vJswT0BRzUDLeQKX3erAG5w8UVQOfpztO+9qhcUfVlMK+9wBxusPxmFfdVl+fK6oNvhFQ7AE/voTF2YqeQIDXHyThbOWSuhscU+vyPI1oJoI7V9IVV6wUqL37/tFDrn3DISNonqLuYRf2raoVvhsQgAn9mkcfDZhniAa8q1mwuXrHQTZ0a5eCfxY9HnfJyzMu1gksv5YHh48oHH4WR9WmgB9Ok9Xmzn4lU0Bc7hWDyZcDfTKwx5ySfMEkZp4wUcUFl2pEGS4omVpIIADoOkcwiUddtjpRPIR4LUfuwhivb9K4Y+rBFbNQk0GhA1kjhq8+pCXV/wS+YQWsOJep+jvJpJghQit/+J1DlrOE+HqnEodv0gg6v+Dj6PbfditVD4UrRL4CcrC526VLgejDuHAAZO37CS+wLnLJc6/3oJfbkEJl4g+0QKP93/GOi29Xzrj1fdXD/zxp4BqWqIdgQxyjB0/TZ4niI+VX3SgSheU8NjP8UcY7V8IF3hMRfQJ9X4N5WDixStVAL/8FFCF6/M5yhP0b/fx9v/4ifIE8SiQPl/gopvscBSQ5eEHGcaCDyosSbjAo1DvP9Djwm4tV99fffDHJoOqeXMGw1ApYM8vp5AniBaULLvDRvMCAeOibCk5DLB8Cgs84ob2P+RCZ8qXplUj/PwUQNUOP1LWVIowsN9gX5QnSFQzYAArTVh6qw2/JF0cL/BY/GELZydc4BGfe3xHgEPPenm9vxbgj04BNbItC2vAbiO81uti+IhJphBG51601sbZl4biUAyZTZjrX/6lhAs8ou9qAuC1/8rlM321Ah9xLqAW4BeC1DnGzp+4yfIEBQtKlnY4MC7nVycHw4wLPmmhZcnUcv1vPuFioK+0vr+64ZcpC6+RDZlMqPAd+aOPo0nzBFEIef7HFBZdpxAMcyj6LBRYlnSBRyQQuQOMg5s8qObagV94vqjV3biEBF55IAcTJMsTxKPIsrscSJvgjzAuuS35Ao+83v9gDtl3C+v7a8Py8/exFuEjzhP0aezf7CX3BTRwdrvEko8ptCwRuOgWe0p6/8ndAQ79zoPdNnnYVy3wS9sWtQa/qHysmbDvcQ/uQJTsSZgsumitg+X/kkqc648/f//D3mi9QQ3CH18JrHL48d/LKE+w5yE3UZ6ARNjY/KUCS1ar0d8l0fu3+XjvRT+q769N+OWVwFqAXwDDaSP87WkPx/foRHmCfNuc8PxIM3j9p7niKp8ahD8DZeGzB7/QoWENvPbIFPIElHzYJwLe2uwhc9hAOOPn+WsBfrESWIPwYyh2mvDOSwEObUu+71Ai+ALIHDY4sNGFNUGqt1bgF00BtbzxcrxqZ8/Pc/CHEzqECUeM1x7IFe3nU8vwi6Tgmt51OyocGTlscOBJf0qFIxP5BoV6/9E/jpZ51TL8USWwTrZchwbsVsK+HhcjCfME4/oGPFbvL0oi1bDlY7IwsBb326do65bdD7jJ1xMUHO7rDP9IeNc52v79zc0uBvs0VDMl2M69ei0/PlfVC/xYIbTShP4/+Ti208a5qxKkdqPqHzMEZP/PhDdnEaH5QwI5z+DAo25dwC9tW9QL/MIHS5AEdv9oankCt8+EhaA2EPQzMts0Tv5aw1IULjbl+oFf2RRQY49ZQZTbH+jTOPhEhXmCeJ4fAry/McgK2yEH0DmgtVXgg3c0o3WRDJ91UCfwx1UCa/kZO3FYqJoIB36VIE9AofWzVzqchHcpe9Jg5JgBSSp5wEXtwp++3cKrBH7hhUobyB416HtwkjxBBFmfBLyDDLLHhoBCEo7s8uGPhKuV6wX++FNAHTxdKy4fO/S0h5O7J88T5F4x4KC4MWZAWoThYxrH3wigktb6Vzn88lNAnT1azWjg9fHyBPFijvcYfv9Y649LyPp3+dC5Cp5SUmPwJykLr334bAArDRx90Uf/tvHXE7h7xzoIzIC0CYNHNI7vD8YuKqkD+PkpgOoQfv6NqHCk72dhniC/WLPQ+o9Env+Yz2W8/WcPxudJiz5qEX5RLqAe4RcuMB05ZPDm5nDHkcLpwN3LYyKE2PpPHdIYPKxD6+f6gx/uEXQGPE41zhMc2Ohi5LDJVwT5hyLrt8d+NjOj/xUfzFyXlj+6R1Cdw8+LNgIIsoy+B3L5USD3Ko+5yELrP3VIQ9o0+XerQcvPO7lnyoOUOcoTHH3Bx4ndAfg4EBxjkCo/98fWX6+WX1AWXv/w8yohA5DA3h/kMPIXPbp3T6H1O4Rj+wIMvB1AFVh/vcAvbVucKfDzrwXQkhLgkTDVW3StBGiPcXiHX/QconqFP74SWKfwAUAIwtkfULCaCUKNRgRsAGUTjr8RIHMsnPuZ6xv+uFNAXVp+3I4E9m3Noe+ZHLInDaym6CnfBAQe491dfrhd/RkAv+zTw+sWfuFrDby718fxNwIsWWlhYbuFlnMFjuzwMXxMw0qNo/nXGXwAUFSy1Ubdw49exJDf/rOHo30Bzltu4cSBoOz2MfUKn0BQYbmjUBg35Kkz+EBRsafVRNA5xlsvupA2Qcoynn8dwg/P4kCA8aotHBCPCqT1Dr+0gohEOCKU3U62DuEzs0lJB8T8qmBGhor6xZkDn8qIY/Vv+XHlFIFBGSFIbFfh5jZ8psI/E7z9ktesyIIAbVfM/JI2OuwSE20W0YBfL/ABAgXGhzF4SWjjveAF2WFJSjCYG/DrGz6DWUGJnM4NS9IvCGk/d4RhdjrSgWCYBvw6tvwwzDdNogkE3rl33nNHRGdvpxZCbFJCgKMWG/DrE378CZZUECQ2dfZ2agEAjqBHM/5IRkDJ/GMZGvDrCz6H8Z+ElIPeUAZCPgoAomv1VnVTb/odzeaxFquZwGwa8OvP8sN7ySZttZKBfmzFb9PvbF29VYkNN9xgAEAF/G1X51wBSSjJlDbg1zj8aEwXJCmnsy5DfBsAbrjhBiOom0xPB8tbnpzX5wXuxrSdLiqebsCvC/hgsJ5vzROuyW1ctWVeH3ewpG4yAgB2t4OZmSyNb+aC3KDEBCFhA34twmeLlBjRmUHJwTcZTGgPWxMA0N1NBp0Qa5+av98L3PvTTrNAwRZIDfi1Cz9qQ7dZrcI12ftXPLNoPzogqJvM2O/UwXJDO/iDO4eebrFbbxz2TwWi4PEJDfi1B59hgjY1Xw0Hg8+uuG7+p7EHRL1U1rjRBRYbAH705uGFrbZ8RZFa6AYZQxSuiqMG/NqCz8Y0yxYRcHDUt4avWPnUoqMAiEB5wa9obWA3yKALdNdTre9mdeZmsDlpCYfBrBvwaws+mLUjHDbMJ3Nm6OYrnjrvXXQVwx9HKAK2rma1ZhsFj609ue5sZ/5jGT8DbXxDJEQDfm1YviUskVatOOEdv/3KZ87dxKtZ0TYKSlmX3T5pzTYKtq5mdfvmszYNZE+tlyRPplSL4NFddxrwq9XyYYJm1SIk1Mnj/on1Vz5z7qat48AfdwQodAqpl/Smm967Ou20bbaEvXjYPxUQSFLB8zSpAb8qQj0C61Y1X/nG6x/m4bVXPb3g5ZjheIwn3ECNeklvXc1q3a8XvDxsTn0oF2S3zLfnKUmSwoetRIohN+DPhbYfK3wMDhRJOss6W2V1ZsugefdDVz294GVezWoi+JOOAPHR08GyM2rod7cNf51YfaXJcuYNe0NgYzQRibIjQgP+jFk+mBnMhkjI+dZ8ZHT2lDbBd5ZvaftWyKxHdvZ2TrptdsX7aTKYNgDUDTJPfPa9y1pUy33G8N0p1WxngxFo1gExCISoMzTgTzd8BjMxGQKzIKnSqg3ZYNgTEA/nOHP/qi0L+hgswpGZKtodMfGGqnGEAABP3Tq0IsXyy0y4vUk1tWrDcHUWxvgmmh7C9olEJWFkZf7EeJmuyc7jGWx7Kt+bJ22bmQ2NnkwKSjTJJihSyAYjQwA9ZqT5XvtvWl8N2WxVa7atCZLwnNKOul1dLJbvAcXTwu87Rs7XvlxP4FsYepUl7DZFFjT7ABh+4ILBM2P5nMDSasryCSnhgIigSCEwAXztDQqinSA8IYXYeNlvWg7nFdxecHdJjD9jHSB/vV0segs6AgC8cBtfmEH2OtZ8jWH/eiKRYjYrQ0mZG5ZfgeVHq7UCItplmHMW5J9AtL2J0i9e9Ft6szBKQzs41vWncvw/3NUiKJIC/pIAAAAASUVORK5CYII=';
  function setFavicon() {
    try {
      var old = document.querySelectorAll('link[rel*="icon"]');
      for (var i = 0; i < old.length; i++) old[i].parentNode.removeChild(old[i]);
      var rels = ['icon', 'apple-touch-icon'];
      for (var j = 0; j < rels.length; j++) {
        var l = document.createElement('link');
        l.rel = rels[j]; l.type = 'image/png'; l.href = ICON;
        if (rels[j] === 'icon') l.sizes = '128x128';
        document.head.appendChild(l);
      }
    } catch (e) {}
  }
  setFavicon();
  setTimeout(setFavicon, 1500);
})();
</script>
@endverbatim
