@verbatim
<style>
/* VYRON THEME v1.0 - area admin */
:root{
  --vy-bg:#0a0b11; --vy-bg2:#0f111a; --vy-surface:#141725; --vy-surface2:#1a1e30;
  --vy-border:#272c42; --vy-text:#e8eaf4; --vy-muted:#8d93ad;
  --vy-violet:#8b5cf6; --vy-fuchsia:#d946ef; --vy-cyan:#c4b5fd;
  --vy-green:#34d399; --vy-amber:#fbbf24; --vy-orange:#fb923c; --vy-red:#fb7185;
  --vy-grad:linear-gradient(135deg,#8b5cf6 0%,#d946ef 100%);
  --vy-radius:14px;
}

body,.skin-blue .wrapper,.skin-blue .content-wrapper,.content-wrapper,.right-side{
  background:var(--vy-bg)!important;color:var(--vy-text);
  font-family:Inter,"Segoe UI",system-ui,-apple-system,Roboto,sans-serif;
}
.skin-blue .main-header .logo{background:#0c0e16!important;color:#fff!important;font-weight:800;letter-spacing:.14em;border-bottom:1px solid var(--vy-border)}
.skin-blue .main-header .logo:hover{background:#10121b!important}
.skin-blue .main-header .navbar{background:#0c0e16!important;border-bottom:1px solid var(--vy-border)}
.skin-blue .main-header .navbar .sidebar-toggle:hover,.skin-blue .main-header .navbar .nav>li>a:hover{background:rgba(139,92,246,.15)!important}
.skin-blue .main-sidebar,.skin-blue .left-side{background:#0c0e16!important}
.skin-blue .sidebar-menu>li.header{background:#0a0b11!important;color:var(--vy-muted)!important;letter-spacing:.12em}
.skin-blue .sidebar-menu>li>a{color:#b6bbd3!important}
.skin-blue .sidebar-menu>li:hover>a,.skin-blue .sidebar-menu>li.active>a{
  background:rgba(139,92,246,.12)!important;color:#fff!important;border-left-color:var(--vy-violet)!important}
.skin-blue .sidebar-menu>li>.treeview-menu{background:#0a0b11!important}
.content-header>h1{color:#fff}.content-header>h1>small{color:var(--vy-muted)}
.content-wrapper a:not(.btn){color:var(--vy-cyan)}

.box{background:var(--vy-surface)!important;border:1px solid var(--vy-border)!important;
  border-top:3px solid var(--vy-violet)!important;border-radius:14px!important;box-shadow:0 10px 30px rgba(0,0,0,.25)!important}
.box.box-danger{border-top-color:var(--vy-red)!important}
.box.box-success{border-top-color:var(--vy-green)!important}
.box.box-warning{border-top-color:var(--vy-amber)!important}
.box.box-info{border-top-color:var(--vy-cyan)!important}
.box-header,.box-footer{background:transparent!important;border-color:var(--vy-border)!important;color:var(--vy-text)}
.table>thead>tr>th,.table>tbody>tr>td,.table>tbody>tr>th{border-color:var(--vy-border)!important;color:var(--vy-text)}
.table-hover>tbody>tr:hover{background:rgba(139,92,246,.08)!important}
.form-control{background:var(--vy-bg2)!important;border:1px solid var(--vy-border)!important;color:var(--vy-text)!important;border-radius:10px!important}
.form-control:focus{border-color:var(--vy-violet)!important;box-shadow:0 0 0 3px rgba(139,92,246,.25)!important}
.input-group-addon{background:var(--vy-surface2)!important;border-color:var(--vy-border)!important;color:var(--vy-muted)!important}
.modal-content{background:var(--vy-surface)!important;border:1px solid var(--vy-border)!important;border-radius:16px!important}

.btn{border-radius:10px!important}
.btn-primary{background:var(--vy-grad)!important;border:0!important;color:#fff!important}
.btn-success{background:var(--vy-green)!important;border:0!important;color:#052e1f!important}
.btn-warning{background:var(--vy-amber)!important;border:0!important;color:#2a1d00!important}
.btn-danger{background:var(--vy-red)!important;border:0!important;color:#3b0610!important}
.btn-info{background:var(--vy-cyan)!important;border:0!important;color:#062a33!important}
.btn-default{background:var(--vy-surface2)!important;border-color:var(--vy-border)!important;color:var(--vy-text)!important}
.label-success{background:var(--vy-green)!important;color:#052e1f}
.label-warning{background:var(--vy-amber)!important;color:#2a1d00}
.label-danger{background:var(--vy-red)!important;color:#3b0610}
.label-info{background:var(--vy-cyan)!important;color:#062a33}
.label-default{background:#323852!important}

.alert-warning,.callout-warning{background:rgba(251,191,36,.12)!important;border:1px solid rgba(251,191,36,.45)!important;color:#fde68a!important}
.alert-danger,.callout-danger{background:rgba(251,113,133,.12)!important;border:1px solid rgba(251,113,133,.45)!important;color:#fecdd3!important}
.alert-success,.callout-success{background:rgba(52,211,153,.12)!important;border:1px solid rgba(52,211,153,.45)!important;color:#a7f3d0!important}
.alert-info,.callout-info{background:rgba(196,181,253,.10)!important;border:1px solid rgba(196,181,253,.4)!important;color:#ddd6fe!important}
.main-footer{background:var(--vy-bg2)!important;border-top:1px solid var(--vy-border)!important;color:var(--vy-muted)!important}

/* ===== v1.0.2 PERBAIKAN: spesifisitas lebih tinggi ===== */
html body.skin-blue .wrapper,html body.skin-blue .content-wrapper,html body.skin-blue .right-side{background:var(--vy-bg)!important;color:var(--vy-text)}
html body.skin-blue .main-header .logo,html body.skin-blue .main-header .navbar,html body.skin-blue .main-sidebar,html body.skin-blue .left-side{background:#0c0e16!important}
html body.skin-blue .sidebar-menu>li.header{background:#0a0b11!important}
html body.skin-blue .sidebar-menu>li>.treeview-menu{background:#0a0b11!important}
html body.skin-blue .box{background:var(--vy-surface)!important}
html body.skin-blue .main-footer{background:var(--vy-bg2)!important}
html body.skin-blue .content-wrapper{overflow-x:hidden}

/* ===== v1.0.12: ganti teks "Pterodactyl" di header dan footer admin jadi VYRON ===== */
html body.skin-blue .main-header .logo{font-size:0!important}
html body.skin-blue .main-header .logo::after{
  content:"VYRON";font-size:1.15rem;font-weight:800;letter-spacing:.22em;
  background:var(--vy-grad);-webkit-background-clip:text;background-clip:text;color:transparent;
}
html body.skin-blue .main-footer a[href*="pterodactyl.io"]{font-size:0!important;text-decoration:none!important}
html body.skin-blue .main-footer a[href*="pterodactyl.io"]::after{
  content:"VYRON\00AE";font-size:1rem;letter-spacing:.12em;color:var(--vy-violet)!important;
}
</style>
<script>
(function () {
  var ICON = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAXe0lEQVR42u2d+3Mc1ZXHv+fe290jaSSbh21s2JAABiPbmJDllVRinIRssgsxYCTzyiZs8hekskUqlZSsSiq11CbZ1FaqUhvyKsIjlnDAkAeGsMbZJQGTZG2MbYSNHcC2wPgh6zEz/bj37A/dPZoZjaRpWY+Z8XSVymNN6850f+6595zvOfc24TSOri4Wy/eAOntJx7/78V18YQbedQK4Rhv/eiKRAsxKglAAAwCooI3C12CAonMmOo+icys6r6jtBH/Dhf/nGWy73GsCwwTEchdgcpLUn4QQ2y3LfvGmR+jN+LyeDpa728Hd3WSmypCmA/wP/5nPD7S/nsjcwoZXKem0SSJowwAYgXbL3sTSm1LRzS7pAJOelwBQ+bZ5Btue6DXBFg4IBCUkAqMRaG+QBO0Uhp6QUm+8ubfl8Ol2hMQdoGs1q+5tFADA9+9xVyimL4PM7SnLaQ0M4Acu2ASGASYGEQAQiYblJ4Eftc0cA2UCSAgpbNkESxByQXYIjMcCo7+37vHWVwFg62pWayI2094BmJk2bAB1d5O5/+5Tl7Wg6T4mfbejUnbOz4FZBwCIGAIx90SAeGZuYi3CB0BjOjqDwSwYhgksSKoWqwWun/EI9HDWH7m/88kFfV1dLDZ0g6mohdPsAD0dLOPh/j/vyn2dhPiKY1nzsm4GDKMJJAhEU7fOBvyJ4YeNUIlJgtkQhGy1W5Hz3VMawXdu+VX6W6XMTqsDxEP+t24dXtzWbP2sybb/IePlwEYHRCTjNqgBfxbhF02HDLCWJFXaakE2yG45aYbv/dzjC/srmRKoEsv/986Bq5uc5s2WsBZnvJGACJKiYb4Bf3bhj9c2gxlgnbbmKd94/Tk9uHbd4wte5g6WNMFIICay/M5e0t+7Y6izyWnaIkguznjDgSBSVDDHN+DPPfwQJJGAUMP+qUBALG4WrVt+dctAJ/WS3rqaVaIO0NUVDvvfvXNwXTqV3mgMn+X6GSNIqOnxyBvwpxN+4WsJodxgxASsz5rvzNv4+NqT69Zso2C8TkDlYvzubjLfvXPgGkc1P83MbYHxIUCyAb+64Rd/b9YW2RBEgxl3+NO3/ebc7dzFgkq0gqK/6QKLboC/f8fwQiGtV6S0Fnqh5YsG/BqCH7XNbExKNQvNwVHf11esfSp9tAugbox2Aip1+na3g+fvyz7dbDfdmHFHAkHUGPZrCH4pI4YJWq15asQfevbPq1o/vWEPqNApFKUe/7zXh77ammrArwf4BEBAqCF/MJjntN541Y5TX6Ve0tzBsqgDdHWx6OiB+e492Uts6dyXcXOGCI05v8bhF0CWI27GpKRz3+abBy5BD0xXF4t8B1i+B0RETEHwDcey24zRpjDUa8CvXfgEgEAUIDBNKtUmBb5BRLx8TyzgRZ7hf9x96jKLUjuN0RaDCbGg34Bf0/ALr1CAWJHytfZWfebJeX3cxUJseP75MFPH6mu2sh3Dmhvw6wt+OAqAjNGckimHib4GABuef14QAPzg83yeCXJvENCkWYNA1FD46gd+PmMAZgkFIs46Fi5e05t+RwCA8TN3NlupZm20Fg349Qe/QC42CHTaamn2XL4TAERHR480zOsCZhChkdKtR/gF10oMCoyBIbOup6NHimvFJ5aAaJUfeABDNODXL/zoTeHqHABa1eZ9YolQwv6Io1JpNkFx6NeAX3fw45DQsG9SMpU2LD8iBOS1EiL0ERrw6xp+oTeohAWCuFYA5hptGPkCzgb8uoYfh4SB8QGYawRAzeN+0Qb8uoOPov9TswB4RaDdCku3G/DrAj6R8AIXAFaoylfsNODXA/zRthkCpEQD/pkIf/T9xrB/hsKP3xMN+Gcu/FAebsA/Y+ETypWFN+CfMfABQDUs/8yFXzQFNOCfefABQI02zDNzExvwqxJ+fgqY8U0OigQoQIjJb0o5+AwApuDiqhU+ASROAz4DbGbe8jHqA/CswdcekMvxGM+TKrR8K0WQ9tgbVE3wWQP+IE/Z8oUFWE1UQUfnaRlV1GzAFwQELmPRMon3Xa1gAgaJ8CKJAOaSdGVBmxy3R8BbLwY4vl/DcgjM1QnfaSUs67TjLTPGdHRmjPk9otGNBDD0lsGR5z0Ih8LfzSB8in2AmZ7zGQAJQnaAsXKtBSExpeO8FRK//ddMvtFqmvNJAP4pRvudDi5bb2Oqx1/+LQsTANIpM0pOM/wJlcBpdfgYUA5w4m8GL/zQBRBOB6wBU8EPa0D7wMLLJd53vYI3whP7ErPt8BFgPCB9gcAH/tGCCQAThN+7kh/jhSPDoed8vLXFh50OrX+m4Y+rBM6Et88aSLUR3tgW4MRBA2mHbwg5+Q9F/wLA39/rhFOAqR5vXwggGGEs/7wDuzUc+oUKv/ekPwIgBegsY3+PC6t59uDnlcDZCvWEAIIcY/vPvTzASg8SofPXtkTgsn+ywlFAVgn8DGPBlQoXfNQKHdQEUxxHc/+Bx30M7DNQKZTxb3jGwkgxm3E+G8BJE956OcDB/w1CqDpBJ4gcxivW20gvEDBeFHbNcZzPBlh5rwOhknXqGP5Iv8H+HhdOG+Xvx2zALz8FzLDIwwawHGBHjwc/wwWufiU9IPSW7RZC+y0WvGyBLzAH8EkA/jBjyfUWzlku80CTDW3A6w95CLKcHzlmCz6VSsGzofCBASsFHN+vsftJHyQAY5JPBctutrHgUokgO/ohc2H5qpmw8otOYm8/7izHdmgcetaDnQ6tfzbh56eARCCnQd41kUO4a5OHwX4DEUGteBTg0Mlqv81GkGMImn34JEPrv/DjFtLnixBepdYftcsa2POjXH7qmG344RQwS5ZfqvAJCXgZxs5feol3LCYZdpj3f1Th765V8IY5f/NnRduPwr7mhQKX3+OE4k6CoT8+/+1nfAzs05BNhZ7/7MGfPAycwcSOiVSz/f/to3+nzg/tSSODlXfYYTTAs5fYESIM25beasOZH8GjBNZPgDvA6HvQhUrNDXyaNAzEzGf1KLLml3/qjkYDXDl81sCCdolLPmXBGyrnRE0/fBKAzgJnXSpx8Vo7sePHJoxmXv+Fi+x7kR7Cs2/58cgv5jKlywawU4Tj+zT2/T50CJmTDAFh85ffZsNuKXWiZgB+FIoGLmPp7VHYx5Vbf6wRnDpgcOhZP+/4zYXlVzwFzHQ+nw2gUoQdD3vIDiQLC+Npo3WJQPvtNvzhEnFouuELwB9hLL5O4YKPqcSiT9wJ9v44B52L/ZbZhV96rWIu4ccXK20g857Bzkc8EE0hLGTg0psttCwQ0N5EexhPwyaMBli23kkc78dRwpE/+Dj6UgCrlcBmbuFPmAyazUoeaMBOE954zseJgwZCJg8L7TRhxd12KKiI6YdPEvCHGBd+0sY5KxKKPtE0EWQY+x8JHb9qgD/uFDAXZVwkAJ1j/PVnbvJogMIOc/GNFs5ZKvOdYDotn3VYqLHs7uSp3rizHHzcw+B+A5nisSPUHMCfpCx89uDHQ6vTSjj0coA3k+YJaNRKr/ySU1BgwtMCX0ggGGIs7XTQsjiZ6BPDz/QbvNHjwWoLR7xqgD9WCZzjAs4wT0DYtdFNnCeIHcJFqySWXKXgD4dh4WkXcBJgXKBpgcBFn7USiz7Fer8Zm8GcQ/hA2bLwuYEfK2RWCjixz2Dv5uR5gvi44gsOZFMZS0vq8MVhX45x+eecsFAjadiX1/tdWOmSbN8cwx/dFKpKSrcJYSWN00bY+5iHoYR5gnjamH+RwAc+XiwOJbb8aHgMMoz5l0hc+CkrL+Ik1fv3/igbFohUkeVTNDWKaqzbFxLwsoxdjybPEyAKC5fdbqPpHAIHEbQp1u2zAS6/xxntSJVaf17v93Bqn4ZqotFq5iqwfEwWBs7log3WYeHIwed8vJswT0BRzUDLeQKX3erAG5w8UVQOfpztO+9qhcUfVlMK+9wBxusPxmFfdVl+fK6oNvhFQ7AE/voTF2YqeQIDXHyThbOWSuhscU+vyPI1oJoI7V9IVV6wUqL37/tFDrn3DISNonqLuYRf2raoVvhsQgAn9mkcfDZhniAa8q1mwuXrHQTZ0a5eCfxY9HnfJyzMu1gksv5YHh48oHH4WR9WmgB9Ok9Xmzn4lU0Bc7hWDyZcDfTKwx5ySfMEkZp4wUcUFl2pEGS4omVpIIADoOkcwiUddtjpRPIR4LUfuwhivb9K4Y+rBFbNQk0GhA1kjhq8+pCXV/wS+YQWsOJep+jvJpJghQit/+J1DlrOE+HqnEodv0gg6v+Dj6PbfditVD4UrRL4CcrC526VLgejDuHAAZO37CS+wLnLJc6/3oJfbkEJl4g+0QKP93/GOi29Xzrj1fdXD/zxp4BqWqIdgQxyjB0/TZ4niI+VX3SgSheU8NjP8UcY7V8IF3hMRfQJ9X4N5WDixStVAL/8FFCF6/M5yhP0b/fx9v/4ifIE8SiQPl/gopvscBSQ5eEHGcaCDyosSbjAo1DvP9Djwm4tV99fffDHJoOqeXMGw1ApYM8vp5AniBaULLvDRvMCAeOibCk5DLB8Cgs84ob2P+RCZ8qXplUj/PwUQNUOP1LWVIowsN9gX5QnSFQzYAArTVh6qw2/JF0cL/BY/GELZydc4BGfe3xHgEPPenm9vxbgj04BNbItC2vAbiO81uti+IhJphBG51601sbZl4biUAyZTZjrX/6lhAs8ou9qAuC1/8rlM321Ah9xLqAW4BeC1DnGzp+4yfIEBQtKlnY4MC7nVycHw4wLPmmhZcnUcv1vPuFioK+0vr+64ZcpC6+RDZlMqPAd+aOPo0nzBFEIef7HFBZdpxAMcyj6LBRYlnSBRyQQuQOMg5s8qObagV94vqjV3biEBF55IAcTJMsTxKPIsrscSJvgjzAuuS35Ao+83v9gDtl3C+v7a8Py8/exFuEjzhP0aezf7CX3BTRwdrvEko8ptCwRuOgWe0p6/8ndAQ79zoPdNnnYVy3wS9sWtQa/qHysmbDvcQ/uQJTsSZgsumitg+X/kkqc648/f//D3mi9QQ3CH18JrHL48d/LKE+w5yE3UZ6ARNjY/KUCS1ar0d8l0fu3+XjvRT+q769N+OWVwFqAXwDDaSP87WkPx/foRHmCfNuc8PxIM3j9p7niKp8ahD8DZeGzB7/QoWENvPbIFPIElHzYJwLe2uwhc9hAOOPn+WsBfrESWIPwYyh2mvDOSwEObUu+71Ai+ALIHDY4sNGFNUGqt1bgF00BtbzxcrxqZ8/Pc/CHEzqECUeM1x7IFe3nU8vwi6Tgmt51OyocGTlscOBJf0qFIxP5BoV6/9E/jpZ51TL8USWwTrZchwbsVsK+HhcjCfME4/oGPFbvL0oi1bDlY7IwsBb326do65bdD7jJ1xMUHO7rDP9IeNc52v79zc0uBvs0VDMl2M69ei0/PlfVC/xYIbTShP4/+Ti208a5qxKkdqPqHzMEZP/PhDdnEaH5QwI5z+DAo25dwC9tW9QL/MIHS5AEdv9oankCt8+EhaA2EPQzMts0Tv5aw1IULjbl+oFf2RRQY49ZQZTbH+jTOPhEhXmCeJ4fAry/McgK2yEH0DmgtVXgg3c0o3WRDJ91UCfwx1UCa/kZO3FYqJoIB36VIE9AofWzVzqchHcpe9Jg5JgBSSp5wEXtwp++3cKrBH7hhUobyB416HtwkjxBBFmfBLyDDLLHhoBCEo7s8uGPhKuV6wX++FNAHTxdKy4fO/S0h5O7J88T5F4x4KC4MWZAWoThYxrH3wigktb6Vzn88lNAnT1azWjg9fHyBPFijvcYfv9Y649LyPp3+dC5Cp5SUmPwJykLr334bAArDRx90Uf/tvHXE7h7xzoIzIC0CYNHNI7vD8YuKqkD+PkpgOoQfv6NqHCk72dhniC/WLPQ+o9Env+Yz2W8/WcPxudJiz5qEX5RLqAe4RcuMB05ZPDm5nDHkcLpwN3LYyKE2PpPHdIYPKxD6+f6gx/uEXQGPE41zhMc2Ohi5LDJVwT5hyLrt8d+NjOj/xUfzFyXlj+6R1Cdw8+LNgIIsoy+B3L5USD3Ko+5yELrP3VIQ9o0+XerQcvPO7lnyoOUOcoTHH3Bx4ndAfg4EBxjkCo/98fWX6+WX1AWXv/w8yohA5DA3h/kMPIXPbp3T6H1O4Rj+wIMvB1AFVh/vcAvbVucKfDzrwXQkhLgkTDVW3StBGiPcXiHX/QconqFP74SWKfwAUAIwtkfULCaCUKNRgRsAGUTjr8RIHMsnPuZ6xv+uFNAXVp+3I4E9m3Noe+ZHLInDaym6CnfBAQe491dfrhd/RkAv+zTw+sWfuFrDby718fxNwIsWWlhYbuFlnMFjuzwMXxMw0qNo/nXGXwAUFSy1Ubdw49exJDf/rOHo30Bzltu4cSBoOz2MfUKn0BQYbmjUBg35Kkz+EBRsafVRNA5xlsvupA2Qcoynn8dwg/P4kCA8aotHBCPCqT1Dr+0gohEOCKU3U62DuEzs0lJB8T8qmBGhor6xZkDn8qIY/Vv+XHlFIFBGSFIbFfh5jZ8psI/E7z9ktesyIIAbVfM/JI2OuwSE20W0YBfL/ABAgXGhzF4SWjjveAF2WFJSjCYG/DrGz6DWUGJnM4NS9IvCGk/d4RhdjrSgWCYBvw6tvwwzDdNogkE3rl33nNHRGdvpxZCbFJCgKMWG/DrE378CZZUECQ2dfZ2agEAjqBHM/5IRkDJ/GMZGvDrCz6H8Z+ElIPeUAZCPgoAomv1VnVTb/odzeaxFquZwGwa8OvP8sN7ySZttZKBfmzFb9PvbF29VYkNN9xgAEAF/G1X51wBSSjJlDbg1zj8aEwXJCmnsy5DfBsAbrjhBiOom0xPB8tbnpzX5wXuxrSdLiqebsCvC/hgsJ5vzROuyW1ctWVeH3ewpG4yAgB2t4OZmSyNb+aC3KDEBCFhA34twmeLlBjRmUHJwTcZTGgPWxMA0N1NBp0Qa5+av98L3PvTTrNAwRZIDfi1Cz9qQ7dZrcI12ftXPLNoPzogqJvM2O/UwXJDO/iDO4eebrFbbxz2TwWi4PEJDfi1B59hgjY1Xw0Hg8+uuG7+p7EHRL1U1rjRBRYbAH705uGFrbZ8RZFa6AYZQxSuiqMG/NqCz8Y0yxYRcHDUt4avWPnUoqMAiEB5wa9obWA3yKALdNdTre9mdeZmsDlpCYfBrBvwaws+mLUjHDbMJ3Nm6OYrnjrvXXQVwx9HKAK2rma1ZhsFj609ue5sZ/5jGT8DbXxDJEQDfm1YviUskVatOOEdv/3KZ87dxKtZ0TYKSlmX3T5pzTYKtq5mdfvmszYNZE+tlyRPplSL4NFddxrwq9XyYYJm1SIk1Mnj/on1Vz5z7qat48AfdwQodAqpl/Smm967Ou20bbaEvXjYPxUQSFLB8zSpAb8qQj0C61Y1X/nG6x/m4bVXPb3g5ZjheIwn3ECNeklvXc1q3a8XvDxsTn0oF2S3zLfnKUmSwoetRIohN+DPhbYfK3wMDhRJOss6W2V1ZsugefdDVz294GVezWoi+JOOAPHR08GyM2rod7cNf51YfaXJcuYNe0NgYzQRibIjQgP+jFk+mBnMhkjI+dZ8ZHT2lDbBd5ZvaftWyKxHdvZ2TrptdsX7aTKYNgDUDTJPfPa9y1pUy33G8N0p1WxngxFo1gExCISoMzTgTzd8BjMxGQKzIKnSqg3ZYNgTEA/nOHP/qi0L+hgswpGZKtodMfGGqnGEAABP3Tq0IsXyy0y4vUk1tWrDcHUWxvgmmh7C9olEJWFkZf7EeJmuyc7jGWx7Kt+bJ22bmQ2NnkwKSjTJJihSyAYjQwA9ZqT5XvtvWl8N2WxVa7atCZLwnNKOul1dLJbvAcXTwu87Rs7XvlxP4FsYepUl7DZFFjT7ABh+4ILBM2P5nMDSasryCSnhgIigSCEwAXztDQqinSA8IYXYeNlvWg7nFdxecHdJjD9jHSB/vV0segs6AgC8cBtfmEH2OtZ8jWH/eiKRYjYrQ0mZG5ZfgeVHq7UCItplmHMW5J9AtL2J0i9e9Ft6szBKQzs41vWncvw/3NUiKJIC/pIAAAAASUVORK5CYII=';
  function setFavicon() {
    try {
      var old = document.querySelectorAll('link[rel*="icon"]');
      for (var i = 0; i < old.length; i++) old[i].parentNode.removeChild(old[i]);
      var rels = ['icon', 'apple-touch-icon'];
      for (var j = 0; j < rels.length; j++) {
        var l = document.createElement('link');
        l.rel = rels[j]; l.type = 'image/png'; l.href = ICON;
        if (rels[j] === 'icon') l.sizes = '128x128';
        document.head.appendChild(l);
      }
    } catch (e) {}
  }
  setFavicon();
  setTimeout(setFavicon, 1500);
})();
</script>
@endverbatim
