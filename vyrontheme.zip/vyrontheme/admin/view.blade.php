<div class="row">
  <div class="col-xs-12">
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">VYRON Theme</h3>
      </div>
      <div class="box-body">
        <p>Tema VYRON aktif: gelap dengan aksen violet dan cyan. Status Online berwarna hijau, warning amber, error rose.</p>
        <p class="text-muted">Supaya nama di tab browser juga VYRON: Admin &gt; Settings &gt; Company Name = <b>VYRON</b>.</p>
      </div>
    </div>
  </div>
</div>
